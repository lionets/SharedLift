package com.amarsoft.app.httpclient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.net.URLEncoder;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;

import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.awe.util.json.JSONValue;

public class CMSHttpClient {

	public JSONObject httpClient(String sMethod, JSONObject request){
		JSONObject result = new JSONObject();
		
		String data = request.toJSONString();
		String sURL = GetNHSMEService.getBasePath();
		HttpClient client = new HttpClient();
		PostMethod method = new PostMethod(sURL);
		try {
			data = URLEncoder.encode(data, "GBK");
			((PostMethod) method).addParameter("Method", sMethod);
			((PostMethod) method).addParameter("TransMessage", data);
			HttpMethodParams param = method.getParams();
			param.setContentCharset("GBK");
			client.executeMethod(method);
			InputStream stream = method.getResponseBodyAsStream();

			BufferedReader br = new BufferedReader(new InputStreamReader(stream, "GBK"));
			StringBuffer buf = new StringBuffer();
			String line;
			while (null != (line = br.readLine())) {
				buf.append(line).append("\n");
			}
			result = (JSONObject)JSONValue.parse(URLDecoder.decode(buf.toString(), "GBK"));
			method.releaseConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
