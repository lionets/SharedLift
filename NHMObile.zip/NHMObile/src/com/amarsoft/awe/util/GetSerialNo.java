package com.amarsoft.awe.util;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import com.amarsoft.are.ARE;

/**
 * ��ȡ��ˮ��
 * @author oldbiao 2015��7��23��
 *
 */
public class GetSerialNo{
	public static String sDataSource = "";
    private static String sLockSql = "update OBJECT_MAXSN set MaxSerialNo=MaxSerialNo where TableName=:TableName and ColumnName=:ColumnName and DateFmt=:DateFmt and NoFmt=:NoFmt";
    private static String sQuerySql = "select MaxSerialNo from OBJECT_MAXSN where TableName=:TableName and ColumnName=:ColumnName and DateFmt=:DateFmt and NoFmt=:NoFmt with ur";
    private static String sUpdateSql = "update OBJECT_MAXSN set MaxSerialNo=:MaxSerialNo where TableName=:TableName and ColumnName=:ColumnName and DateFmt=:DateFmt and NoFmt=:NoFmt";
    private static String sInsertSql = "insert into OBJECT_MAXSN (TableName,ColumnName,MaxSerialNo,DateFmt,NoFmt) values (:TableName,:ColumnName,:MaxSerialNo,:DateFmt,:NoFmt)";
    private static long iCount = 100000L;
	
	public static String getDataSource()
    {
        return sDataSource;
    }

    public static void setDataSource(String dataSource)
    {
        sDataSource = dataSource;
    }

    public static String getSerialNo()
    {
        return getSerialNo("T");
    }

    public static String getSerialNo(String sPrefix)
    {
        if(iCount > 999998L)
            iCount = 100000L;
        return (new StringBuilder()).append(sPrefix).append(RandomTools.getTimeString()).append(iCount++).toString();
    }

    public static String getUUID()
    {
        return UUID.randomUUID().toString().replace("_", "");
    }

    public static String getSerialNo(String sTable, String sColumn)
        throws Exception
    {
        return getSerialNo(sTable, sColumn, "yyyyMMdd", "00000000", new Date());
    }

    public static String getSerialNo(String sTable, String sColumn, Transaction Sqlca)
        throws Exception
    {
        return getSerialNo(sTable, sColumn);
    }

    public static String getSerialNo(String sTable, String sColumn, String sPrefix)
        throws Exception
    {
        if(sPrefix == null || sPrefix.equals(""))
            sPrefix = "";
        else
            sPrefix = (new StringBuilder()).append("'").append(sPrefix).append("'").toString();
        return getSerialNo(sTable, sColumn, (new StringBuilder()).append(sPrefix).append("yyyyMMdd").toString(), "00000000", new Date());
    }

    public static String getSerialNo(String sTable, String sColumn, String sPrefix, Transaction Sqlca)
        throws Exception
    {
        return getSerialNo(sTable, sColumn, sPrefix);
    }

    public static String getSerialNo(String sTable, String sColumn, String sDateFmt, String sNoFmt, Date today, Transaction Sqlca)
        throws Exception
    {
        return getSerialNo(sTable, sColumn, sDateFmt, sNoFmt, today);
    }

    public static String getSerialNo(String sTable, String sColumn, String sDateFmt, String sNoFmt, Date today)
        throws Exception
    {
        Transaction Sqlca;
        String sNewSerialNo;
        Sqlca = null;
        sNewSerialNo = "";
        try
        {
            Sqlca = new Transaction("als");
            sNewSerialNo = getSerialNoByCon(sTable, sColumn, sDateFmt, sNoFmt, today, Sqlca);
        }
        catch(Exception e)
        {
            throw new Exception((new StringBuilder()).append("getSerialNo...\u5931\u8D25\uFF01").append(e.getMessage()).toString());
        }finally{
        	if(Sqlca != null)
        		Sqlca.disConnect();
        }
        return sNewSerialNo;
    }

    private static String getSerialNoByCon(String sTable, String sColumn, String sDateFmt, String sNoFmt, Date today, Transaction Sqlca)
        throws Exception
    {
        SimpleDateFormat simpledateformat = new SimpleDateFormat(sDateFmt);
        DecimalFormat decimalformat = new DecimalFormat(sNoFmt);
        String sDate = simpledateformat.format(today);
        int iDateLen = sDate.length();
        String sNewSerialNo = "";
        sTable = sTable.toUpperCase();
        sColumn = sColumn.toUpperCase();
        int iMaxNo = 0;
        try
        {
            SqlObject objLock = new SqlObject(sLockSql);
            objLock.setParameter("TableName", sTable).setParameter("ColumnName", sColumn).setParameter("DateFmt", sDateFmt).setParameter("NoFmt", sNoFmt);
            Sqlca.executeSQL(objLock);
            SqlObject objQuery = new SqlObject(sQuerySql);
            objQuery.setParameter("TableName", sTable).setParameter("ColumnName", sColumn).setParameter("DateFmt", sDateFmt).setParameter("NoFmt", sNoFmt);
            ASResultSet rs = Sqlca.getASResultSet(objQuery);
            if(rs.next())
            {
                String sMaxSerialNo = rs.getString(1);
                rs.close();
                iMaxNo = 0;
                if(sMaxSerialNo != null && sMaxSerialNo.indexOf(sDate, 0) != -1)
                {
                    iMaxNo = Integer.valueOf(sMaxSerialNo.substring(iDateLen)).intValue();
                    sNewSerialNo = (new StringBuilder()).append(sDate).append(decimalformat.format(iMaxNo + 1)).toString();
                } else
                {
                    sNewSerialNo = getSerialNoFromDB(sTable, sColumn, "", sDateFmt, sNoFmt, today, Sqlca);
                }
                SqlObject objUpdate = new SqlObject(sUpdateSql);
                objUpdate.setParameter("MaxSerialNo", sNewSerialNo).setParameter("TableName", sTable).setParameter("ColumnName", sColumn).setParameter("DateFmt", sDateFmt).setParameter("NoFmt", sNoFmt);
                Sqlca.executeSQL(objUpdate);
            } else
            {
                rs.close();
                sNewSerialNo = getSerialNoFromDB(sTable, sColumn, "", sDateFmt, sNoFmt, today, Sqlca);
                SqlObject objInsert = new SqlObject(sInsertSql);
                objInsert.setParameter("MaxSerialNo", sNewSerialNo).setParameter("TableName", sTable).setParameter("ColumnName", sColumn).setParameter("DateFmt", sDateFmt).setParameter("NoFmt", sNoFmt);
                Sqlca.executeSQL(objInsert);
            }
            Sqlca.commit();
        }
        catch(Exception e)
        {
            Sqlca.rollback();
            ARE.getLog().error((new StringBuilder()).append("getSerialNo...\u5931\u8D25[").append(e.getMessage()).append("]!").toString(), e);
        }
        return sNewSerialNo;
    }

    public static String getSerialNoXD(String sTable, String sColumn, String sDateFmt, String sNoFmt, Date today, Transaction Sqlca)
        throws Exception
    {
        return getSerialNoByCon(sTable, sColumn, sDateFmt, sNoFmt, today, Sqlca);
    }

    public static String getSerialNo_for_alarm(String sTable, String sColumn, String sWhere, String sDateFmt, String sNoFmt, Date today, Transaction Sqlca)
        throws Exception
    {
        return getSerialNo_for_alarm(sTable, sColumn, sDateFmt, sNoFmt, today, Sqlca);
    }

    public static String getSerialNo_for_alarm(String sTable, String sColumn, String sDateFmt, String sNoFmt, Date today, Transaction Sqlca)
        throws Exception
    {
        return getSerialNoByCon(sTable, sColumn, sDateFmt, sNoFmt, today, Sqlca);
    }

    public static String getSerialNo(String sTable, String sColumn, String sWhere, String sDateFmt, String sNoFmt, Date today, Transaction Sqlca)
        throws Exception
    {
        return getSerialNo(sTable, sColumn, sDateFmt, sNoFmt, today, Sqlca);
    }
	
	/**
	 * ��д���෽�����ų���׺ LX   ����������׺��ͨ��SQL�ų�
	 * @param sTable
	 * @param sColumn
	 * @param sWhere
	 * @param sDateFmt
	 * @param sNoFmt
	 * @param today
	 * @param Sqlca
	 * @return
	 * @throws Exception
	 */
	public static String getSerialNoFromDB(String sTable, String sColumn, String sWhere, String sDateFmt, String sNoFmt, Date today, Transaction Sqlca)
	        throws Exception
	    {
	        ARE.getLog().warn((new StringBuilder()).append("****\u4E0D\u5EFA\u8BAE\u7684\u53D6\u6D41\u6C34\u53F7\u7684\u65B9\u5F0F(getSerialNoFromDB)****[").append(sTable).append("][").append(sColumn).append("]******").toString());
	        SimpleDateFormat sdfTemp = new SimpleDateFormat(sDateFmt);
	        DecimalFormat dfTemp = new DecimalFormat(sNoFmt);
	        String sPrefix = sdfTemp.format(today);
	        int iDateLen = sPrefix.length();
	        String sSql = (new StringBuilder()).append("select max(").append(sColumn).append(") from ").append(sTable).append(" where ").append(sColumn).append(" like '").append(sPrefix).append("%' ").append(" and ").append(sColumn).append("  not like'%LX' ").toString();
	        if(sWhere.length() > 0)
	            sSql = (new StringBuilder()).append(sSql).append(" and ").append(sWhere).toString();
	        ASResultSet rsTemp = Sqlca.getResultSet(sSql);
	        int iMaxNo = 0;
	        if(rsTemp.next())
	        {
	            String sMaxSerialNo = rsTemp.getString(1);
	            if(sMaxSerialNo != null)
	                iMaxNo = Integer.valueOf(sMaxSerialNo.substring(iDateLen)).intValue();
	        }
	        rsTemp.getStatement().close();
	        String sNewSerialNo = (new StringBuilder()).append(sPrefix).append(dfTemp.format(iMaxNo + 1)).toString();
	        ARE.getLog().info((new StringBuilder()).append("newSerialNo[").append(sTable).append("][").append(sColumn).append("]=[").append(sNewSerialNo).append("]").toString());
	        return sNewSerialNo;
	    }
}
