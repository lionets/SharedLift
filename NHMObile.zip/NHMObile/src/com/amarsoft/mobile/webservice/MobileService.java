package com.amarsoft.mobile.webservice;

import com.amarsoft.are.ARE;
import com.amarsoft.are.log.Log;
import com.amarsoft.are.security.AppContext;
import com.amarsoft.are.security.DefaultAppContext;
import com.amarsoft.mobile.webservice.business.AppContextSetting;
import com.amarsoft.mobile.webservice.business.BusinessHandler;
import com.amarsoft.mobile.webservice.business.BusinessValidator;
import com.amarsoft.mobile.webservice.business.IDeviceType;
import com.amarsoft.mobile.webservice.imp.SessionBusinessHandler;
import com.amarsoft.mobile.webservice.model.BaseRequest;
import com.amarsoft.mobile.webservice.model.BaseResponse;
import com.amarsoft.mobile.webservice.model.TradeConfigModel;
import com.amarsoft.mobile.webservice.security.Base64;
import com.amarsoft.mobile.webservice.security.CompressHelp;
import com.amarsoft.mobile.webservice.security.EncryptAction;
import com.amarsoft.mobile.webservice.security.imp.Des3Encryption;
import com.amarsoft.mobile.webservice.system.AfterLogonAuthor;
import com.amarsoft.mobile.webservice.system.SignAuthor;
import java.util.Properties;
import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

@WebService(targetNamespace="http://ws.service.amarsoft.com/")
public class MobileService
{
  protected static final String SUCCESS = "SUCCESS";
  private Properties handlerProperties = new Properties();

  @Resource
  private WebServiceContext wsContext;
  private String clientIP = "";
  protected ServiceFactory factory;
private MessageContext localObject1;
private HttpServletRequest localObject2;
private SessionBusinessHandler localObject3;
private String localObject4;

  public MobileService()
  {
  }

  public MobileService(String paramString)
  {
    this.clientIP = paramString;
  }

  public void appendHandlerProperties(String paramString1, String paramString2)
  {
    this.handlerProperties.setProperty(paramString1, paramString2);
  }

  @WebMethod
  @WebResult(name="runService")
  public String runService(@WebParam(name="method") String paramString1, @WebParam(name="requestFormat") String paramString2, @WebParam(name="requestStr") String paramString3, @WebParam(name="signKey") String paramString4)
  {
    TradeManager localTradeManager = null;
    try
    {
      String str1 = this.clientIP;
      if (this.wsContext != null)
      {
        localObject1 = this.wsContext.getMessageContext();
        localObject2 = (HttpServletRequest)((MessageContext)localObject1).get("javax.xml.ws.servlet.request");
        str1 = ((HttpServletRequest)localObject2).getRemoteAddr();
      }
      ARE.getLog().info("����" + str1 + "������method=" + paramString1 + ",requestFormat=" + paramString2 + ",requestStr=" + paramString3 + ",signKey=" + paramString4);
      Object localObject1 = new DefaultAppContext();
      ((DefaultAppContext)localObject1).setClientAddress(str1);
      this.factory = getFactory();
      localTradeManager = getTradeManager(paramString1);
      if (null == localTradeManager)
      {
        ARE.getLog().error("��֧�ֵķ�����" + paramString1);
        return encodeData("request.custom:��֧�ֵķ�����" + paramString1, localTradeManager);
      }
      Object localObject2 = localTradeManager.getConvertor(paramString2);
      if (localObject2 == null)
      {
        ARE.getLog().error("����" + paramString1 + "��֧�����ݸ�ʽ" + paramString2);
        return encodeData("request.custom:����" + paramString1 + "��֧�ֵ����ݸ�ʽ" + paramString2, localTradeManager);
      }
      try
      {
        paramString3 = decodeData(paramString3, localTradeManager);
        if (localTradeManager.getTradeConfigModel().isOutputRequestStr()&&paramString3.indexOf("userpass")<0)
          ARE.getLog().debug("���������ݱ���:" + paramString3);
      }
      catch (Exception localException2)
      {
        localException2.printStackTrace();
        ARE.getLog().info("���ݽ���ʧ�ܣ�" + paramString3);
        return encodeData("request.decode.error", localTradeManager);
      }
      BaseRequest localBaseRequest = ((DataConvertor)localObject2).convertToObject(paramString3);
      if (localBaseRequest == null)
        return encodeData("request.invalid", localTradeManager);
      String str2 = systemAuth(paramString1, paramString2, paramString3, paramString4, localBaseRequest, localTradeManager);
      if (!"SUCCESS".equals(str2))
        return encodeData(returnError((DataConvertor)localObject2, str2), localTradeManager);
      BusinessHandler localBusinessHandler = localTradeManager.getBusinessHandler();
      if (localBusinessHandler == null)
        return encodeData(returnError((DataConvertor)localObject2, "trade.method.handler.invalid"), localTradeManager);
      if ((localBusinessHandler instanceof AppContextSetting))
        ((AppContextSetting)localBusinessHandler).setAppContext((AppContext)localObject1);
      localBusinessHandler.setRequestBusinessObject(localBaseRequest.getBusinessRequestObject());
      if ((localBusinessHandler instanceof IDeviceType))
        ((IDeviceType)localBusinessHandler).setDeviceType(localBaseRequest.getDeviceType());
      if ((localBusinessHandler instanceof SessionBusinessHandler))
      {
        localObject3 = (SessionBusinessHandler)localBusinessHandler;
        if ((localTradeManager.getTradeConfigModel().isNeedLogon()) && ((localBaseRequest.getSessionKey() == null) || (localBaseRequest.getSessionKey().equals(""))))
          return encodeData(returnError((DataConvertor)localObject2, "account.session.invalid"), localTradeManager);
        ((SessionBusinessHandler)localObject3).setSessionKey(localBaseRequest.getSessionKey());
      }
      if ((localBusinessHandler instanceof BusinessValidator))
      {
        String localObject3 = ((BusinessValidator)localBusinessHandler).valid();
        if (!"SUCCESS".equals(localObject3))
          return encodeData(returnError((DataConvertor)localObject2, (String)localObject3), localTradeManager);
      }
      this.handlerProperties.putAll(localTradeManager.getHandlerProperties());
      Object localObject3 = localBusinessHandler.execute(this.handlerProperties);
      if (!"SUCCESS".equals(localObject3))
      {
        if ("response.unkown".equals(localObject3))
        {
          localObject4 = "N";
          ARE.getLog().debug("sReturn=" + (String)localObject4);
          return localObject4;
        }
        localObject4 = encodeData(returnError((DataConvertor)localObject2, (String)localObject3), localTradeManager);
        ARE.getLog().debug("sReturn=" + (String)localObject4);
        return localObject4;
      }
      Object localObject4 = localBusinessHandler.getResponseBusinessObject();
      String str3 = returnStringResult((DataConvertor)localObject2, "SUCCESS", localObject4);
      if (str3 == null)
        str3 = "response.unknown";
      try
      {
        if (localTradeManager.getTradeConfigModel().isOutputResponseStr())
          ARE.getLog().debug("����������=" + str3);
        str3 = str3.replace("\\\"", "��");
        str3 = encodeData(str3, localTradeManager);
      }
      catch (Exception localException3)
      {
        ARE.getLog().info("���ݱ���ʧ�ܣ�" + str3);
        return encodeData("response.encode.error", localTradeManager);
      }
      ARE.getLog().debug("sReturn=" + str3);
      return str3;
    }
    catch (Exception localException1)
    {
      localException1.printStackTrace();
    }
    return encodeData("response.unknown", localTradeManager);
  }

  protected ServiceFactory getFactory()
  {
    return ServiceFactory.getFactory();
  }

  protected TradeManager getTradeManager(String paramString)
  {
    TradeManager localTradeManager = null;
    try
    {
      localTradeManager = this.factory.createTradeManager(paramString);
    }
    catch (Exception localException)
    {
      return null;
    }
    return localTradeManager;
  }

  protected String decodeData(String paramString, TradeManager paramTradeManager)
    throws Exception
  {
    int i = 1;
    if (paramTradeManager != null)
      i = !paramTradeManager.isUnsafe() ? 1 : 0;
    if ((i != 0) && ("true".equals(this.factory.getTransportEncryption())))
    {
      String str1 = this.factory.getTransportEncryptKey();
      int j = str1.lastIndexOf(",");
      String str2 = str1.substring(0, j);
      String str3 = str1.substring(j + 1, str1.length());
      byte[] arrayOfByte1 = str2.getBytes(this.factory.getDataChangeEncode());
      EncryptAction localEncryptAction = createEncryptAction(this.factory.getTransportEncryptAlgorithrm());
      localEncryptAction.setDecryptKey(arrayOfByte1);
      localEncryptAction.setIV(str3);
      byte[] arrayOfByte2 = localEncryptAction.decrypt(Base64.decode(paramString));
      byte[] arrayOfByte3 = CompressHelp.uncompressData(arrayOfByte2);
      paramString = new String(arrayOfByte3, this.factory.getDataChangeEncode());
      return paramString;
    }
    return paramString;
  }

  protected EncryptAction createEncryptAction(String paramString)
    throws Exception
  {
    if ((paramString == null) || (paramString.trim().length() == 0))
      return new Des3Encryption();
    return (EncryptAction)Class.forName(paramString).newInstance();
  }

  protected String encodeData(String paramString, TradeManager paramTradeManager)
  {
    int i = 1;
    if (paramTradeManager != null)
      i = !paramTradeManager.isUnsafe() ? 1 : 0;
    if ((i != 0) && ("true".equals(this.factory.getTransportEncryption())))
      try
      {
        byte[] arrayOfByte1 = paramString.getBytes(this.factory.getDataChangeEncode());
        byte[] arrayOfByte2 = CompressHelp.compressData(arrayOfByte1);
        String str1 = this.factory.getTransportEncryptKey();
        int j = str1.lastIndexOf(",");
        String str2 = str1.substring(0, j);
        byte[] arrayOfByte3 = str2.getBytes(this.factory.getDataChangeEncode());
        String str3 = str1.substring(j + 1, str1.length());
        EncryptAction localEncryptAction = createEncryptAction(this.factory.getTransportEncryptAlgorithrm());
        localEncryptAction.setDecryptKey(arrayOfByte3);
        localEncryptAction.setIV(str3);
        return arrayOfByte1.length + "," + Base64.encode(localEncryptAction.encrypt(arrayOfByte2));
      }
      catch (Exception localException)
      {
        return "response.unknown";
      }
    return paramString;
  }

  protected BaseResponse createResponse(String paramString, Object paramObject)
  {
    BaseResponse localBaseResponse = new BaseResponse();
    localBaseResponse.setReturnCode(paramString);
    localBaseResponse.setBusinessResponseObject(paramObject);
    return localBaseResponse;
  }

  protected String returnError(DataConvertor paramDataConvertor, String paramString)
  {
    return returnStringResult(paramDataConvertor, paramString, null);
  }

  protected String returnStringResult(DataConvertor paramDataConvertor, String paramString, Object paramObject)
  {
    BaseResponse localBaseResponse = createResponse(paramString, paramObject);
    return paramDataConvertor.convertFromObject(localBaseResponse);
  }

  protected String systemAuth(String paramString1, String paramString2, String paramString3, String paramString4, BaseRequest paramBaseRequest, TradeManager paramTradeManager)
  {
    if ((paramBaseRequest.getSessionKey() == null) || (paramBaseRequest.getSessionKey().length() == 0))
    {
      int i = 1;
      if (paramTradeManager != null)
        i = !paramTradeManager.isUnsafe() ? 1 : 0;
      if (i != 0)
        return new SignAuthor(this.factory.getSystemKey()).auth(paramString1, paramString2, paramString3, paramString4);
      return "SUCCESS";
    }
    AfterLogonAuthor localAfterLogonAuthor = new AfterLogonAuthor(this.factory.getSystemKey());
    localAfterLogonAuthor.setSessionKey(paramBaseRequest.getSessionKey());
    if (paramTradeManager.getTradeConfigModel().isNeedLogon())
      return localAfterLogonAuthor.auth(paramString1, paramString2, paramString3, paramString4);
    return "SUCCESS";
  }
}