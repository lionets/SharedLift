package com.amarsoft.webservice;

//import com.amarsoft.are.sql.DBFunction;
import com.amarsoft.awe.util.DBKeyHelp;
import com.amarsoft.mobile.webservice.sql.Pageable;

public class InitDBFunctionServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet{

	public void init() throws javax.servlet.ServletException{
		super.init();
		String sJndiName = getInitParameter("jndiname");
		DBKeyHelp.sDataSource = sJndiName;
		Pageable.setDBType(getInitParameter("dbtype"));
	}

}
