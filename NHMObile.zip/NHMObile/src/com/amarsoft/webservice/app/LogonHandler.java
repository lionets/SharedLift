package com.amarsoft.webservice.app;

import java.util.Properties;

import javax.servlet.ServletException;

import com.amarsoft.app.httpclient.CMSHttpClient;
import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandler;
import com.amarsoft.mobile.webservice.session.SessionManager;
/**
 * ��¼����
 * ���������
 * 		userid:�û� ��
 * 		userpass������
 * ���������
 * 		sessionKey:��¼��ʾ
 * 		roleid:��ɫ���
 * 		orgid:�������
 *      orgname����������
 * 		username:�û�����
 * @author flian
 *
 */
public class LogonHandler extends JSONHandler {

	public Object createResponse(JSONObject request, Properties arg1) throws HandlerException{
		JSONObject result = new JSONObject();
		CMSHttpClient client = new CMSHttpClient();
		try {
			result = client.httpClient("logon", request);
			if (result.containsKey("Exception")) {
				String exception=result.get("Exception").toString();
				throw new HandlerException(exception);
			}else{
				String sSessionKey = createSessionKey(request);
				if(sSessionKey!=null){
					//���ؽ��
					try{
						result.put("sessionKey", sSessionKey);
						return result;
					}
					catch(Exception e){
						e.printStackTrace();
						ARE.getLog().error(e.toString());
						throw new HandlerException("logon.createKey.fail");
					}
				}
				else{
					throw new HandlerException("logon.createKey.fail");
				}
			}
		} catch (HandlerException e) {
			throw e;
		}
	}
	
	private String createSessionKey(JSONObject businessRequest){
		try{
			return SessionManager.createSessionKey(businessRequest.get("userid").toString(),"");
		}
		catch(Exception e){
			return null;
		}
	}
}
