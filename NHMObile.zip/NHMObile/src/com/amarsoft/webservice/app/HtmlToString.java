package com.amarsoft.webservice.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class HtmlToString {
	public static String getHtmlTemplate(String sFileName) {
		StringBuffer sf = new StringBuffer();
//		String sFileName = ARE.getProperty("formathtml") + "/" + name;// ���html�ļ���·��
		if(sFileName.equals("") || sFileName == null){
			return "�ļ��������ڣ�";
		}
		File file = new File(sFileName);
		try {
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			try {
				while (br.ready()) {
					try {
						sf.append(br.readLine() + "\n");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				br.close();
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sf.toString();
	}

	public static String createHtmlFromFileName(HashMap params,
			String templateName) {

		String html = getHtmlTemplate(templateName);
		java.util.Iterator it = params.keySet().iterator();
		while (it.hasNext()) {
			String sKey = it.next().toString();
			String sValue = params.get(sKey).toString();
			html = html.replaceAll("#\\{" + sKey + "\\}", sValue);
		}
		return html;

	}
}
