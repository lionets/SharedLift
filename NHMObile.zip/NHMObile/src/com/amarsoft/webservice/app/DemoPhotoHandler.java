package com.amarsoft.webservice.app;


import java.sql.Connection;
import java.util.ArrayList;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandler;
import com.amarsoft.mobile.webservice.security.Base64;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.webservice.proj.nh.PhotoSave;

/**
 * ͼƬ��������
 * ���������
 * 		ObjectType �������ͣ�Apply,Customer
 * 		ObjectNo ������
 * 		BizType ҵ�����ͣ�Apply-����,Customer-�ͻ�����,Afterloan-������,Credit-����
 * 		PhotoDesc ͼƬ����
 * 
 * 		Address ���յ�ַ
 * 		Latitude ��������-����
 * 		Longitude �������꣭γ��
 * 		PhotoDatas ͼƬ����
 * ���������
 * 		��
 * @author flian
 *
 */
public class DemoPhotoHandler extends JSONHandler {

	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		String sInputUser = SessionManager.getUserId(this.getSessionKey());
		if(!request.containsKey("BizType")){
			throw new HandlerException("��Ҫҵ������");
		}
		if(!request.containsKey("ObjectType")){
			throw new HandlerException("��Ҫ��������");
		}
		if(!request.containsKey("ObjectNo")){
			throw new HandlerException("��Ҫ������");
		}
		if(!request.containsKey("PhotoDatas")){
			throw new HandlerException("ȱ��ͼƬ����");
		}
		Connection conn = null;
		try{
			conn=ARE.getDBConnection("als");
			//���ַ���ͼƬ���ݻ�ԭ
			ArrayList<byte[]> photoDatalist = createPhotoDataList(request.get("PhotoDatas").toString());
			PhotoSave saver = new PhotoSave(request.get("BizType").toString(),request.get("ObjectType").toString(),request.get("ObjectNo").toString());
			saver.setInputUser(sInputUser);
			if(request.containsKey("PhotoDesc"))
				saver.setPhotoDesc(request.get("PhotoDesc").toString());
			if(request.containsKey("Address"))
				saver.setAddress(request.get("Address").toString());
			if(request.containsKey("Latitude"))
				saver.setLatitude(Double.parseDouble(request.get("Latitude").toString()));
			if(request.containsKey("Longitude"))
				saver.setLongitude(Double.parseDouble(request.get("Longitude").toString()));
			saver.save(photoDatalist, conn);
		}
		catch(Exception e){
			try{
				conn.rollback();
			}
			catch(Exception ex){ex.printStackTrace();}
			e.printStackTrace();
			throw new HandlerException("ͼƬ�ϴ�ʧ��");
		}
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception ex){ex.printStackTrace();}
		}
		
		return null;
	}
	
	private ArrayList<byte[]> createPhotoDataList(String photodatas)throws Exception{
		String[] photoDatas = photodatas.split("\\,");
		ArrayList<byte[]> photoDatalist = new ArrayList<byte[]>();
		for(int i=0;i<photoDatas.length;i++)
			photoDatalist.add(Base64.decode(photoDatas[i]));
		return photoDatalist;
	}

}
