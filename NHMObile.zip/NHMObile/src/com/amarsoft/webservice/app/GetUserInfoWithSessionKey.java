package com.amarsoft.webservice.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.DBKeyHelp;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandler;
import com.amarsoft.mobile.webservice.session.SessionManager;

public class GetUserInfoWithSessionKey extends JSONHandler {

	@Override
	public Object createResponse(JSONObject arg0, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		DBKeyHelp.setDataSource("als");
		Connection conn = null;
		JSONObject result = new JSONObject();
		try {
			if (conn == null) {
				conn = ARE.getDBConnection("als");
			}
			String sql = "select i.belongorg,i.username,getOrgName(i.belongorg) as OrgName from user_info i where i.userid='"
					+ SessionManager.getUserId(getSessionKey())
					+ "' and i.status='1'";
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				result.put("username", rs.getObject("username") == null ? ""
						: rs.getObject("username").toString().trim());
				result.put("orgid", rs.getObject("belongorg") == null ? "" : rs
						.getObject("belongorg").toString().trim());
				result.put("orgname", rs.getObject("OrgName") == null ? "" : rs
						.getObject("OrgName").toString().trim());
				rs.getStatement().close();
				String sql2 = "select r.roleid from user_role r where r.userid='"
						+ SessionManager.getUserId(getSessionKey()) + "'";
				PreparedStatement ps2 = conn.prepareStatement(sql2);
				ARE.getLog().info(
						sql2 + ",userid=" + SessionManager.getUserId(getSessionKey()));
				rs = ps2.executeQuery();
				while (rs.next()) {
					if (!result.containsKey("roleid")) {
						result.put("roleid", rs.getString("roleid"));
					} else {
						result.put("roleid", result.get("roleid").toString()
								+ "," + rs.getString("roleid"));
					}
				}
			}
			rs.getStatement().close();

		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			throw new HandlerException(e.getMessage());
		}

		return result;
	}

}
