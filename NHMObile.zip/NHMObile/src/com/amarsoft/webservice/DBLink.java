package com.amarsoft.webservice;

import java.sql.SQLException;

import com.amarsoft.awe.util.Transaction;
import com.amarsoft.dict.als.cache.NameCache;

/**
 * ��ȡ���ݿ�����
 * @author WJ
 *
 */
public class DBLink {

	public static Transaction getSqlca(){
		
		Transaction Sqlca;
		try {
			Sqlca = NameCache.getSqlca();
			
			return Sqlca;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
		
	}
	
}
