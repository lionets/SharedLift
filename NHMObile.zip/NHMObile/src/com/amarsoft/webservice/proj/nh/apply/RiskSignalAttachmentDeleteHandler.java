package com.amarsoft.webservice.proj.nh.apply;

import java.util.Properties;

import com.amarsoft.app.httpclient.CMSHttpClient;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;

/**
 * ����Ԥ������ɾ��������
 * ���������
 * 		DocNo:�ĵ����
		ObjectNo:������
		ObjectType:��������
 * ���������
 * 		result:success\fail
 * 
 * @author jwu1  2015/11/09
 *
 */
public class RiskSignalAttachmentDeleteHandler extends JSONHandlerWithSession {
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		JSONObject result = new JSONObject();
		CMSHttpClient client = new CMSHttpClient();
		request.put("userid", SessionManager.getUserId(this.getSessionKey()));
		result = client.httpClient("riskSignalAttachmentDelete", request);
		if (result.containsKey("Exception")) {
			String exception=result.get("Exception").toString();
			throw new HandlerException(exception);
		}
		return result;
	}
	
}
