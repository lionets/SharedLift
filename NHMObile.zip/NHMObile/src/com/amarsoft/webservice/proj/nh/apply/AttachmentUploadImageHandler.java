package com.amarsoft.webservice.proj.nh.apply;

import java.util.Properties;

import com.amarsoft.app.httpclient.CMSHttpClient;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;

/**
 * �ͻ���鱨�棨�����ϴ���
 * ���������
		ObjectNo:������
		ObjectType:��������
		TypeNo:�ϴ��ڵ���
		
 * ���������
 * 		result:success\fail
 * 
 * @author jwu1  2015/11/19
 *
 */
public class AttachmentUploadImageHandler extends JSONHandlerWithSession {
	
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		JSONObject result = new JSONObject();
		CMSHttpClient client = new CMSHttpClient();
//		request = new JSONObject();
		request.put("userid", SessionManager.getUserId(this.getSessionKey()));
		result = client.httpClient("attachmentUploadImage", request);
		if (result.containsKey("Exception")) {
			String exception=result.get("Exception").toString();
			throw new HandlerException(exception);
		}
		return result;
	}
	
}
