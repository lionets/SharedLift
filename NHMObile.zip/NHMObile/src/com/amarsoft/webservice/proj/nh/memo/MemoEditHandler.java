package com.amarsoft.webservice.proj.nh.memo;

import java.util.Properties;

import com.amarsoft.app.httpclient.CMSHttpClient;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
/**
 * ����¼����
 * ���������

 * ���������

 * @author 
 *
 */

public class MemoEditHandler extends  JSONHandlerWithSession {
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		JSONObject result = new JSONObject();
		CMSHttpClient client = new CMSHttpClient();
		request.put("userid", SessionManager.getUserId(this.getSessionKey()));
		result = client.httpClient("memoEdit", request);
		if (result.containsKey("Exception")) {
			String exception=result.get("Exception").toString();
			throw new HandlerException(exception);
		}
		return result;
	}
}