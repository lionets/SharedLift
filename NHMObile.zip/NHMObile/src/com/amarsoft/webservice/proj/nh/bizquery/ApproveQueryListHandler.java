package com.amarsoft.webservice.proj.nh.bizquery;

import java.util.Properties;

import com.amarsoft.app.httpclient.CMSHttpClient;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.ServiceFactory;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;

/**
 * ������ѯ�б�
 * @author zhukai
 *
 */
public class ApproveQueryListHandler extends JSONHandlerWithSession {

	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		JSONObject result = new JSONObject();
		CMSHttpClient client = new CMSHttpClient();
		request.put("userid", SessionManager.getUserId(this.getSessionKey()));
		request.put("sPhotoRootPath", ServiceFactory.getFactory().getUploadRootPath());
		result = client.httpClient("approveQueryList", request);
		if (result.containsKey("Exception")) {
			String exception=result.get("Exception").toString();
			throw new HandlerException(exception);
		}
		return result;
	}
}
