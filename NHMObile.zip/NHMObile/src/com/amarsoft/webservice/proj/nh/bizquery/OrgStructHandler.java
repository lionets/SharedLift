package com.amarsoft.webservice.proj.nh.bizquery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;
/**
 * ��������ṹ��ѯ2
 * ���������
	SearchKey - ��ѯ�������������ƣ�[���л���,�޴�֧�У�����֧��....]
 * ���������
	html

 * @author 
 *
 */

public class OrgStructHandler extends JSONHandlerWithSession {

	private String SearchKey = "";
	private String sDate = StringFunction.getToday().substring(0,4);//��ǰ���
	
	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		StringBuffer result = new StringBuffer();
		
		if(request.containsKey("SearchKey")){//��ѯ����
			this.SearchKey =request.get("SearchKey").toString();
		}
		
		//add 20140416
		String sUserId = SessionManager.getUserId(this.getSessionKey());
		String getorg = " select belongorg from user_info where userid=?";
		
		String query = " select OrgName,yearbalance,MortgageBalance,GuarantBalance,TrustBalance,DiscountBalance "
				+ "from mobile_org_condition where currentyear =? and querymonth=(select max(querymonth) from mobile_org_condition) ";
		
		try {
		
			conn= ARE.getDBConnection("als");
			Pageable.setDBType("DB2");
			
			String orgid = "";
			PreparedStatement psorg = conn.prepareStatement(getorg);
			psorg.setString(1, sUserId);
			ARE.getLog().info(getorg);
			ResultSet rsorg = psorg.executeQuery();
			if(rsorg.next()){
				orgid = rsorg.getString("belongorg");
			}
			rsorg.getStatement().close();

			if((SearchKey==null) || SearchKey.equals("")){//��ʼҳ�棬��ѯ����Ϊ��
				String sWhereClause = " and 1=2 ";
				query+=sWhereClause;
			}
			else if(SearchKey.equals("All")){//��ѯ����������,��ǰ�������ܵ����У�
				String sWhereClause = " and (orgid in (select orgid from Org_Info where belongorgid like '%"+orgid+"%') or orgid='"+orgid+"')";
				query+=sWhereClause;
			}
			else {//��ѯ����������,����ѯ�Ļ�����
				String sWhereClause = " and orgname = '"+SearchKey+"'";
				query+=sWhereClause;
			}
			String sOrderClause = "  order by orgid ";
			query+=sOrderClause;
			
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, sDate);
			ARE.getLog().info(query);
			ResultSet rs = ps.executeQuery();
			
			result.append("<!DOCTYPE html>");
			result.append("<html><head><meta charset=\"utf-8\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><Title>��������ṹ��ѯ</title>");
			
			result.append("<style type=\"text/css\">");
			result.append("body { padding:0px;margin:5px;font-size:12px;font-family:\"΢���ź�\";}");
			result.append("table { border:1px solid #d8d8d8;padding:0px;margin-top:10px;-moz-border-radius: 10px 10px 0px 0px;-webkit-border-radius: 3px 3px 0px 0px;border-radius:10px 10px 0px 0px;}");
			result.append("th { padding-left:8px;background:#e8e8e8;color:#d4537a;font-size:14px;-moz-border-radius: 10px 10px 0px 0px;-webkit-border-radius: 3px 3px 0px 0px;border-radius:10px 10px 0px 0px;}");
			result.append("td { background:#FFFfff; color:#333333;padding-left:8px;line-height:24px;border-bottom:1px dotted #CCCCCC;}.left{ color:#333333; text-align:left; font-weight:bold;}.right{ color:#666666; text-align:right;padding-right:8px;}");
			
			result.append("</style></head><body><TABLE CELLSPACING=\"0\" COLS=\"6\" BORDER=\"1\" cellpadding=\"0\" style=\"border-collapse: collapse\"  bordercolor=\"#{111111\" width=\"100%\">");
			result.append("	<TR>");
			result.append("		<TD HEIGHT=\"34\" ALIGN=\"CENTER\" VALIGN=MIDDLE><B><FONT COLOR=\"#{000000\">����</FONT></B></TD>");
			result.append("		<TD ALIGN=\"CENTER\" VALIGN=MIDDLE><B><FONT COLOR=\"#{000000\">�������</FONT></B></TD>");
			result.append("		<TD ALIGN=\"CENTER\" VALIGN=MIDDLE><B><FONT COLOR=\"#{000000\">��Ѻ</FONT></B></TD>");
			result.append("		<TD ALIGN=\"CENTER\" VALIGN=MIDDLE><B><FONT COLOR=\"#{000000\">��֤</FONT></B></TD>");
			result.append("		<TD ALIGN=\"CENTER\" VALIGN=MIDDLE><B><FONT COLOR=\"#{000000\">����</FONT></B></TD>");
			result.append("		<TD ALIGN=\"CENTER\" VALIGN=MIDDLE><B><FONT COLOR=\"#{000000\">����</FONT></B></TD>");
			result.append("	</TR>");
			
			while(rs.next()){
				result.append("	<TR>");
				result.append("		<TD HEIGHT=\"34\" ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#{000000\">"+rs.getString("OrgName")+"</FONT></TD>");
				result.append("		<TD ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#{000000\">"+(new DecimalFormat("#0.00").format(rs.getDouble("yearbalance")))+"<BR></FONT></TD>");
				result.append("		<TD ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#{000000\">"+(new DecimalFormat("#0.00").format(rs.getDouble("MortgageBalance")))+"<BR></FONT></TD>");
				result.append("		<TD ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#{000000\">"+(new DecimalFormat("#0.00").format(rs.getDouble("GuarantBalance")))+"<BR></FONT></TD>");
				result.append("		<TD ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#{000000\">"+(new DecimalFormat("#0.00").format(rs.getDouble("TrustBalance")))+"<BR></FONT></TD>");
				result.append("		<TD ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#{000000\">"+(new DecimalFormat("#0.00").format(rs.getDouble("DiscountBalance")))+"<BR></FONT></TD>");
				result.append("	</TR>");
			}
			rs.getStatement().close();
		}catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return result;
	}

}
