package com.amarsoft.webservice.proj.nh.afterloan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
/**�������
SerialNo
�������
status
*/
public class CheckCommitHandler extends JSONHandlerWithSession{
	
	private String sSerialno = "";//�����
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {

		Connection conn = null;
		JSONObject response = new JSONObject();

		if (request.containsKey("SerialNo")) {// ״̬����
			this.sSerialno = request.get("SerialNo").toString();
		}
		
		String sSqlUpdate = " update inspect_info set steptype = '2' where serialno =? and objecttype = 'MobileCustomer'";

		
		try {
			conn = ARE.getDBConnection("als");
			String status = "";
			conn.setAutoCommit(false);
			PreparedStatement ps = conn.prepareStatement(sSqlUpdate);
			ps.setString(1, sSerialno);
			ARE.getLog().info(sSqlUpdate);
			ps.executeUpdate();
			conn.commit();
			status="success";
			response.put("status", status);

		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			return null;
		}

		finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				ARE.getLog().error("���ݿ�ر�ʧ��:" + e.getMessage());
				e.printStackTrace();
			}
		}

		return response;

	}


}
