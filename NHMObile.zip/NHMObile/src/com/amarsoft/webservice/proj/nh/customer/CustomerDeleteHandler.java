package com.amarsoft.webservice.proj.nh.customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;

/**
 * @author Administrator
 * ���������CustomerNo �ͻ���
 * ���������status ״̬
 * 
 */
public class CustomerDeleteHandler extends JSONHandlerWithSession {

	private String CustomerNo = "";
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		JSONObject response = new JSONObject();
		if (request.containsKey("CustomerNo")) {
			this.CustomerNo = request.get("CustomerNo").toString();
		}
		String sql = " delete from strange_customer_info where serialno =?";
		try {
			conn = ARE.getDBConnection("als");
			conn.setAutoCommit(false);
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, CustomerNo);
			ARE.getLog().info(sql+" Serialno="+CustomerNo);
			ps.execute();
			conn.commit();
			response.put("status", "success");
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			throw new HandlerException(e.getMessage());
		}

		finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				ARE.getLog().error("���ݿ�ر�ʧ��:" + e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}
}
