package com.amarsoft.webservice.proj.nh.apply;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.DBKeyHelp;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.security.Base64;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.webservice.proj.nh.PhotoSave;

/**
 * �����ݴ� ��������� 1�������ݴ棺 ApplyNo - ������(ApplyNo =="") CustomerNo - �ͻ����
 * CustomerName - �ͻ����� CreditMoney-���Ž��(decimal) Remark-��ע TermMonth -
 * ���ޣ��£�(integer) BusinessRate - �������� PayWay - ���ʽ Latitude - ���� Longitude - γ��
 * PhotoDes - ��Ƭ���� PhotoDatas - ͼƬ����
 * 
 * 
 * 2���޸��ݴ棺 ApplyNo - ������(ApplyNo !="") CreditMoney-���Ž��(decimal) Remark-��ע
 * TermMonth - ���ޣ��£�(integer) PayWay - ���ʽ BusinessRate - �������� Latitude - ����
 * Longitude - γ�� PhotoDes - ��Ƭ���� PhotoDatas - ͼƬ���� ��������� status
 * 
 * @author
 * 
 */
public class ApplyTempSaveHandler extends JSONHandlerWithSession {
	private String sApplyNo = "";
	private String sInputOrgID = "";
	private String sInputOrgName = "";
	private String sUserName = "";
	private String sSerialNo = "";

	public static String sbizType = "Apply";
	public static String sObjetctype = "Apply";

	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub

		Connection conn = null;
		JSONObject response = new JSONObject();
		ARE.getLog(request.toString());
		if (request.containsKey("ApplyNo")) {
			this.sApplyNo = request.get("ApplyNo").toString();
		}

		String sUserId = SessionManager.getUserId(this.getSessionKey());// �û���
		// ��ȡ�Ǽǻ�����Ϣ
		String sGetNameSql = " select username,belongorg as InputOrgID,getOrgName(belongorg) as OrgName from USER_INFO "
				+ " where userid = ?";
		// �������� FLOW_OBJECT��
		String sSqlInsertObject = "insert into flow_object(objecttype,objectno,applytype,"
				+ "phasetype,phaseno,phasename,"
				+ "flowno,flowname,"
				+ "orgid,orgname,userid,username,inputdate) "
				+ "values('SmallApply',?,'SmallApply','1010','0010','������','SmallFlow','С΢ҵ������',?,?,?,?,?)";
		// ����flow_task��
		String sSqlInsertTask = "insert into flow_task(objecttype,objectno,applytype,"
				+ "phasetype,phaseno,phasename,"
				+ "flowno,flowname,"
				+ "orgid,orgname,userid,username,begintime,SerialNo) "
				+ "values('SmallApply',?,'SmallApply','1010','0010','������','SmallFlow','С΢ҵ������',?,?,?,?,?,?)";

		// ����BUSINESS_APPLY��(��˾���˿ͻ�)
		String sSqlInsertCustomer = " insert into BUSINESS_APPLY(SerialNo,BUSINESSSUM,"
				+ " BUSINESSRATE,TermMonth,Remark,PAYCYC,"
				+ " UpdateDate,INPUTORGID,INPUTUSERID,INPUTDATE,tempsaveflag,BUSINESSTYPE,CustomerID,CustomerName,FLAG5,ApplyType,"
				+ " OccurType,flag4,OccurDate,OperateOrgID,OperateUserID,OperateDate,BASERATETYPE,BASERATE,RATEFLOATTYPE,RATEFLOAT,EXECUTEYEARRATE,BusinessCurrency)"
				+ " values(?,?,?,?,?,?,?,?,?,?,'1','5020090',?,?,'010','SmallApply','010','01',?,?,?,?,?,?,?,?,?,?)";// ���ձ�ҵ��(С΢)
		// ����BUSINESS_APPLY��(��˾���˿ͻ�)
		String sSqlUpdateCustomer = " update BUSINESS_APPLY set"
				+ " BUSINESSSUM = ?,BUSINESSRATE = ?,"
				+ " TermMonth = ?,Remark =?,PAYCYC = ?,UpdateDate = ?,"
				+ " BASERATETYPE=?,BASERATE=?,RATEFLOATTYPE=?,RATEFLOAT=?,EXECUTEYEARRATE=?,BusinessCurrency=?,"
				+ " TempSaveFlag = '1'" + // �ݴ��־λ��1���ݴ棬2�����棩
				" where SerialNo =?";

		// ɾ��ԭ��Ƭ��Ϣ
		String sSqlDelete = " delete from photo_info where objectno = ? and objecttype = 'Apply' and biztype = 'Apply'";

		try {
			conn = ARE.getDBConnection("als");
			conn.setAutoCommit(false);
			// ��ȡ������
			PreparedStatement psUser = conn.prepareStatement(sGetNameSql);
			psUser.setString(1, sUserId);
			ARE.getLog().info(sGetNameSql + "," + sUserId);
			ResultSet rsUser = psUser.executeQuery();
			if (rsUser.next()) {
				this.sInputOrgID = rsUser.getString("InputOrgID");
				this.sInputOrgName = rsUser.getString("OrgName");
				this.sUserName = rsUser.getString("username");
			}
			rsUser.getStatement().close();
			String sCurrentTime = StringFunction.getTodayNow();
			if (sApplyNo.equals("")) {// ��������

				if (!isFloatPointNumber(request.get("CreditMoney").toString())
						&& !isIntegerNumber(request.get("CreditMoney")
								.toString())) {
					throw new Exception("���Ž����д����ȷ��");
				}
				if (!isIntegerNumber(request.get("TermMonth").toString())) {
					throw new Exception("������д����ȷ��");
				}
				if (!isFloatPointNumber(request.get("RateFloat").toString())
						&& !isIntegerNumber(request.get("RateFloat")
								.toString())) {
					throw new Exception("����������д����ȷ��");
				}

				PreparedStatement ps = conn
						.prepareStatement(sSqlInsertCustomer);
				sApplyNo = DBKeyHelp.getSerialNo("Business_Apply", "SerialNo",
						"\'BA\'yyyyMMdd", "00000000", new Date());
				ps.setString(1, sApplyNo);

				if (request.get("CreditMoney").toString().equals("")) {
					ps.setNull(2, Types.DECIMAL);
				} else {
					ps.setDouble(2, Double.parseDouble(request.get(
							"CreditMoney").toString()));// alert20140226
				}

				if (request.get("BusinessRate").toString().equals("")) {
					ps.setNull(3, Types.DECIMAL);
				} else {
					ps.setDouble(3, Double.parseDouble(request.get(
							"BusinessRate").toString()));// alert20140226
				}

				if (request.get("TermMonth").toString().equals("")) {
					ps.setNull(4, Types.INTEGER);
				} else {
					ps.setInt(4, Integer.parseInt(request.get("TermMonth")
							.toString()));// alert20140226
				}

				ps.setString(5, request.get("Remark").toString());
				ps.setString(6, request.get("PayWay").toString());
				ps.setString(7, StringFunction.getToday());
				ps.setString(8, sInputOrgID);
				ps.setString(9, sUserId);
				ps.setString(10, StringFunction.getToday());
				ps.setString(11, request.get("CustomerNo").toString());
				ps.setString(12, request.get("CustomerName").toString());
				ps.setString(13, StringFunction.getToday());
				ps.setString(14, sInputOrgID);
				ps.setString(15, sUserId);
				ps.setString(16, StringFunction.getToday());
				//add 20140527
				ps.setString(17, request.get("BaseRateType").toString());
				
				if (request.get("BaseRate").toString().equals("")) {
					ps.setNull(18, Types.DECIMAL);
				} else {
					ps.setDouble(18, Double.parseDouble(request.get(
							"BaseRate").toString()));
				}
				
				ps.setString(19, request.get("RateFloatType").toString());
				
				if (request.get("RateFloat").toString().equals("")) {
					ps.setNull(20, Types.DECIMAL);
				} else {
					ps.setDouble(20, Double.parseDouble(request.get(
							"RateFloat").toString()));
				}
				
				if (request.get("ExecuteYearRate").toString().equals("")) {
					ps.setNull(21, Types.DECIMAL);
				} else {
					ps.setDouble(21, Double.parseDouble(request.get(
							"ExecuteYearRate").toString()));
				}
				ps.setString(22, request.get("BusinessCurrency").toString());
				//end
				ARE.getLog().info(sSqlInsertCustomer);
				ps.executeUpdate();
				// ����flow_object��
				PreparedStatement psObject = conn
						.prepareStatement(sSqlInsertObject);
				psObject.setString(1, sApplyNo);
				psObject.setString(2, sInputOrgID);
				psObject.setString(3, sInputOrgName);
				psObject.setString(4, sUserId);
				psObject.setString(5, sUserName);
				psObject.setString(6, StringFunction.getToday());
				ARE.getLog().info(sSqlInsertObject);
				psObject.executeUpdate();
				// ����flow_task��
				PreparedStatement psTask = conn
						.prepareStatement(sSqlInsertTask);
				sSerialNo = DBKeyHelp.getSerialNo("flow_task", "SerialNo");
				psTask.setString(1, sApplyNo);
				psTask.setString(2, sInputOrgID);
				psTask.setString(3, sInputOrgName);
				psTask.setString(4, sUserId);
				psTask.setString(5, sUserName);
				psTask.setString(6, sCurrentTime);
				psTask.setString(7, sSerialNo);
				ARE.getLog().info(sSqlInsertTask);
				psTask.executeUpdate();
				// ������Ƭ
				if (!request.containsKey("PhotoDatas")) {
					throw new HandlerException("ȱ��ͼƬ����");
				} else if (!request.get("PhotoDatas").toString().equals("")) {
					PhotoSave psave = new PhotoSave(sbizType, sObjetctype,
							sApplyNo);
					ArrayList<byte[]> photoDatalist = createPhotoDataList(request
							.get("PhotoDatas").toString());
					psave.setInputUser(sUserId);
					psave.setPhotoDesc(request.get("PhotoDes").toString());
					// modify 20140319 by ldfang
					if (request.get("Latitude").toString().equals("")) {
						psave.setLatitude(1000);
					} else {
						psave.setLatitude(Double.parseDouble(request.get(
								"Latitude").toString()));
					}
					if (request.get("Longitude").toString().equals("")) {
						psave.setLongitude(1000);
					} else {
						psave.setLongitude(Double.parseDouble(request.get(
								"Longitude").toString()));
					}
					// end
					psave.setLatitude(Double.parseDouble(request
							.get("Latitude").toString()));
					psave.setLongitude(Double.parseDouble(request.get(
							"Longitude").toString()));
					// psave.setAddress(request.get("Address").toString());
					psave.save(photoDatalist, conn);
				}
			} else {// ��������

				if (!isFloatPointNumber(request.get("CreditMoney").toString())
						&& !isIntegerNumber(request.get("CreditMoney")
								.toString())) {
					throw new Exception("���Ž����д����ȷ��");
				}
				if (!isIntegerNumber(request.get("TermMonth").toString())) {
					throw new Exception("������д����ȷ��");
				}
				if (!isFloatPointNumber(request.get("RateFloat").toString())
						&& !isIntegerNumber(request.get("RateFloat")
								.toString())) {
					throw new Exception("����������д����ȷ��");
				}

				PreparedStatement ps = conn
						.prepareStatement(sSqlUpdateCustomer);
				if (request.get("CreditMoney").toString().equals("")) {
					ps.setNull(1, Types.DECIMAL);
				} else {
					ps.setDouble(1, Double.parseDouble(request.get(
							"CreditMoney").toString()));// alert20140226
				}

				if (request.get("BusinessRate").toString().equals("")) {
					ps.setNull(2, Types.DECIMAL);
				} else {
					ps.setDouble(2, Double.parseDouble(request.get(
							"BusinessRate").toString()));// alert20140226
				}

				if (request.get("TermMonth").toString().equals("")) {
					ps.setNull(3, Types.INTEGER);
				} else {
					ps.setInt(3, Integer.parseInt(request.get("TermMonth")
							.toString()));// alert20140226
				}

				ps.setString(4, request.get("Remark").toString());
				ps.setString(5, request.get("PayWay").toString());
				ps.setString(6, StringFunction.getToday());
				
				//add 20140527
				ps.setString(7, request.get("BaseRateType").toString());
				
				if (request.get("BaseRate").toString().equals("")) {
					ps.setNull(8, Types.DECIMAL);
				} else {
					ps.setDouble(8, Double.parseDouble(request.get(
							"BaseRate").toString()));
				}
				ps.setString(9, request.get("RateFloatType").toString());
				if (request.get("RateFloat").toString().equals("")) {
					ps.setNull(10, Types.DECIMAL);
				} else {
					ps.setDouble(10, Double.parseDouble(request.get(
							"RateFloat").toString()));
				}
				if (request.get("ExecuteYearRate").toString().equals("")) {
					ps.setNull(11, Types.DECIMAL);
				} else {
					ps.setDouble(11, Double.parseDouble(request.get(
							"ExecuteYearRate").toString()));
				}
				//end
				
				ps.setString(12, sApplyNo);
				ARE.getLog().info(sSqlUpdateCustomer);
				ps.executeUpdate();
				if (!request.containsKey("PhotoDatas")) {
					throw new HandlerException("ȱ��ͼƬ����");
				} else {
					// ɾ����Ƭ
					PreparedStatement psPhoto = conn
							.prepareStatement(sSqlDelete);
					psPhoto.setString(1, sApplyNo);
					ARE.getLog().info(sSqlDelete);
					psPhoto.executeUpdate();
					// ����Ƭ�ͷ������
					if (!request.get("PhotoDatas").toString().equals("")) {
						PhotoSave psave = new PhotoSave(sbizType, sObjetctype,
								sApplyNo);
						ArrayList<byte[]> photoDatalist = createPhotoDataList(request
								.get("PhotoDatas").toString());
						psave.setInputUser(sUserId);
						psave.setPhotoDesc(request.get("PhotoDes").toString());
						// modify 20140319 by ldfang
						if (request.get("Latitude").toString().equals("")) {
							psave.setLatitude(1000);
						} else {
							psave.setLatitude(Double.parseDouble(request.get(
									"Latitude").toString()));
						}
						if (request.get("Longitude").toString().equals("")) {
							psave.setLongitude(1000);
						} else {
							psave.setLongitude(Double.parseDouble(request.get(
									"Longitude").toString()));
						}
						// end
						psave.setLatitude(Double.parseDouble(request.get(
								"Latitude").toString()));
						psave.setLongitude(Double.parseDouble(request.get(
								"Longitude").toString()));
						// psave.setAddress(request.get("Address").toString());
						psave.save(photoDatalist, conn);
					}
				}
			}
			conn.commit();
			response.put("status", "success");
		} catch (Exception e) {
			ARE.getLog().error(
					"������Ϣ�ݴ�ʧ��"
							+ (e.getMessage() == null ? "" : ":"
									+ e.getMessage()));
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
			// throw new Exception("��������������");
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				ARE.getLog().error("���ݿ�ر�ʧ��:" + e.getMessage());
				e.printStackTrace();
			}
		}
		return response;

	}

	// ������Ƭ�����б�
	private ArrayList<byte[]> createPhotoDataList(String photodatas)
			throws Exception {
		String[] photoDatas = photodatas.split("\\,");
		ArrayList<byte[]> photoDatalist = new ArrayList<byte[]>();
		for (int i = 0; i < photoDatas.length; i++)
			photoDatalist.add(Base64.decode(photoDatas[i]));
		return photoDatalist;
	}

	// ���ͼ��
	private static boolean isIntegerNumber(String number) {
		number = number.trim();
		String intNumRegex = "\\-{0,1}\\d+";
		if(number.equals("")){
			return true;
		}
		if (number.matches(intNumRegex))
			return true;
		else {
			return false;
		}
	}

	// �����ͼ��
	private static boolean isFloatPointNumber(String number) {
		number = number.trim();
		String pointPrefix = "(\\-|\\+){0,1}\\d*\\.\\d+";
		String pointStuffix = "(\\-|\\+){0,1}\\d*\\.";
		if(number.equals("")){
			return true;
		}
		if (number.matches(pointPrefix) || number.matches(pointStuffix)) {
			return true;
		} else {
			return false;
		}
	}

}
