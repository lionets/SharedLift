package com.amarsoft.webservice.proj.nh.accredit;

import java.sql.Connection;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.DBHandler;

/**
 * ��Ȩ�б� 
 * ���������
 *  
 * CurPage-����ҳ�� 
 * PrageSize-��������
 * 
 * ���������
 * 
 * @author jyli
 * 
 */
public class AccreditListHandler extends DBHandler {

	private int CurPage;
	private int PageSize;

	protected Object createReponseWithDB(JSONObject request, Properties arg1,
			Connection conn) throws Exception {
		conn = null;
		if (request.containsKey("CurPage")) {
			this.CurPage = Integer.parseInt(request.get("CurPage").toString());

		}
		if (request.containsKey("PageSize"))
			this.PageSize = Integer
					.parseInt(request.get("PageSize").toString());

		try {
			conn = ARE.getDBConnection("als");
			JSONObject response = new JSONObject();
			JSONArray result = new JSONArray();
			for (int i = 0; i < PageSize; i++) {
				JSONObject obj = new JSONObject();
				obj.put("AccreditOrgName", "�Ϻ�֧��" + i);
				obj.put("CustomerName", "�Ϻ�ĳ��ҵA-" + i);
				obj.put("BusinessType", "1383838383-" + i);
				obj.put("CreditMoney", "1383838383-" + i);
				obj.put("Process", "XXXXX" + i);
				result.add(obj);
			}
			response.put("array", result);
			return response;
		} catch (Exception e) {
			throw new Exception("��������ʧ��");
		} finally {
			if (conn != null)
				conn.close();

		}

	}

}
