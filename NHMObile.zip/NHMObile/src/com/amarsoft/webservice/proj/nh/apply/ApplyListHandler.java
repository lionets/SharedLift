package com.amarsoft.webservice.proj.nh.apply;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;
/**
 * �����б������ձ�ҵ��
 * ���������
 * PageSize ÿҳ��ʾ������
 * CurPage  ���ص�ҳ��
 * BStatus  01-���������� 02-������������� 03-�˻ز���������� 04-����ͨ������  05-�ѷ������
 * SearchKey:��ѯ���������Ž��/�ͻ�����)
 * 

 * ���������
 * ApplyNo-������[��Ӧ�ύʱѡ�����˵�ObjectNo]
 * FlowTaskNo - ������ˮ�� //add 20140227
 * CustomerName-�ͻ�����
 * CustomerNo - �ͻ����
 * BusinessTypeName-ҵ������
 * BusinessSum-���Ž��
 * TempSaveFlag - �ݴ�״̬���ݴ�״̬�¼�1�������ύ���룩
 * ArrayPayWay - ���ʽ�����ֵ�//add 20140328
 *     CodeNo 
 *     CodeName 
 * //add 20140220	
		TempSaveFlag=1 	�����ύ����
		TempSaveFlag=2���ܹ��ύ����
		//end

 * @author jyli
 *
 */

public class ApplyListHandler extends JSONHandlerWithSession {
	private int pageSize = 20;
	private String BStatus = "01";
	private int CurPage=0;
	
	private String SearchKey = "";
	
	private static String NEED_HANDLER_APPLY = "1010";
	private static String IN_HANDLER_APPLY = "1020";
	private static String BACK_HANDLER_APPLY = "1030";
	private static String PASS_HANDLER_APPLY = "1040";
	private static String NO_HANDLER_APPLY = "1050";
	
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub

		Connection conn = null;
		JSONObject response = new JSONObject();
		if(request.containsKey("BStatus")){
		  this.BStatus=request.get("BStatus").toString();
		}
		if(request.containsKey("PageSize"))
			this.pageSize = Integer.parseInt(request.get("PageSize").toString());
		if(request.containsKey("CurPage"))
			this.CurPage = Integer.parseInt(request.get("CurPage").toString());
		if(request.containsKey("SearchKey"))//��ѯ����
			this.SearchKey = request.get("SearchKey").toString();
		
		String sUserId = SessionManager.getUserId(this.getSessionKey());//�û���
		//�����б�
		String sSql =   " select BA.CustomerName as CustomerName,BA.BusinessSum as BusinessSum," +
						" BA.CustomerID as CustomerNo," +
						" BA.BusinessType,getBusinessName(BA.BusinessType) as BusinessTypeName," +
						" BA.SerialNo as ApplyNo,BA.TempSaveFlag as TempSaveFlag " +
						" from FLOW_OBJECT FO,BUSINESS_APPLY BA " +
						" where BA.BusinessType = '5020090' and FO.OBJECTTYPE= 'SmallApply' and FO.ApplyType = 'SmallApply' " +//alert 20140317
						" and FO.ObjectNo = BA.SerialNo "+
			            " and FO.PhaseType=?  "+ 
						" and BA.PigeonholeDate is null "+//δ�鵵
						" and FO.UserID=?";
		
		if(isNum(SearchKey)&&!(SearchKey.equals(""))){//��ѯ�������ͻ����ƺ����Ž�����ѯ����Ϊ�����������ͻ����ƺ����Ž��
			String sWhereClause1 = " and (BA.CustomerName like '%"+SearchKey+"%' or BA.BusinessSum = "+SearchKey+")";
			sSql+=sWhereClause1;
		}
		else {//��ѯ����Ϊ������������ֻ��ͻ�����
			String sWhereClause1 = " and BA.CustomerName like '%"+SearchKey+"%' ";
			sSql+=sWhereClause1;
		}
		String sOrderClause1 = " order by BA.SerialNo desc";
		sSql+=sOrderClause1;
		
		//�ύʹ�õ���ˮ��add 20140326
		String sGetFlowTaskNo = " select max(serialno) as FlowTaskNo from flow_task where objectno = ? and objecttype=?";
		//add 20140328
		String sPayWay = " select itemno,itemname from code_library where codeno = ? and isinuse='1'";
		
		//���ʱ�����
		String rate = " select RateType,Term,Rate from rate_info";
		try {
			conn= ARE.getDBConnection("als");
			Pageable.setDBType("DB2");
			JSONArray result = new JSONArray();
			sSql = Pageable.getPageable().getPagedSqlByPageNum(sSql, this.CurPage, this.pageSize);
			ARE.getLog().info(sSql);
			PreparedStatement ps = conn.prepareStatement(sSql);
			if(BStatus.equals("01")){
				ps.setString(1, NEED_HANDLER_APPLY);
			}
			else if(BStatus.equals("02")){
				ps.setString(1, IN_HANDLER_APPLY);
			}
			else if(BStatus.equals("03")) {
				ps.setString(1, BACK_HANDLER_APPLY);
			}
			else if(BStatus.equals("04")) {
				ps.setString(1, PASS_HANDLER_APPLY);
			}
			else if(BStatus.equals("05")){
				ps.setString(1, NO_HANDLER_APPLY);
			}
			else{
				ARE.getLog().info(BStatus);
				throw new Exception("����׶�ȡֵ������");
			}
			ps.setString(2, sUserId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				JSONObject obj = new JSONObject();
				obj.put("ApplyNo", rs.getString("ApplyNo"));//�����ţ������ţ�
				obj.put("CustomerName", rs.getString("CustomerName"));
				obj.put("CustomerNo", rs.getString("CustomerNo"));
				obj.put("BusinessTypeName", rs.getString("BusinessTypeName"));
				obj.put("BusinessSum", (new DecimalFormat("#0.00").format(rs.getDouble("BusinessSum")/10000))+"��Ԫ");
				obj.put("TempSaveFlag", rs.getDouble("TempSaveFlag")+"");
				PreparedStatement psSerialno = conn.prepareStatement(sGetFlowTaskNo);
				psSerialno.setString(1, rs.getString("ApplyNo"));
				psSerialno.setString(2, "SmallApply");
				ResultSet rsSerialno = psSerialno.executeQuery();
				if (rsSerialno.next()) {
					obj.put("FlowTaskNo", rsSerialno.getString("FlowTaskNo"));//������ˮ��
				}
				rsSerialno.getStatement().close();
				result.add(obj);
			}
			rs.getStatement().close();
			
			//add 20140328
			JSONArray arrayPayWay = new JSONArray();
			PreparedStatement psPayWay = conn.prepareStatement(sPayWay);
			psPayWay.setString(1, "CorpusPayMethod2");
			ResultSet rsPayWay = psPayWay.executeQuery();
			while(rsPayWay.next()){
				JSONObject obje = new JSONObject();
				obje.put("CodeNo", rsPayWay.getString("itemno"));
				obje.put("CodeName", rsPayWay.getString("itemname"));
				arrayPayWay.add(obje);
			}
			rsPayWay.getStatement().close();
			response.put("ArrayPayWay", arrayPayWay);
			//end
			
			//begin ldfang 20140527
			JSONArray arrayBaseRate = new JSONArray();
			PreparedStatement psBaseRate = conn.prepareStatement(sPayWay);
			psBaseRate.setString(1, "BaseRateType");
			ResultSet rsBaseRate = psBaseRate.executeQuery();
			while(rsBaseRate.next()){
				JSONObject obje = new JSONObject();
				obje.put("CodeNo", rsBaseRate.getString("itemno"));
				obje.put("CodeName", rsBaseRate.getString("itemname"));
				arrayBaseRate.add(obje);
			}
			rsBaseRate.getStatement().close();
			response.put("ArrayBaseRate", arrayBaseRate);
			
			JSONArray arrayRateFloat = new JSONArray();
			PreparedStatement psRateFloat = conn.prepareStatement(sPayWay);
			psRateFloat.setString(1, "RateFloatType");
			ResultSet rsRateFloat = psRateFloat.executeQuery();
			while(rsRateFloat.next()){
				JSONObject obje = new JSONObject();
				obje.put("CodeNo", rsRateFloat.getString("itemno"));
				obje.put("CodeName", rsRateFloat.getString("itemname"));
				arrayRateFloat.add(obje);
			}
			rsRateFloat.getStatement().close();
			response.put("ArrayRateFloat", arrayRateFloat);
			
			PreparedStatement psrate = conn.prepareStatement(rate);
			ARE.getLog().info(rate);
			JSONArray rateArray = new JSONArray();
			ResultSet rsrate = psrate.executeQuery();
			while(rsrate.next()){
				JSONObject object = new JSONObject();
				object.put("RateType", rsrate.getString("RateType"));
				object.put("Term", rsrate.getInt("Term"));
				object.put("Rate", (new DecimalFormat("#0.00").format(rsrate.getDouble("Rate"))));
				rateArray.add(object);
			}
			response.put("ArrayRate", rateArray);
			rsrate.getStatement().close();
			//end 20140527
			//add 20140328
			JSONArray arrayCurrency = new JSONArray();
			PreparedStatement psCurrency = conn.prepareStatement(sPayWay);
			psCurrency.setString(1, "Currency");
			ResultSet rsCurrency = psCurrency.executeQuery();
			while(rsCurrency.next()){
				JSONObject obje = new JSONObject();
				obje.put("CodeNo", rsCurrency.getString("itemno"));
				obje.put("CodeName", rsCurrency.getString("itemname"));
				arrayCurrency.add(obje);
			}
			rsCurrency.getStatement().close();
			response.put("ArrayBusinessCurrency", arrayCurrency);
			
			
			
			response.put("array", result);	
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		finally{
			try{
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	
	}
	//�ж��ַ��������Ƿ���������С��
	private static boolean isNum(String s){
		char dot = '.';
		int c=0;
		for (int i = 0; i < s.length(); i++) {
			if(s.charAt(i)==dot){
				c++;
			}
		}
		if(c<=1&&(s.matches("[-+]?[0-9/.]*"))){
			return true;
		}
		else {
			return false;
		}
	}

}
