/**
 * 
 */
package com.amarsoft.webservice.proj.nh.customerarray;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;

/**
 * @author Administrator
 * �����ֵ䣺����CodeNo CodeName
 */
public class CustomerNativePlaceHandler extends JSONHandlerWithSession{

	
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		JSONObject response = new JSONObject();
		try {
			    conn = ARE.getDBConnection("als");
				String sSql = "select itemno,itemname from code_library where codeno=? and IsInuse = '1'";
				PreparedStatement psCode = conn.prepareStatement(sSql);
				psCode.setString(1, "AreaCode");
				ARE.getLog().info(sSql);
				JSONArray array = new JSONArray();
				ResultSet rsCode = psCode.executeQuery();
				while(rsCode.next()){
					JSONObject object = new JSONObject();
					object.put("CodeNo", rsCode.getString("itemno"));
					object.put("CodeName", rsCode.getString("itemname"));
					array.add(object);
				}
				rsCode.getStatement().close();
				response.put("ArrayNativePlace", array);
			}
		catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	
	}

}
