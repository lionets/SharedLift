/**
 * 
 */
package com.amarsoft.webservice.proj.nh;

/**
 * @author Administrator
 * ������ʾ��
 */
public class WorkTipMessageContent {
	// ���������Ŵ�ҵ������1
	private String sql0 = "select count(BA.SerialNo) as count from BUSINESS_APPLY BA,FLOW_TASK FT where BA.SerialNo = FT.ObjectNo and FT.ObjectType='CreditApply' "
			+ "and FT.UserID=? and (FT.EndTime is null or FT.EndTime = ' ') and (FT.PhaseAction is null or FT.PhaseAction = ' ')";

	private String sq100 = "select '[�ͻ����: '||BA.CustomerID||' ] [�ͻ�����:'||BA.CustomerName||']'||' ['||nvl(getItemName('OccurType',OccurType),'')||']'||' ['||nvl(getBusinessName(BusinessType),'')||']  ['||nvl(getItemName('Currency',BusinessCurrency),'')||']'  as detail,nvl(BA.BusinessSum,0) as BUSINESSSUM,FT.ApplyType,"
			+ " FT.BeginTime,FT.PhaseName as PhaseName,"
			+ "FT.PhaseNo,FT.PhaseType from BUSINESS_APPLY BA,FLOW_TASK FT where BA.SerialNo = FT.ObjectNo and FT.ObjectType='CreditApply' and FT.UserID=? and (FT.EndTime is null or FT.EndTime = ' ') "
			+ "and (FT.PhaseAction is null or FT.PhaseAction = ' ') order by FT.ApplyType,FT.begintime";

	// �������Ĺ����ƻ�2
	private String sql1 = "select count(SerialNo) as count from"
			+ " WORK_RECORD W where W.PromptBeginDate <=? and W.PromptEndDate >=? "
			+ " and (W.ActualFinishDate is null or W.ActualFinishDate=' ') and W.OperateUserID =?";

	private String sql10 = "select W.SerialNo,'['|| GetItemName('WorkType',WorkType) ||']'||' [ ������ʾ����:'|| W.PromptEndDate || ']' as detail,W.WorkBrief,W.PlanFinishDate,W.ActualFinishDate,getOrgName(W.OperateOrgID) as OrgName,getUserName(W.OperateUserID) as UserName,Importance,Urgency "
			+ "from WORK_RECORD W where W.PromptBeginDate <=? and W.PromptEndDate >=? and (W.ActualFinishDate is null or W.ActualFinishDate=' ') and W.OperateUserID =? ";
	// �������� ���õȼ�����3

	private String sql2 = "select count(ER.SerialNo) as count from "
			+ "EVALUATE_RECORD ER,FLOW_TASK FT where ER.SerialNo = FT.ObjectNo and (ER.ModelNo like '0%' ) and FT.ObjectType='Customer' and FT.UserID=? and (FT.EndTime is null or FT.EndTime = ' ') and (FT.PhaseAction is null or FT.PhaseAction = ' ')";

	private String sql20 = "select  nvl(getModelame(ER.ModelNo),'')||' [�ͻ���ţ�'||ER.ObjectNo||']'||' ['||nvl(getCustomerName(ER.ObjectNo),'')||']'||' [�����·ݣ�'||ER.ACCOUNTMONTH||']'||' [ϵͳ���������'||ER.EVALUATERESULT||']'  as detail,FT.ApplyType,FT.BeginTime,FT.PhaseName,FT.PhaseNo,FT.PhaseType from "
			+ "EVALUATE_RECORD ER,FLOW_TASK FT where ER.SerialNo = FT.ObjectNo and (ER.ModelNo like '0%' ) and FT.ObjectType='Customer' and FT.UserID=? and (FT.EndTime is null or FT.EndTime = ' ') and (FT.PhaseAction is null or FT.PhaseAction = ' ') order by ER.ModelNo,FT.BeginTime";

	// ���ǼǺ�ͬ������4
	private String sql30 = "select getBusinessName(BA.BusinessType)||'['||BA.CustomerName||']'as detail,nvl(BA.BusinessSum,0) as BusinessSum,BA.OccurDate from BUSINESS_APPROVE BA where OperateUserID =? and ApproveType = '01' and SerialNo in (select ObjectNo from FLOW_OBJECT FO where FlowNo='ApproveFlow' and PhaseNo='1000') and flag5 = '010'";

	private String sql3 = "select count(*) as count from BUSINESS_APPROVE BA where OperateUserID =? and ApproveType = '01' and SerialNo in (select ObjectNo from FLOW_OBJECT FO where FlowNo='ApproveFlow' and PhaseNo='1000') and flag5 = '010'";

	// ������������5
	private String sql4 = "select count(*)  as count from "
			+ "BUSINESS_APPROVE BA,FLOW_TASK FT where BA.SerialNo=FT.ObjectNo and FT.ApplyType='ApproveApply' and FT.UserID=? and (FT.EndTime is null or FT.EndTime = ' ') and (FT.PhaseAction is null or FT.PhaseAction = ' ')";

	private String sql40 = "select getBusinessName(BA.BusinessType)||' ['||BA.CustomerName||']'||' ['||FT.PhaseName||']'  as detail,nvl(BA.BusinessSum,0) as BusinessSum,FT.BeginTime,FT.PhaseName,FT.PhaseNo,FT.PhaseType "
			+ "from BUSINESS_APPROVE BA,FLOW_TASK FT where BA.SerialNo=FT.ObjectNo and FT.ApplyType='ApproveApply' and FT.UserID=? and (FT.EndTime is null or FT.EndTime = ' ') and (FT.PhaseAction is null or FT.PhaseAction = ' ')";

	// �������ķſ�6
	private String sql5 = " select count(BP.SerialNo) as count from "
			+ "BUSINESS_PUTOUT BP,FLOW_TASK FT where BP.SerialNo=FT.ObjectNo and FT.ObjectType='PutOutApply' and FT.UserID=? and (FT.EndTime is null or FT.EndTime = ' ') and (FT.PhaseAction is null or FT.PhaseAction = ' ')";

	private String sql50 = "select nvl(getBusinessName(BP.BusinessType),'')||'  ['||BP.CustomerID||']'||'  ['||BP.CustomerName||']'||' ['||nvl(getItemName('Currency',BusinessCurrency),'')||']' as detail,nvl(BP.BusinessSum,0) as BusinessSum,FT.BeginTime,FT.PhaseName,FT.PhaseNo,FT.PhaseType from "
			+ "BUSINESS_PUTOUT BP,FLOW_TASK FT where BP.SerialNo=FT.ObjectNo and FT.ObjectType='PutOutApply' and FT.UserID=? and (FT.EndTime is null or FT.EndTime = ' ') and (FT.PhaseAction is null or FT.PhaseAction = ' ')";
	// ���ǼǺ�ͬ������7
	private String sql6 = "select count(SerialNo) as count from BUSINESS_APPLY BA "
			+ " where OperateUserID =? and "
			+ " SerialNo in (select ObjectNo from FLOW_OBJECT FO where FlowNo='CreditFlow' and PhaseNo='1000') and flag5 = '010'";
	private String sql60 = "select getBusinessName(BA.BusinessType)||'  ['||BA.CustomerName||'] ' as detail,nvl(BA.BusinessSum,0) as BusinessSum "
			+ " from BUSINESS_APPLY BA "
			+ " where OperateUserID =? and SerialNo in (select ObjectNo from FLOW_OBJECT FO where FlowNo='CreditFlow' and PhaseNo='1000') and flag5 = '010'";

	// �������Ŵ����ݱ��(��ȷ��)8
	private String sql7 = " select count(SerialNo) as count from MODIFY_READYAPPLY where Tips = '1'";
	private String sql70 = " select CustomerName,Flag  from MODIFY_READYAPPLY where Tips = '1'";
	// ��������������������9
	private String sql8 = " select count(BA.SerialNo) as count from APPROVE_CHANGE BA,FLOW_TASK FT "
			+ " where BA.SerialNo=FT.ObjectNo and FT.ApplyType='CreditApplyChange' "
			+ " and FT.UserID=? and (FT.EndTime is null or FT.EndTime = ' ') and (FT.PhaseAction is null or FT.PhaseAction = ' ')";
	private String sql80 = "select nvl(getBusinessName(BA.BusinessType),'')||'  [�ͻ���ţ�'||BA.CustomerID||']'||'  [�ͻ����ƣ�'||BA.CustomerName||']'  as detail,nvl(BA.BusinessSum,0) as BusinessSum,FT.BeginTime,FT.PhaseName,FT.PhaseNo,FT.PhaseType,FT.ApplyType "
			+ " from APPROVE_CHANGE BA, FLOW_TASK FT"
			+ " where BA.SerialNo=FT.ObjectNo  and FT.ApplyType='CreditApplyChange'  and FT.UserID=? "
			+ " and (FT.EndTime is null  or FT.EndTime = ' ')  and (FT.PhaseAction is null  or FT.PhaseAction = ' ')";
	// �������ı��շ�ά������10
	private String sql9 = " select count(SerialNo) as count from PREMIUM_INCOME_INFO where InputUserID =? and ApproveStatus='020'";
	private String sql90 = " select '[�ͻ���ţ�'||CustomerID||']'||'  [�ͻ����ƣ�'||getCustomerName(CustomerID)||']' as detail,InsurancePolicyID,InsuranceAmount,InputDate"
			+ " from PREMIUM_INCOME_INFO where InputUserID =? and ApproveStatus='020'";

	// �������Ŀͻ�Ȩ������ 11
	private String sql100 = " select count(BA.SerialNo) as count "
			+ " from CUSRIGHT_APPLY BA,FLOW_TASK FT "
			+ " where BA.SerialNo=FT.ObjectNo and FT.ApplyType='CusRightApply' "
			+ " and FT.ObjectType='CustomerRight' and FT.UserID=? and FT.PhaseType<>'1010' "
			+ " and (FT.EndTime is null or FT.EndTime = ' ') "
			+ " and (FT.PhaseAction is null or FT.PhaseAction = ' ')";
	private String sql101 = " select ' [�ͻ���ţ�'||BA.CustomerID||']'||'  [�ͻ����ƣ�'||BA.CustomerName||']'||' [�����ˣ�'||getUserName(BA.inputuserid)||']' as detail,"
			+ " nvl(0,0),FT.BeginTime,FT.PhaseName,FT.PhaseNo,FT.PhaseType,FT.ApplyType "
			+ " from CUSRIGHT_APPLY BA, FLOW_TASK FT "
			+ " where BA.SerialNo=FT.ObjectNo  and FT.ApplyType='CusRightApply' "
			+ " and FT.ObjectType='CustomerRight'  and FT.UserID=? "
			+ " and FT.PhaseType<>'1010'  and (FT.EndTime is null  or FT.EndTime = ' ')  and (FT.PhaseAction is null  or FT.PhaseAction = ' ') ";

	// ��������Ԥ���ź�12
	private String sql110 = " select count(BA.SerialNo) as count from RISK_SIGNAL BA, FLOW_TASK FT  "
			+ " where BA.SerialNo=FT.ObjectNo  and FT.ApplyType='RiskSignalApply'  "
			+ " and FT.ObjectType='RiskSignalApply'  and FT.UserID=? "
			+ " and FT.PhaseType<>'1010'  and (FT.EndTime is null  or FT.EndTime = ' ')  and (FT.PhaseAction is null  or FT.PhaseAction = ' ')";
	private String sql111 = " select '  [�ͻ���ţ�'||BA.CustomerID||']'||'  [�ͻ����ƣ�'||BA.CustomerName||']'||'  [�����ˣ�'||getUserName(BA.inputuserid)||']' as detail,nvl(0,0),FT.BeginTime,FT.PhaseName,FT.PhaseNo,FT.PhaseType,FT.ApplyType "
			+ " from RISK_SIGNAL BA,FLOW_TASK FT where BA.SerialNo=FT.ObjectNo and FT.ApplyType='RiskSignalApply' and FT.ObjectType='RiskSignalApply' "
			+ " and FT.UserID=? and FT.PhaseType<>'1010' and (FT.EndTime is null or FT.EndTime = ' ') and (FT.PhaseAction is null or FT.PhaseAction = ' ')";

	// ����⹤������13
	private String sql120 = " select count(SerialNo) as count from guaranty_output "
			+ " where reputdate <= replace((date(to_char(sysdate,'yyyy-MM-DD')) +15 days ),'-','/')"
			+ " and InputUser =? and InputOrg =?";

	private String sql121 = "  select ' [��ˮ�ţ�'||SerialNo || ']' ||' [��Ѻ�����ƣ�'||outputdescribe||']' as detail,serialno,reputdate from guaranty_output "
			+ "  where reputdate <= replace((date(to_char(sysdate,'yyyy-MM-DD')) +15 days ),'-','/')"
			+ "  and InputUser =? and InputOrg =?";

	// ���Ǽ������������������14
	private String sql130 = "select count(distinct BA.SerialNo) as count "
			+ "from BUSINESS_APPLY BA,FLOW_OBJECT FO,FLOW_TASK FT where BA.SerialNo=FO.ObjectNo and BA.SerialNo=FT.ObjectNo and FO.ObjectType='CreditApply' "
			+ "and (FO.PhaseNo='1000' or FO.PhaseNo= '8000')  and BA.OperateOrgID in (select OrgID from ORG_INFO where SortNo like ?) and BA.FLAG5='010' "
			+ "and BA.OperateUserID =?";

	private String sql131 = "select getBusinessName(BA.BusinessType)||' ['||BA.CustomerName||']'||' ' as detail,nvl(BA.BusinessSum,0) as BusinessSum "
			+ "from BUSINESS_APPLY BA,FLOW_OBJECT FO,FLOW_TASK FT where BA.SerialNo=FO.ObjectNo and BA.SerialNo=FT.ObjectNo and FO.ObjectType='CreditApply' "
			+ "and (FO.PhaseNo='1000' or FO.PhaseNo= '8000')  and BA.OperateOrgID in (select OrgID from ORG_INFO where SortNo like ?) and BA.FLAG5='010' "
			+ "and BA.OperateUserID =? and FT.SerialNo = (select MAX(FTT.SerialNo) from FLOW_TASK FTT where FTT.ObjectType='CreditApply' and FTT.ObjectNo=BA.SerialNo)";
	// ��������֧��15
	private String sql140 = " select count(PI.SerialNo) as count "
			+ " from PAYMENT_INFO PI, FLOW_TASK FT "
			+ " where PI.SerialNo=FT.ObjectNo "
			+ " and FT.ObjectType='PaymentApply' " + " and FT.UserID=? "
			+ " and (FT.EndTime is null " + " or FT.EndTime = ' ') "
			+ " and (FT.PhaseAction is null " + " or FT.PhaseAction = ' ') ";
	private String sql141 = " select '['||PI.CustomerName||']'||'  ['||FT.PhaseName||']' as detail,nvl(PI.PaymentSum,0) as BusinessSum "
			+ " from PAYMENT_INFO PI, FLOW_TASK FT "
			+ " where PI.SerialNo=FT.ObjectNo "
			+ " and FT.ObjectType='PaymentApply' "
			+ " and FT.UserID=? "
			+ " and (FT.EndTime is null "
			+ " or FT.EndTime = ' ') "
			+ " and (FT.PhaseAction is null " + " or FT.PhaseAction = ' ') ";

	// �����ʲ���ȫ�����ʼ�16
	private String sql150 = "select count(nc.SerialNo) as count "
			+ "from WORK_RECORD wr,NPA_CHANGEUSER nc where wr.ObjectNo=nc.SerialNo and wr.PROMPTBEGINDATE <=? and wr.PROMPTENDDATE >=? and wr.PROMPTENDDATE<> null";

	private String sql151 = "select  '[�ƽ�����ţ�'||nc.SerialNo||']'||'  [�ͻ���ţ�'||nc.CustomerID||']'||'  [�ͻ����ƣ�'||nc.CustomerName||']'||'  [����ժҪ��'||wr.WorkBrief||']' as detail,nc.SerialNo,nc.CustomerID,nc.CustomerName,wr.WorkBrief "
			+ "from WORK_RECORD wr,NPA_CHANGEUSER nc where wr.ObjectNo=nc.SerialNo and wr.PROMPTBEGINDATE <=? and wr.PROMPTENDDATE >=? and wr.PROMPTENDDATE<> null";

	// ��������¥��׼������17
	private String sql160 = "select count(BUILDINGPLATE_ACCESS_APPLY.SerialNo) as count "
			+ " from FLOW_TASK,BUILDINGPLATE_ACCESS_APPLY where FLOW_TASK.ObjectNo = BUILDINGPLATE_ACCESS_APPLY.SerialNo"
			+ " and FLOW_TASK.ObjectType =  'BuildingPlate' and  FLOW_TASK.phaseType='1020' and FLOW_TASK.UserID=?"
			+ " and (FLOW_TASK.EndTime is  null  or  FLOW_TASK.EndTime = '')";;

	private String sql161 = " select '����¥��  '||nvl(getBPNameBySerialNo(BUILDINGPLATE_ACCESS_APPLY.BUILDINGPLATENO),'')||'  ������' as detail,FLOW_TASK.ApplyType,FLOW_TASK.PhaseName,FLOW_TASK.PhaseNo,FLOW_TASK.PhaseType "
			+ " from FLOW_TASK,BUILDINGPLATE_ACCESS_APPLY where FLOW_TASK.ObjectNo = BUILDINGPLATE_ACCESS_APPLY.SerialNo"
			+ " and FLOW_TASK.ObjectType =  'BuildingPlate' and  FLOW_TASK.phaseType='1020' and FLOW_TASK.UserID=?"
			+ " and (FLOW_TASK.EndTime is  null  or  FLOW_TASK.EndTime = '')  order by BUILDINGPLATE_ACCESS_APPLY.SerialNo";

	// ��������С΢ҵ����������18
	private String sql170 = " select count(FLOW_TASK.ObjectType) as count "
			+ "from FLOW_TASK,BUSINESS_APPLY where  FLOW_TASK.ObjectType =  'SmallApply'  and  FLOW_TASK.ObjectNo = BUSINESS_APPLY.SerialNo"
			+ " and FLOW_Task.FlowNo='SmallFlow' and FLOW_TASK.UserID=?  and (FLOW_TASK.EndTime is  null  or  FLOW_TASK.EndTime = '') ";

	private String sql171 = " select '����С΢ҵ��ͻ�: '||nvl(BUSINESS_APPLY.CustomerName,'')||'  ������' as detail,FLOW_TASK.ApplyType,FLOW_TASK.PhaseName,FLOW_TASK.PhaseNo,FLOW_TASK.PhaseType  "
			+ "from FLOW_TASK,BUSINESS_APPLY where  FLOW_TASK.ObjectType =  'SmallApply'  and  FLOW_TASK.ObjectNo = BUSINESS_APPLY.SerialNo"
			+ " and FLOW_Task.FlowNo='SmallFlow' and FLOW_TASK.UserID=?  and (FLOW_TASK.EndTime is  null  or  FLOW_TASK.EndTime = '') "
			+ " order by FLOW_TASK.ObjectNo desc";

	// �����������/���������19
	private String sql180 = " select count(GUARANTY_OUTPUT.SerialNo) as count "
			+ " From GUARANTY_OUTPUT,FLOW_OBJECT,FLOW_TASK  Where FLOW_OBJECT.ObjectNo=GUARANTY_OUTPUT.SerialNo "
			+ " and FLOW_OBJECT.ObjectNo=FLOW_TASK.ObjectNo and FLOW_OBJECT.ObjectType =  'OutInApply' "
			+ "	 and FLOW_OBJECT.FlowNo='OutInFlowOne'  and FLOW_TASK.FlowNo=FlOW_OBJECT.FlowNo "
			+ "  and FLOW_TASK.UserID=? "
			+ "and (FLOW_TASK.EndTime is  null  or  FLOW_TASK.EndTime = '')";

	private String sql181 = " select ' [�����������ˮ�� ��'||nvl(GUARANTY_OUTPUT.SERIALNO,'')||'] '||nvl(getItemName('OutPutType',OUTPUTTYPE),'')||' ������!' as detail,FLOW_TASK.ApplyType,FLOW_TASK.PhaseName,FLOW_TASK.PhaseNo,FLOW_TASK.PhaseType "
			+ " From GUARANTY_OUTPUT,FLOW_OBJECT,FLOW_TASK  Where FLOW_OBJECT.ObjectNo=GUARANTY_OUTPUT.SerialNo "
			+ " and FLOW_OBJECT.ObjectNo=FLOW_TASK.ObjectNo and FLOW_OBJECT.ObjectType =  'OutInApply' "
			+ "	 and FLOW_OBJECT.FlowNo='OutInFlowOne'  and FLOW_TASK.FlowNo=FlOW_OBJECT.FlowNo "
			+ "  and FLOW_TASK.UserID=? "
			+ "and (FLOW_TASK.EndTime is  null  or  FLOW_TASK.EndTime = '')  order by FLOW_TASK.ObjectNo desc";

	// ����������ʽ��������20
	private String sql190 = "select count(GUARANTY_OUTPUT.SerialNo) as count "
			+ "From GUARANTY_OUTPUT,FLOW_OBJECT,FLOW_TASK Where 1=1  and FLOW_OBJECT.ObjectNo=GUARANTY_OUTPUT.SerialNo  "
			+ " and FLOW_OBJECT.ObjectNo=FLOW_TASK.ObjectNo and FLOW_OBJECT.ObjectType =  'OutInApply' "
			+ "	 and FLOW_OBJECT.FlowNo='OutInFlowTwo'  and FLOW_TASK.FlowNo=FlOW_OBJECT.FlowNo "
			+ "  and FLOW_TASK.UserID=? "
			+ "and (FLOW_TASK.EndTime is  null  or  FLOW_TASK.EndTime = '')";
	private String sql191 = "select ' [�����������ˮ�� ��'||nvl(GUARANTY_OUTPUT.SERIALNO,'')||'] '||nvl(getItemName('OutPutType',OUTPUTTYPE),'')||' ������!' as detail,FLOW_TASK.ApplyType,FLOW_TASK.PhaseName,FLOW_TASK.PhaseNo,FLOW_TASK.PhaseType  "
			+ "From GUARANTY_OUTPUT,FLOW_OBJECT,FLOW_TASK Where 1=1  and FLOW_OBJECT.ObjectNo=GUARANTY_OUTPUT.SerialNo  "
			+ " and FLOW_OBJECT.ObjectNo=FLOW_TASK.ObjectNo and FLOW_OBJECT.ObjectType =  'OutInApply' "
			+ "	 and FLOW_OBJECT.FlowNo='OutInFlowTwo'  and FLOW_TASK.FlowNo=FlOW_OBJECT.FlowNo "
			+ "  and FLOW_TASK.UserID=? "
			+ "and (FLOW_TASK.EndTime is  null  or  FLOW_TASK.EndTime = '') order by FLOW_TASK.ObjectNo desc";

	// ����������ʱ��������21
	private String sql200 = " select count(GUARANTY_OUTPUT.SerialNo) as count "
			+ "From GUARANTY_OUTPUT,FLOW_OBJECT,FLOW_TASK Where FLOW_OBJECT.ObjectNo=GUARANTY_OUTPUT.SerialNo  "
			+ " and FLOW_OBJECT.ObjectNo=FLOW_TASK.ObjectNo and FLOW_OBJECT.ObjectType =  'OutInApply' "
			+ "	 and FLOW_OBJECT.FlowNo='OutInFlowThree'  and FLOW_TASK.FlowNo=FlOW_OBJECT.FlowNo "
			+ "  and FLOW_TASK.UserID=? "
			+ "and (FLOW_TASK.EndTime is  null  or  FLOW_TASK.EndTime = '')";
	private String sql201 = " select ' [�����������ˮ�� ��'||nvl(GUARANTY_OUTPUT.SERIALNO,'')||']  '||nvl(getItemName('OutPutType',OUTPUTTYPE),'')||' ������!' as detail,FLOW_TASK.ApplyType,FLOW_TASK.PhaseName,FLOW_TASK.PhaseNo,FLOW_TASK.PhaseType "
			+ "From GUARANTY_OUTPUT,FLOW_OBJECT,FLOW_TASK Where FLOW_OBJECT.ObjectNo=GUARANTY_OUTPUT.SerialNo  "
			+ " and FLOW_OBJECT.ObjectNo=FLOW_TASK.ObjectNo and FLOW_OBJECT.ObjectType =  'OutInApply' "
			+ "	 and FLOW_OBJECT.FlowNo='OutInFlowThree'  and FLOW_TASK.FlowNo=FlOW_OBJECT.FlowNo "
			+ "  and FLOW_TASK.UserID=? "
			+ "and (FLOW_TASK.EndTime is  null  or  FLOW_TASK.EndTime = '') order by FLOW_TASK.ObjectNo desc";

	// ��������ѹ���˳���ά������22
	private String sql210 = "select count(RA.SerialNo) as count "
			+ " from FLOW_OBJECT FO,REDUCE_QUIT_APPLY  RA where  FO.ObjectType =  'ReduceQuitApply'  "
			+ " and  FO.ObjectNo = RA.SerialNo  "
			+ " and FO.PhaseType='1010'  and FO.ApplyType='ReduceQuitApply'  "
			+ " and FO.UserID=? ";

	private String sql211 = " select ' [�ͻ���ţ�'||RA.CustomerID||']'||' [�ͻ����ƣ�'||RA.CustomerName||']'||' [�����ˣ�'||getUserName(RA.inputuserid)||']' as detail,FO.APPLYTYPE,FO.PHASETYPE ,FO.PHASENAME"
			+ " from FLOW_OBJECT FO,REDUCE_QUIT_APPLY  RA where  FO.ObjectType =  'ReduceQuitApply'  "
			+ " and  FO.ObjectNo = RA.SerialNo  "
			+ " and FO.PhaseType='1010'  and FO.ApplyType='ReduceQuitApply'  "
			+ " and FO.UserID=? order by RA.SerialNo desc ";
	// ����Ч�ĵǼǺ�ͬ23
	private String sql220 = "  select count(SerialNo)  as count "
			+ " FROM ELECTRON_CONTRACT BC WHERE BC.ContractStatus = '01' and OperateUserID=? ";

	private String sql221 = " select ' [�ͻ����ƣ�'||BC.CustomerName||']'||' ' as detail,nvl(BC.BusinessSum,0) as BusinessSum "
			+ " FROM ELECTRON_CONTRACT BC WHERE BC.ContractStatus = '01' and OperateUserID=? ";

	// ��������Ԥ���ź�24
	private String sql230 = " select count(BA.SerialNo) as count "
			+ " from RISK_SIGNAL BA, FLOW_TASK FT "
			+ " where BA.SerialNo=FT.ObjectNo "
			+ " and FT.ApplyType='RiskSignalReApply' "
			+ " and FT.ObjectType='RiskSignalReApply' "
			+ " and FT.UserID=? and FT.PhaseType<>'1010' "
			+ " and (FT.EndTime is null " + " or FT.EndTime = ' ') "
			+ " and (FT.PhaseAction is null " + " or FT.PhaseAction = ' ') ";
	private String sql231 = " select ' [�ͻ���ţ�'||BA.CustomerID||']'||' [�ͻ����ƣ�'||BA.CustomerName||']'||' [�����ˣ�'||getUserName(BA.inputuserid)||']' as detail "
			+ " from RISK_SIGNAL BA, FLOW_TASK FT "
			+ " where BA.SerialNo=FT.ObjectNo "
			+ " and FT.ApplyType='RiskSignalReApply' "
			+ " and FT.ObjectType='RiskSignalReApply' "
			+ " and FT.UserID=? and FT.PhaseType<>'1010' "
			+ " and (FT.EndTime is null "
			+ " or FT.EndTime = ' ') "
			+ " and (FT.PhaseAction is null " + " or FT.PhaseAction = ' ') ";

	// �������ĵ����������25
	private String sql240 = " select count(CA.SerialNo) as count "
			+ " from CL_APPLY CA, FLOW_TASK FT "
			+ " where CA.SerialNo=FT.ObjectNo "
			+ " and FT.ApplyType='GCreditApply' "
			+ " and FT.ObjectType='GCreditApply' "
			+ " and FT.UserID=? and FT.PhaseType<>'1010' "
			+ " and (FT.EndTime is null " + " or FT.EndTime = ' ') "
			+ " and (FT.PhaseAction is null " + " or FT.PhaseAction = ' ') ";

	private String sql241 = " select ' [�����ţ�'||CA.SerialNo||']'||' [�ͻ���ţ�'||CA.CustomerID||']'||' [�ͻ����ƣ�'||CA.CustomerName||']'||' [�����ˣ�'||getUserName(CA.inputuser)||']' as detail "
			+ " from CL_APPLY CA, FLOW_TASK FT "
			+ " where CA.SerialNo=FT.ObjectNo "
			+ " and FT.ApplyType='GCreditApply' "
			+ " and FT.ObjectType='GCreditApply' "
			+ " and FT.UserID=? and FT.PhaseType<>'1010' "
			+ " and (FT.EndTime is null "
			+ " or FT.EndTime = ' ') "
			+ " and (FT.PhaseAction is null " + " or FT.PhaseAction = ' ') ";

	// �������ĳ��������26
	private String sql250 = " select count(GO.SerialNo) as count "
			+ " From GUARANTY_OUTPUT GO,FLOW_OBJECT FO Where  FO.OBJECTNO=GO.SERIALNO   "
			+ " and FO.ObjectType =  'OutInApply' and (FO.PhaseType='1030' or FO.PhaseType='1010' )  "
			+ " and FO.ApplyType='OutInLineApply' and FO.UserID=? ";

	private String sql251 = "  select '[�����������ˮ��: '||GO.SERIALNO||' ] [�������������:'||nvl(getItemName('OutPutType',GO.OUTPUTTYPE),'')||'] [������: '||nvl(FO.USERNAME ,'')||'] [�׶�����: '||nvl(FO.PHASENAME,'')||'] [��������: '||nvl(FO.FlowName,'')||']' as detail "
			+ " From GUARANTY_OUTPUT GO,FLOW_OBJECT FO Where  FO.OBJECTNO=GO.SERIALNO   "
			+ " and FO.ObjectType =  'OutInApply' and (FO.PhaseType='1030' or FO.PhaseType='1010' )  "
			+ " and FO.ApplyType='OutInLineApply' and FO.UserID=? order by GO.SERIALNO desc";

	// �������Ľ��Ĺ�����������27
	private String sql260 = " select count(LDA.SerialNo) as count"
			+ " from  LEND_DOC_APPLY LDA ,FLOW_TASK FT where FT.objectType='LendingApply' and LDA.SERIALNO=FT.OBJECTNO   "
			+ "  and FT.APPLYTYPE='LendingApply' and (FT.ENDTIME is null or FT.ENDTIME='')  "
			+ "  and FT.UserID=? ";

	private String sql261 = " select '[������ˮ��: '||LDA.SERIALNO||'  ]  [�ͻ���::'||nvl(LDA.CustomerID,'')||']  [���������:  '||nvl(LDA.CustomerName ,'')||']  [�׶�����:  '||nvl(FT.PHASENAME,'')||']' as detail "
			+ " from  LEND_DOC_APPLY LDA ,FLOW_TASK FT where FT.objectType='LendingApply' and LDA.SERIALNO=FT.OBJECTNO   "
			+ "  and FT.APPLYTYPE='LendingApply' and (FT.ENDTIME is null or FT.ENDTIME='')  "
			+ "  and FT.UserID=? order by LDA.SERIALNO desc ";

	// �������ķ���Ԥ�����28
	private String sql270 = " select count(BA.SerialNo) as count "
			+ " from RISK_SIGNAL BA, FLOW_TASK FT "
			+ " where BA.SerialNo=FT.ObjectNo "
			+ " and FT.ApplyType='RiskSignalReApply' "
			+ " and FT.ObjectType='RiskSignalReApply' "
			+ " and FT.UserID=? and FT.PhaseType<>'1010' "
			+ " and (FT.EndTime is null " + " or FT.EndTime = ' ') "
			+ " and (FT.PhaseAction is null " + " or FT.PhaseAction = ' ') ";
	private String sql271 = " select '  [�ͻ���ţ�'||BA.CustomerID||']'||'  [�ͻ����ƣ�'||BA.CustomerName||']'||'  [�����ˣ�'||getUserName(BA.inputuserid)||']' as detail "
			+ " from RISK_SIGNAL BA, FLOW_TASK FT "
			+ " where BA.SerialNo=FT.ObjectNo "
			+ " and FT.ApplyType='RiskSignalReApply' "
			+ " and FT.ObjectType='RiskSignalReApply' "
			+ " and FT.UserID=? and FT.PhaseType<>'1010' "
			+ " and (FT.EndTime is null "
			+ " or FT.EndTime = ' ') "
			+ " and (FT.PhaseAction is null " + " or FT.PhaseAction = ' ') ";

	// �������Ĵ�����ƻ���������29
	private String sql280 = " select count(II.SerialNo) as count "
			+ " from FLOW_TASK FT ,INSPECT_INFO II    "
			+ " where FT.objectType='InspectPlanApply' and II.SERIALNO=FT.OBJECTNO and FT.APPLYTYPE='InspectPlanApply'  "
			+ " and (FT.ENDTIME is null or FT.ENDTIME='') and FT.UserID=? ";
	private String sql281 = " select '[������ˮ��:  '||II.SERIALNO||'  ]  [�ͻ�����::'||nvl(getCustomerName(II.ObjectNo),'')||']  [���Ƶ��:  '||nvl(getItemName('InspectFrequency',II.Opinion1) ,'')||']  [�׶�����:  '||nvl(FT.PHASENAME,'')||']' as detail "
			+ " from FLOW_TASK FT ,INSPECT_INFO II    "
			+ " where FT.objectType='InspectPlanApply' and II.SERIALNO=FT.OBJECTNO and FT.APPLYTYPE='InspectPlanApply'  "
			+ " and (FT.ENDTIME is null or FT.ENDTIME='') and FT.UserID=?  order by II.SERIALNO desc";

	// ���������ʲ����շ����϶���������30
	private String sql290 = " select count(CR.SerialNo)  as count "
			+ " from FLOW_TASK FT,CLASSIFY_RECORD CR    "
			+ " where FT.objectType='Classify' and CR.SERIALNO=FT.OBJECTNO and FT.APPLYTYPE='RiskClassifyApply'   "
			+ " and (FT.ENDTIME is null or FT.ENDTIME='') and FT.UserID=? ";

	private String sql291 = " select '[�϶�������ˮ��:  '||CR.SERIALNO||'  ]  [�ͻ�����:'||nvl(getCustomerName(CR.ObjectNo),'')||']  [�������:  '||nvl(sum1,0)||']  [�׶�����:  '||nvl(FT.PHASENAME,'')||']'  as detail "
			+ " from FLOW_TASK FT,CLASSIFY_RECORD CR    "
			+ " where FT.objectType='Classify' and CR.SERIALNO=FT.OBJECTNO and FT.APPLYTYPE='RiskClassifyApply'   "
			+ " and (FT.ENDTIME is null or FT.ENDTIME='') and FT.UserID=?  order by CR.SERIALNO desc";

	// �������ķſ�Ҫ����������31
	private String sql300 = " select count(PE.SerialNo) as count "
			+ " from FLOW_TASK FT, PUTOUT_ELEMENT PE    "
			+ " where FT.objectType='Element' and PE.SERIALNO=FT.OBJECTNO and FT.APPLYTYPE='ElementApply'  "
			+ " and (FT.ENDTIME is null or FT.ENDTIME='') and FT.UserID=? ";
	private String sql301 = "  select '[������:  '||PE.SERIALNO||'  ]  [��ͬ���:'||nvl(PE.ContractSerialNo,'')||']  [�ͻ�����:  '||nvl(PE.CustomerName,'')||']  [ҵ��Ʒ��:  '||nvl(getBusinessName(PE.BusinessType),'')||']  [������(Ԫ):  '||nvl(PE.BusinessSum,0)||']  [�׶�����:  '||nvl(FT.PHASENAME,'')||']' as detail "
			+ " from FLOW_TASK FT, PUTOUT_ELEMENT PE    "
			+ " where FT.objectType='Element' and PE.SERIALNO=FT.OBJECTNO and FT.APPLYTYPE='ElementApply'  "
			+ " and (FT.ENDTIME is null or FT.ENDTIME='') and FT.UserID=? order by PE.SERIALNO desc";

	// �������Ĵ�ǰ����������������32
	private String sql310 = " select count(BSC.SerialNo)  as count "
			+ " from FLOW_TASK FT, BUSINESS_SPECIAL_CONDITION BSC    "
			+ " where FT.objectType='SpecialConApply' and BSC.SERIALNO=FT.OBJECTNO and FT.APPLYTYPE='SpecialConApply'  "
			+ " and (FT.ENDTIME is null or FT.ENDTIME='') and FT.UserID=?";
	private String sql311 = " select '[������:   '||BSC.SERIALNO||'   ]   [�ͻ����:'||nvl(BSC.CustomerID,'')||']   [�ͻ�����:   '"
			+ "||nvl(BSC.CustomerName,'')||']   [С΢��Ʒ:   '||nvl(getBusinessName(BSC.BUSINESSTYPE),'')||']   [������:   '"
			+ "||nvl(BSC.BusinessSum,0)||']   [��������:   '||nvl(getItemName('ApplyItem',BSC.APPLYITEM),'')||']   [��ǰ�׶�:   '||nvl(FT.PHASENAME,'')||']' as detail "
			+ " from FLOW_TASK FT, BUSINESS_SPECIAL_CONDITION BSC    "
			+ " where FT.objectType='SpecialConApply' and BSC.SERIALNO=FT.OBJECTNO and FT.APPLYTYPE='SpecialConApply'  "
			+ " and (FT.ENDTIME is null or FT.ENDTIME='') and FT.UserID=? order by BSC.SERIALNO desc";

	// �������ĸ�������������������33
	private String sql320 = " select count(RP.SerialNo) as count "
			+ " From RATE_PRICE RP,FLOW_TASK FT    "
			+ " Where FT.ObjectNo=RP.SERIALNO and FT.ObjectType =  'RatePriceApply'  and FT.ApplyType='RatePriceApply'  "
			+ " and (FT.ENDTIME is null or FT.ENDTIME='') and FT.UserID=?";
	private String sql321 = " select '[������:  '||RP.SERIALNO||'  ]  [��Ʒ����:'||nvl(GETBUSINESSTYPEITEMS(RP.BUSINESSTYPE),'')||']' "
			+ "||'  [��������:'||nvl(GETOCCURTYPEITEMS(RP.RELATIVEPRODUCTNO),'')||']  [����¥��:  '"
			+ "||nvl(RP.SPECIALCLOCCUPY,'')||']  [�������:  '||nvl(RP.SPECIALCASENAME,'')||']  [���ʸ�����������(%):  '"
			+ "||nvl(RP.RATEFLOAT,0)||']  [�Ǽ���:  '||nvl(getUserName(INPUTUSER),'')||']  [��ǰ�׶�:  '||nvl(FT.PHASENAME,'')||']' as detail  "
			+ " From RATE_PRICE RP,FLOW_TASK FT    "
			+ " Where FT.ObjectNo=RP.SERIALNO and FT.ObjectType =  'RatePriceApply'  and FT.ApplyType='RatePriceApply'  "
			+ " and (FT.ENDTIME is null or FT.ENDTIME='') and FT.UserID=? order by RP.SERIALNO desc";

	//��������δ���ѺƷ34
	public String getSql0() {
		return sql0;
	}

	public void setSql0(String sql0) {
		this.sql0 = sql0;
	}

	public String getSq100() {
		return sq100;
	}

	public void setSq100(String sq100) {
		this.sq100 = sq100;
	}

	public String getSql1() {
		return sql1;
	}

	public void setSql1(String sql1) {
		this.sql1 = sql1;
	}

	public String getSql10() {
		return sql10;
	}

	public void setSql10(String sql10) {
		this.sql10 = sql10;
	}

	public String getSql2() {
		return sql2;
	}

	public void setSql2(String sql2) {
		this.sql2 = sql2;
	}

	public String getSql20() {
		return sql20;
	}

	public void setSql20(String sql20) {
		this.sql20 = sql20;
	}

	public String getSql30() {
		return sql30;
	}

	public void setSql30(String sql30) {
		this.sql30 = sql30;
	}

	public String getSql3() {
		return sql3;
	}

	public void setSql3(String sql3) {
		this.sql3 = sql3;
	}

	public String getSql4() {
		return sql4;
	}

	public void setSql4(String sql4) {
		this.sql4 = sql4;
	}

	public String getSql40() {
		return sql40;
	}

	public void setSql40(String sql40) {
		this.sql40 = sql40;
	}

	public String getSql5() {
		return sql5;
	}

	public void setSql5(String sql5) {
		this.sql5 = sql5;
	}

	public String getSql50() {
		return sql50;
	}

	public void setSql50(String sql50) {
		this.sql50 = sql50;
	}

	public String getSql6() {
		return sql6;
	}

	public void setSql6(String sql6) {
		this.sql6 = sql6;
	}

	public String getSql60() {
		return sql60;
	}

	public void setSql60(String sql60) {
		this.sql60 = sql60;
	}

	public String getSql7() {
		return sql7;
	}

	public void setSql7(String sql7) {
		this.sql7 = sql7;
	}

	public String getSql70() {
		return sql70;
	}

	public void setSql70(String sql70) {
		this.sql70 = sql70;
	}

	public String getSql8() {
		return sql8;
	}

	public void setSql8(String sql8) {
		this.sql8 = sql8;
	}

	public String getSql80() {
		return sql80;
	}

	public void setSql80(String sql80) {
		this.sql80 = sql80;
	}

	public String getSql9() {
		return sql9;
	}

	public void setSql9(String sql9) {
		this.sql9 = sql9;
	}

	public String getSql90() {
		return sql90;
	}

	public void setSql90(String sql90) {
		this.sql90 = sql90;
	}

	public String getSql100() {
		return sql100;
	}

	public void setSql100(String sql100) {
		this.sql100 = sql100;
	}

	public String getSql101() {
		return sql101;
	}

	public void setSql101(String sql101) {
		this.sql101 = sql101;
	}

	public String getSql110() {
		return sql110;
	}

	public void setSql110(String sql110) {
		this.sql110 = sql110;
	}

	public String getSql111() {
		return sql111;
	}

	public void setSql111(String sql111) {
		this.sql111 = sql111;
	}

	public String getSql120() {
		return sql120;
	}

	public void setSql120(String sql120) {
		this.sql120 = sql120;
	}

	public String getSql121() {
		return sql121;
	}

	public void setSql121(String sql121) {
		this.sql121 = sql121;
	}

	public String getSql130() {
		return sql130;
	}

	public void setSql130(String sql130) {
		this.sql130 = sql130;
	}

	public String getSql131() {
		return sql131;
	}

	public void setSql131(String sql131) {
		this.sql131 = sql131;
	}

	public String getSql140() {
		return sql140;
	}

	public void setSql140(String sql140) {
		this.sql140 = sql140;
	}

	public String getSql141() {
		return sql141;
	}

	public void setSql141(String sql141) {
		this.sql141 = sql141;
	}

	public String getSql150() {
		return sql150;
	}

	public void setSql150(String sql150) {
		this.sql150 = sql150;
	}

	public String getSql151() {
		return sql151;
	}

	public void setSql151(String sql151) {
		this.sql151 = sql151;
	}

	public String getSql160() {
		return sql160;
	}

	public void setSql160(String sql160) {
		this.sql160 = sql160;
	}

	public String getSql161() {
		return sql161;
	}

	public void setSql161(String sql161) {
		this.sql161 = sql161;
	}

	public String getSql170() {
		return sql170;
	}

	public void setSql170(String sql170) {
		this.sql170 = sql170;
	}

	public String getSql171() {
		return sql171;
	}

	public void setSql171(String sql171) {
		this.sql171 = sql171;
	}

	public String getSql180() {
		return sql180;
	}

	public void setSql180(String sql180) {
		this.sql180 = sql180;
	}

	public String getSql181() {
		return sql181;
	}

	public void setSql181(String sql181) {
		this.sql181 = sql181;
	}

	public String getSql190() {
		return sql190;
	}

	public void setSql190(String sql190) {
		this.sql190 = sql190;
	}

	public String getSql191() {
		return sql191;
	}

	public void setSql191(String sql191) {
		this.sql191 = sql191;
	}

	public String getSql200() {
		return sql200;
	}

	public void setSql200(String sql200) {
		this.sql200 = sql200;
	}

	public String getSql201() {
		return sql201;
	}

	public void setSql201(String sql201) {
		this.sql201 = sql201;
	}

	public String getSql210() {
		return sql210;
	}

	public void setSql210(String sql210) {
		this.sql210 = sql210;
	}

	public String getSql211() {
		return sql211;
	}

	public void setSql211(String sql211) {
		this.sql211 = sql211;
	}

	public String getSql220() {
		return sql220;
	}

	public void setSql220(String sql220) {
		this.sql220 = sql220;
	}

	public String getSql221() {
		return sql221;
	}

	public void setSql221(String sql221) {
		this.sql221 = sql221;
	}

	public String getSql230() {
		return sql230;
	}

	public void setSql230(String sql230) {
		this.sql230 = sql230;
	}

	public String getSql231() {
		return sql231;
	}

	public void setSql231(String sql231) {
		this.sql231 = sql231;
	}

	public String getSql240() {
		return sql240;
	}

	public void setSql240(String sql240) {
		this.sql240 = sql240;
	}

	public String getSql241() {
		return sql241;
	}

	public void setSql241(String sql241) {
		this.sql241 = sql241;
	}

	public String getSql250() {
		return sql250;
	}

	public void setSql250(String sql250) {
		this.sql250 = sql250;
	}

	public String getSql251() {
		return sql251;
	}

	public void setSql251(String sql251) {
		this.sql251 = sql251;
	}

	public String getSql260() {
		return sql260;
	}

	public void setSql260(String sql260) {
		this.sql260 = sql260;
	}

	public String getSql261() {
		return sql261;
	}

	public void setSql261(String sql261) {
		this.sql261 = sql261;
	}

	public String getSql270() {
		return sql270;
	}

	public void setSql270(String sql270) {
		this.sql270 = sql270;
	}

	public String getSql271() {
		return sql271;
	}

	public void setSql271(String sql271) {
		this.sql271 = sql271;
	}

	public String getSql280() {
		return sql280;
	}

	public void setSql280(String sql280) {
		this.sql280 = sql280;
	}

	public String getSql281() {
		return sql281;
	}

	public void setSql281(String sql281) {
		this.sql281 = sql281;
	}

	public String getSql290() {
		return sql290;
	}

	public void setSql290(String sql290) {
		this.sql290 = sql290;
	}

	public String getSql291() {
		return sql291;
	}

	public void setSql291(String sql291) {
		this.sql291 = sql291;
	}

	public String getSql300() {
		return sql300;
	}

	public void setSql300(String sql300) {
		this.sql300 = sql300;
	}

	public String getSql301() {
		return sql301;
	}

	public void setSql301(String sql301) {
		this.sql301 = sql301;
	}

	public String getSql310() {
		return sql310;
	}

	public void setSql310(String sql310) {
		this.sql310 = sql310;
	}

	public String getSql311() {
		return sql311;
	}

	public void setSql311(String sql311) {
		this.sql311 = sql311;
	}

	public String getSql320() {
		return sql320;
	}

	public void setSql320(String sql320) {
		this.sql320 = sql320;
	}

	public String getSql321() {
		return sql321;
	}

	public void setSql321(String sql321) {
		this.sql321 = sql321;
	}

}
