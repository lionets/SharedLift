package com.amarsoft.webservice.proj.nh.approve;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amarsoft.are.ARE;
import com.amarsoft.mobile.webservice.business.HandlerException;

public class TakeBackControl{
	
	/**
	 * �ж��ջذ�ť��ʾȨ��
	 * @param flowNo
	 * @param phaseNo
	 * @return
	 * @throws HandlerException
	 */
	public static Boolean getBackControl(String flowNo, String phaseNo) throws HandlerException{
		
		Connection conn = null;
		
		String orleSql="select attribute2 from  flow_model where flowno=? and phaseno=?";
		
		try {
			conn = ARE.getDBConnection("als");
			
			PreparedStatement ps1=conn.prepareStatement(orleSql);
			ps1.setString(1,flowNo);
			ps1.setString(2,phaseNo);
			
			ResultSet rs1=ps1.executeQuery();
			if(rs1.next()){
				String buttons=rs1.getString("attribute2");
				if(buttons.indexOf("takeBack")>0){
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new HandlerException("�ر����ݿ����");
				}
			}
		}
		return false;
	}

}
