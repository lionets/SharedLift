package com.amarsoft.webservice.proj.nh.apply;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;

/**
 * ��������ʱѡ��ͻ�
 * ���������
  
  

 * ���������
 *    IndArray-���˿ͻ�
 *       CustomerNo �ͻ����
 *       CustomerName �ͻ�����
 *    EntArray-��˾�ͻ�
 *       CustomerNo �ͻ����
 *       CustomerName �ͻ�����
 *    StrangArray-İ���ͻ�
 *       CustomerNo �ͻ����
 *       CustomerName �ͻ�����

 * @author 
 *
 */
public class ApplyAddHandler extends JSONHandlerWithSession{

	private String sInputOrgID = "";
	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		JSONObject response = new JSONObject();
		Connection conn = null;
		
		String sUserId = SessionManager.getUserId(this.getSessionKey());//�û���
		//��ȡ������Ϣ
		String sGetNameSql = " select belongorg as InputOrgID from USER_INFO " +
	  	 					" where userid = ?";
		//���˿ͻ�
		String sSqlInd = " select CI.CustomerID as CustomerNo,CI.CustomerName,getItemName('CertType',CI.CertType) as CertTypeName,CI.CertID,getItemName('CustomerType',CI.CustomerType) as CustomerTypeName " +
					" from CUSTOMER_INFO CI  " + 
					" where (exists(select CB.CustomerID from CUSTOMER_BELONG CB where CB.CustomerID = CI.CustomerID and CB.OrgID=? and CB.BelongAttribute3 = '1'))" +
					" and CI.CustomerType like '03%'";
		//��˾�ͻ�
		String sSqlEnt = " select CI.CustomerID as CustomerNo,CI.CustomerName as CustomerName," +
				" getItemName('CertType',CI.CertType) as CertTypeName,CI.CertID,getItemName('CustomerType',CI.CustomerType) as CustomerTypeName " +
				" from CUSTOMER_INFO CI  " + 
				" where (exists(select CB.CustomerID from CUSTOMER_BELONG CB where CB.CustomerID = CI.CustomerID and CB.OrgID=? and CB.BelongAttribute3 = '1'))" +
				" and CI.CustomerType like '01%'";
		//İ���ͻ�
		String sSqlStrange = " select SI.SerialNo as CustomerNo,SI.CustomerName as CustomerName " +
							" from strange_customer_info SI  " + 
							" where (exists(select CB.CustomerID from CUSTOMER_BELONG CB where CB.CustomerID = SI.SerialNo and CB.OrgID=? and CB.BelongAttribute3 = '1'))" ;
		
		try {
			conn = ARE.getDBConnection("als");
			
			PreparedStatement psUser = conn.prepareStatement(sGetNameSql);
			psUser.setString(1, sUserId);
			ARE.getLog().info(sGetNameSql);
			ResultSet rsUser = psUser.executeQuery();
			if(rsUser.next()){
				this.sInputOrgID = rsUser.getString("InputOrgID");
			}
			rsUser.getStatement().close();
			
			PreparedStatement psInd = conn.prepareStatement(sSqlInd);
			JSONArray resultInd = new JSONArray();
			psInd.setString(1, sInputOrgID);
			ARE.getLog().info(sSqlInd);
			ResultSet rsInd = psInd.executeQuery();
			while(rsInd.next()){
				JSONObject object = new JSONObject();
				object.put("CustomerNo", rsInd.getString("CustomerNo"));
				object.put("CustomerName", rsInd.getString("CustomerName"));
				resultInd.add(object);
			}
			rsInd.getStatement().close();
			response.put("IndArray", resultInd);
			
			PreparedStatement psEnt = conn.prepareStatement(sSqlEnt);
			JSONArray resultEnt = new JSONArray();
			psEnt.setString(1, sInputOrgID);
			ARE.getLog().info(sSqlEnt);
			ResultSet rsEnt = psEnt.executeQuery();
			while(rsEnt.next()){
				JSONObject object = new JSONObject();
				object.put("CustomerNo", rsEnt.getString("CustomerNo"));
				object.put("CustomerName", rsEnt.getString("CustomerName"));
				resultEnt.add(object);
			}
			rsEnt.getStatement().close();
			response.put("EntArray", resultEnt);
			
			PreparedStatement psStrange = conn.prepareStatement(sSqlStrange);
			JSONArray resultStrange = new JSONArray();
			psStrange.setString(1, sInputOrgID);
			ARE.getLog().info(sSqlStrange);
			ResultSet rsStrange = psStrange.executeQuery();
			while(rsStrange.next()){
				JSONObject object = new JSONObject();
				object.put("CustomerNo", rsStrange.getString("CustomerNo"));
				object.put("CustomerName", rsStrange.getString("CustomerName"));
				resultStrange.add(object);
			}
			rsStrange.getStatement().close();
			response.put("StrangeArray", resultStrange);
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		finally{
			try{
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}

}
