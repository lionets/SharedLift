package com.amarsoft.webservice.proj.nh.bizquery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;
/**
 * ѡ�����
 * ���������
	CurPage - ��ǰ���ص�ҳ
	PageSize - ÿҳ������
 * ���������
	OrgArray��
	   OrgID - ������
	   OrgName - ��������
 * @author 
 *
 */

public class OrgListHandler extends JSONHandlerWithSession{

	private int CurPage = 0;
	private int PageSize = 20;
	private String org = "";
	private String orgname = "";
	
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		JSONObject response = new JSONObject();
		Pageable.setDBType("DB2");
		if(request.containsKey("PageSize")){//ÿҳ����
			this.PageSize = Integer.parseInt(request.get("PageSize").toString());
		}
		if(request.containsKey("CurPage")){//��ǰҳ��
			this.CurPage = Integer.parseInt(request.get("CurPage").toString());
		}
		String sUserId = SessionManager.getUserId(this.getSessionKey());
		String sbelongOrg = " select belongorg,getOrgName(belongorg) as OrgName from user_info where userid = ?";
//		String sSql = " select orgid as OrgID,orgname as OrgName from Org_Info where belongorgid like '"+sbelongOrg+"%'";

		try {
			conn= ARE.getDBConnection("als");
			JSONArray result = new JSONArray();
			//add 20140409
			PreparedStatement psorg = conn.prepareStatement(sbelongOrg);
			psorg.setString(1, sUserId);
			ResultSet rsorg = psorg.executeQuery();
			if (rsorg.next()) {
				org = rsorg.getString("belongorg");
				orgname = rsorg.getString("OrgName");
			}
			rsorg.getStatement().close();
			
			if(org!=null&&!org.equals("")){//�ɲ鿴�Ļ���
				String sSql = " select orgid as OrgID,orgname as OrgName from Org_Info where belongorgid like '"+org+"%'";
				sSql = Pageable.getPageable().getPagedSqlByPageNum(sSql, this.CurPage, this.PageSize);
				ARE.getLog().info(sSql);
				PreparedStatement ps = conn.prepareStatement(sSql);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					JSONObject obj = new JSONObject();
					if(rs.getString("OrgID").equals(org)){//����б��У��Ȳ���������
						continue;
					}
					obj.put("OrgID", rs.getString("OrgID"));
					obj.put("OrgName", rs.getString("OrgName"));
					result.add(obj);
				}
				rs.getStatement().close();
			}
			//����
			if(CurPage==0){
				JSONObject object = new JSONObject();
				object.put("OrgID", org);
				object.put("OrgName", orgname);
				result.add(object);
			}
			
			response.put("OrgArray", result);	
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	
	}

}
