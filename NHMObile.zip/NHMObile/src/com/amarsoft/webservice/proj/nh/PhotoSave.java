package com.amarsoft.webservice.proj.nh;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Types;
import java.util.ArrayList;

import com.amarsoft.are.ARE;
//import com.amarsoft.are.sql.Transaction;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.DBKeyHelp;
import com.amarsoft.awe.util.Transaction;
import com.amarsoft.mobile.webservice.ServiceFactory;
//import com.amarsoft.webservice.DBFunction1;

/**
 * ͼƬ����
 * @author amarsoft
 *
 */
public class PhotoSave {
	
	private String objectNo="";
	private String objectType="";//Apply,Customer
	private String bizType="";//Apply,Customer,Afterloan,Credit
	private String photoDesc="";
	private String address="";
	private double latitude=0d;
	private double longitude=0d;
	private String inputUser="";
	
	public PhotoSave(String bizType,String objectType,String objectNo){
		this.bizType = bizType;
		this.objectType = objectType;
		this.objectNo = objectNo;
	}
	
	public String getInputUser() {
		return inputUser;
	}

	public void setInputUser(String inputUser) {
		this.inputUser = inputUser;
	}

	public String getObjectNo() {
		return objectNo;
	}

	public void setObjectNo(String objectNo) {
		this.objectNo = objectNo;
	}

	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public String getBizType() {
		return bizType;
	}

	public void setBizType(String bizType) {
		this.bizType = bizType;
	}

	public String getPhotoDesc() {
		return photoDesc;
	}

	public void setPhotoDesc(String photoDesc) {
		this.photoDesc = photoDesc;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	
	public void save(ArrayList<byte[]> photoDatas,Connection conn)throws Exception{
		if(photoDatas==null)throw new Exception("û��ͼƬ��Ϣ");
		String sql = "insert into photo_info(serialno,biztype,objectno,objecttype,photopath,photodesc,address,latitude,longitude,inputuser,inputtime)"
				+ "values(?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		for(byte[] bytes : photoDatas){
			//��¼���ݿ�
			String sSerialNo = DBKeyHelp.getSerialNo("photo_info", "serialno");
		
			String sPhotoRootPath = ServiceFactory.getFactory().getUploadRootPath();//��ȡ����ͼƬ�ĸ�·��
			String sRelativePath = "/" + getBizType() + "/" + getObjectType() + "/" + getObjectNo();
			String sFilePath = sRelativePath + "/" + sSerialNo + ".jpg";
			String sTodayNow = StringFunction.getTodayNow();
			ps.setString(1, sSerialNo);
//			ARE.getLog(sSerialNo+" ***************");
			ps.setString(2, this.getBizType());
			ps.setString(3, this.getObjectNo());
			ps.setString(4, this.getObjectType());
			ps.setString(5, sFilePath );
			ps.setString(6, this.getPhotoDesc());
			ps.setString(7, this.getAddress());
			//modify 20140319 by ldfang ��ָ�봦��
			if (this.getLatitude()==1000) {
				ps.setNull(8, Types.DECIMAL);
			}
			else {
				ps.setDouble(8, this.getLatitude());
			}
			
			if(this.getLongitude()==1000){
				ps.setNull(9, Types.DECIMAL);
			}
			else {
				ps.setDouble(9, this.getLongitude());
			}
			//end	
			ps.setString(10, this.getInputUser());
			ps.setString(11, sTodayNow);
			//�����ļ�Ŀ¼
			File dir = new File(sPhotoRootPath+sRelativePath);
			boolean bCanMakeDir = true;
			if(dir.exists()==false)
				bCanMakeDir= dir.mkdirs();
			if(bCanMakeDir==false){
				ARE.getLog().error("����Ŀ¼"+sPhotoRootPath+sRelativePath+"ʧ��");
				throw new Exception("����Ŀ¼ʧ��");
			}
			else{
				ARE.getLog().error("����Ŀ¼"+sPhotoRootPath+sRelativePath+"�ɹ�");
			}
			//�����ļ�
			FileOutputStream fos = new FileOutputStream(sPhotoRootPath+sFilePath);
			fos.write(bytes);
			fos.close();
			ARE.getLog().info("�ļ����浽" + sPhotoRootPath+sFilePath);
			ps.addBatch();
			ARE.getLog().info(sql+ ","+sSerialNo+ ","+getBizType()+ ","+getObjectNo()+ ","+getObjectType()+ ","+sFilePath+ ","+getPhotoDesc()
				+ ","+getAddress()+ ","+getLatitude()+ ","+getLongitude()+ ","+getInputUser()+ ","+sTodayNow);
		}
		//����ִ�в������ݿ�
		ps.executeBatch();
	}
}
