package com.amarsoft.webservice.proj.nh.bizquery;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
/**
 * ��Ȩ�ύ
 * ���������
 *    FlowTaskNo - ������ˮ��
 *    ActionValue-�ͻ���ѡ��Ĵ����˵�ֵ��Ϊ��������Ȩ��
 *    
 * ���������
 *    status - ״̬
 * @author 
 *
 */
public class EmpowerCommitHandler extends JSONHandlerWithSession{

	
	private String sActionValue;
	private String sUserID;
	private String UserName;
	
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		JSONObject response = new JSONObject();
		
		String sUserName = " select username from user_info where userid=?";
		
		String sUpdateTask = " update flow_task set userid =?,username=?" +
				" where serialno = ?";
	
		try {
			if(!request.containsKey("FlowTaskNo")){
				throw new Exception("��Ҫ����FlowTaskNo");
			}
			if(!request.containsKey("ActionValue")){
				throw new Exception("��Ҫ����ActionValue");
			}

		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		try {
			conn= ARE.getDBConnection("als");
			
			sActionValue = request.get("ActionValue").toString();
			sUserID = sActionValue.split(" ")[0];
			
			PreparedStatement ps = conn.prepareStatement(sUserName);
			ps.setString(1, sUserID);
			ARE.getLog().info(sUserName);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				UserName = rs.getString("username");
			}
			rs.getStatement().close();
			
			PreparedStatement psUpdate = conn.prepareStatement(sUpdateTask);
			psUpdate.setString(1, sUserID);
			psUpdate.setString(2, UserName);
			psUpdate.setString(3, request.get("FlowTaskNo").toString());
			psUpdate.executeUpdate();
			response.put("status", "success");
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
		}

}
