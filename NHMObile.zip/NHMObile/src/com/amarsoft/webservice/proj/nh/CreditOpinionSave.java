/**
 * 
 */
package com.amarsoft.webservice.proj.nh;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.DBKeyHelp;

/**
 * @author Administrator
 * ������������ݿ���
 */
public class CreditOpinionSave {
	
	private String TaskNo = "";
	private String RelativeType = "";
	private String RelativeNo = "";
	private String ObjectNo = "";
	private String CustomerID = "";
	private String CustomerName = "";
	private String BusinessCurrency = "";
	private double BusinessSum = 0;
	private int TermMonth = 0;
	private String BaseRateType = "";
	private String RateFloatType = "";
	private double RateFloat = 0;
	private String BusinessType = "";
	private double BusinessRate = 0;
	private double ExecuteYearRate = 0;
	private double BaseRate = 0;
	private String CorpusPayMethod = "";
	private String VouchType = "";
	private String CycleFlag = "";
	private double PdgRatio = 0;
	private double PdgSum = 0;
	private double BailRatio = 0;
	private double BailSum = 0;
	private String InputOrgID = "";
	private String InputUserID = "";
	private String OpinionState = "";

	public void save(Connection conn)throws Exception{
		String getFlowCredit = " INSERT INTO FLOW_CREDITOPINION(SERIALNO, TASKNO, RELATIVETYPE, RELATIVENO, OBJECTNO, CUSTOMERID, "
				+ " CUSTOMERNAME, BUSINESSCURRENCY,"
				+ " BUSINESSSUM, TERMMONTH, BASERATETYPE, RATEFLOATTYPE, RATEFLOAT, BUSINESSTYPE, BUSINESSRATE, ExecuteYearRate, "
				+ " BASERATE, CORPUSPAYMETHOD, VOUCHTYPE, CYCLEFLAG, BailSum,BailRatio,PdgSum,PdgRatio,INPUTORGID, INPUTUSERID, INPUTTIME, OPINIONSTATE,OPERATEORGID,OPERATEUSERID,OPERATEDATE,APPROVEVALIDDATE)  "
				+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(getFlowCredit);
		//��¼���ݿ�
		String sSerialNo = DBKeyHelp.getSerialNo("FLOW_CREDITOPINION", "serialno");
		ps.setString(1, sSerialNo);
		ps.setString(2, TaskNo);
		ps.setString(3, RelativeType);
		ps.setString(4, RelativeNo);
		ps.setString(5, ObjectNo);
		ps.setString(6, CustomerID);
		ps.setString(7, CustomerName);
		ps.setString(8, BusinessCurrency);
		ps.setDouble(9, BusinessSum);
		ps.setInt(10, TermMonth);
		ps.setString(11, BaseRateType);
		ps.setString(12, RateFloatType);
		ps.setDouble(13, RateFloat);
		ps.setString(14, BusinessType);
		ps.setDouble(15, BusinessRate);
		ps.setDouble(16, ExecuteYearRate);
		ps.setDouble(17, BaseRate);
		ps.setString(18, CorpusPayMethod);
		ps.setString(19, VouchType);
		ps.setString(20, CycleFlag);
		ps.setDouble(21, BailSum);
		ps.setDouble(22, BailRatio);
		ps.setDouble(23, PdgSum);
		ps.setDouble(24, PdgRatio);
		ps.setString(25, InputOrgID);
		ps.setString(26, InputUserID);
		ps.setString(27, StringFunction.getToday());
		ps.setString(28, OpinionState);
		String OperateOrgID="",OperateUserID="",OperateDate="";
		int ApproveValidDate =0;
		ResultSet rs = conn.createStatement().executeQuery("select OPERATEORGID,OPERATEUSERID,OPERATEDATE,APPROVEVALIDDATE from FLOW_CREDITOPINION where  taskno=(select relativeSerialno from flow_task where serialno='"+TaskNo+"' )  and ObjectNo='"+ObjectNo+"'");
		while(rs.next()){
			OperateOrgID = rs.getString(1);
			OperateUserID = rs.getString(2);
			OperateDate = rs.getString(3);
			ApproveValidDate = rs.getInt(4);
		}
		rs.close();
		ps.setString(29, OperateOrgID);
		ps.setString(30, OperateUserID);
		ps.setString(31, OperateDate);
		ps.setInt(32, ApproveValidDate);
		ps.executeUpdate();
		ARE.getLog().info(getFlowCredit);
		ps.close();
	}

	public String getTaskNo() {
		return TaskNo;
	}

	public void setTaskNo(String taskNo) {
		TaskNo = taskNo;
	}

	public String getRelativeType() {
		return RelativeType;
	}

	public void setRelativeType(String relativeType) {
		RelativeType = relativeType;
	}

	public String getRelativeNo() {
		return RelativeNo;
	}

	public void setRelativeNo(String relativeNo) {
		RelativeNo = relativeNo;
	}

	public String getObjectNo() {
		return ObjectNo;
	}

	public void setObjectNo(String objectNo) {
		ObjectNo = objectNo;
	}

	public String getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}

	public String getCustomerName() {
		return CustomerName;
	}

	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}

	public String getBusinessCurrency() {
		return BusinessCurrency;
	}

	public void setBusinessCurrency(String businessCurrency) {
		BusinessCurrency = businessCurrency;
	}

	public double getBusinessSum() {
		return BusinessSum;
	}

	public void setBusinessSum(double businessSum) {
		BusinessSum = businessSum;
	}

	public int getTermMonth() {
		return TermMonth;
	}

	public void setTermMonth(int termMonth) {
		TermMonth = termMonth;
	}

	public String getBaseRateType() {
		return BaseRateType;
	}

	public void setBaseRateType(String baseRateType) {
		BaseRateType = baseRateType;
	}

	public String getRateFloatType() {
		return RateFloatType;
	}

	public void setRateFloatType(String rateFloatType) {
		RateFloatType = rateFloatType;
	}

	public double getRateFloat() {
		return RateFloat;
	}

	public void setRateFloat(double rateFloat) {
		RateFloat = rateFloat;
	}

	public String getBusinessType() {
		return BusinessType;
	}

	public void setBusinessType(String businessType) {
		BusinessType = businessType;
	}

	public double getBusinessRate() {
		return BusinessRate;
	}

	public void setBusinessRate(double businessRate) {
		BusinessRate = businessRate;
	}

	public double getExecuteYearRate() {
		return ExecuteYearRate;
	}

	public void setExecuteYearRate(double executeYearRate) {
		ExecuteYearRate = executeYearRate;
	}

	public double getBaseRate() {
		return BaseRate;
	}

	public void setBaseRate(double baseRate) {
		BaseRate = baseRate;
	}

	public String getCorpusPayMethod() {
		return CorpusPayMethod;
	}

	public void setCorpusPayMethod(String corpusPayMethod) {
		CorpusPayMethod = corpusPayMethod;
	}

	public String getVouchType() {
		return VouchType;
	}

	public void setVouchType(String vouchType) {
		VouchType = vouchType;
	}

	public String getCycleFlag() {
		return CycleFlag;
	}

	public void setCycleFlag(String cycleFlag) {
		CycleFlag = cycleFlag;
	}

	public String getInputOrgID() {
		return InputOrgID;
	}

	public void setInputOrgID(String inputOrgID) {
		InputOrgID = inputOrgID;
	}

	public String getInputUserID() {
		return InputUserID;
	}

	public void setInputUserID(String inputUserID) {
		InputUserID = inputUserID;
	}

	public String getOpinionState() {
		return OpinionState;
	}

	public void setOpinionState(String opinionState) {
		OpinionState = opinionState;
	}
	
	public double getPdgRatio() {
		return PdgRatio;
	}

	public void setPdgRatio(double pdgRatio) {
		PdgRatio = pdgRatio;
	}

	public double getPdgSum() {
		return PdgSum;
	}

	public void setPdgSum(double pdgSum) {
		PdgSum = pdgSum;
	}

	public double getBailRatio() {
		return BailRatio;
	}

	public void setBailRatio(double bailRatio) {
		BailRatio = bailRatio;
	}

	public double getBailSum() {
		return BailSum;
	}

	public void setBailSum(double bailSum) {
		BailSum = bailSum;
	}

	public CreditOpinionSave(String taskNo, String relativeType,
			String relativeNo, String objectNo, String customerID,
			String customerName, String businessCurrency, double businessSum,
			int termMonth, String baseRateType, String rateFloatType,
			double rateFloat, String businessType, double businessRate,
			double executeYearRate, double baseRate, String corpusPayMethod,
			String vouchType, String cycleFlag, double pdgRatio, double pdgSum,
			double bailRatio, double bailSum, String inputOrgID,
			String inputUserID, String opinionState) {
		super();
		TaskNo = taskNo;
		RelativeType = relativeType;
		RelativeNo = relativeNo;
		ObjectNo = objectNo;
		CustomerID = customerID;
		CustomerName = customerName;
		BusinessCurrency = businessCurrency;
		BusinessSum = businessSum;
		TermMonth = termMonth;
		BaseRateType = baseRateType;
		RateFloatType = rateFloatType;
		RateFloat = rateFloat;
		BusinessType = businessType;
		BusinessRate = businessRate;
		ExecuteYearRate = executeYearRate;
		BaseRate = baseRate;
		CorpusPayMethod = corpusPayMethod;
		VouchType = vouchType;
		CycleFlag = cycleFlag;
		PdgRatio = pdgRatio;
		PdgSum = pdgSum;
		BailRatio = bailRatio;
		BailSum = bailSum;
		InputOrgID = inputOrgID;
		InputUserID = inputUserID;
		OpinionState = opinionState;
	}
}
