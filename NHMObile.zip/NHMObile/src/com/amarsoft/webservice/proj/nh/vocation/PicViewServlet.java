package com.amarsoft.webservice.proj.nh.vocation;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sun.misc.BASE64Encoder;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;

/**
 * �鿴ͼƬ
 * 
 * @author jwu1  2015/11/17
 *
 */
public class PicViewServlet extends JSONHandlerWithSession {
	private String sPhotoID = "";
	private String sObjectType = "";
	private String DocNo = "";

	public Object createResponse(JSONObject request, Properties arg1)throws HandlerException{
		
		if(request.containsKey("ObjectNo")){
			this.sPhotoID = request.get("ObjectNo").toString();
		}else{
			throw new HandlerException("ȱ�ٲ���ObjectNo");
		}
		if(request.containsKey("ObjectType")){
			this.sObjectType = request.get("ObjectType").toString();
		}else{
			throw new HandlerException("ȱ�ٲ���ObjectType");
		}
		if(sObjectType.equals("RiskSignalApply")){

			if(request.containsKey("DocNo")){
				this.DocNo = request.get("DocNo").toString();
			}else{
				throw new HandlerException("ȱ�ٲ���DocNo");
			}
		}
		
		Connection conn = null;
		ResultSet rs = null;
		String photoPath = "";		//ͼƬ·��
		String sSql = "";
		JSONObject jsonObject = new JSONObject();
		
		try {
			//��ȡͼƬ·��
			if(sObjectType.equals("AfterLoan")){
				
			//	sSql = " SELECT DocumentID as PhotoPath FROM ecm_page where serialno='"+sPhotoID+"' ";	
				
				sSql = " SELECT EPF.documentId||'/'||EPF.FileName as PhotoPath FROM   ECM_PAGE_NEW EPN,ECM_PAGE_FILE EPF" +
						" where (EPF.EndTime='' or EPF.EndTime is null or EPN.ModifyTime <= EPF.EndTime) and EPN.TypeNo=EPF.TypeNo and EPN.DocumentID=EPF.DocumentID " +
						"and EPF.SerialNo='"+sPhotoID+"' and EPN.ObjectType='AfterLoan' and EPN.documentId is not null  with ur ";	

			}else if(sObjectType.equals("RiskSignalApply")){
				
				String sDocNo = this.DocNo;
				sSql = " select FullPath as PhotoPath from REST_ATTACHMENT where ObjectNo='"+sPhotoID+"' and ObjectType='"+sObjectType+"' and DocNo='"+sDocNo+"' ";
			}
			
			//�������ݿ�
			conn= ARE.getDBConnection("als");

			ARE.getLog().info(sSql);
			PreparedStatement ps = conn.prepareStatement(sSql);
			rs = ps.executeQuery();
			if(rs.next()){
				
				photoPath = rs.getString("PhotoPath")==null?"":rs.getString("PhotoPath").toString();
			}
			rs.getStatement().close();
			
			
			InputStream in = null;
			byte[] data = null;
			// ��ȡͼƬ�ֽ�����
			in = new FileInputStream(photoPath);
			data = new byte[in.available()];
			in.read(data);
			in.close();
			// ���ֽ�����Base64����
			BASE64Encoder encoder = new BASE64Encoder();
			
			jsonObject.put("Photo", encoder.encode(data));// ����Base64��������ֽ������ַ���
			
			return jsonObject;
			
		} catch (Exception e) {
			jsonObject.put("Photo", "fail");
			e.printStackTrace();
			return jsonObject;
		}finally{
			
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		
	}

}
