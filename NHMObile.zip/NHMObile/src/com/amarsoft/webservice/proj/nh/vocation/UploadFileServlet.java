package com.amarsoft.webservice.proj.nh.vocation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.common.attachment.FileNameHelper;
import com.amarsoft.awe.util.ASResultSet;
import com.amarsoft.awe.util.DBKeyHelp;
import com.amarsoft.awe.util.SqlObject;
import com.amarsoft.awe.util.Transaction;
import com.amarsoft.biz.formatdoc.model.FormatDocConfig;
import com.amarsoft.context.ASUser;
import com.amarsoft.webservice.DBLink;

/**
 * @author lxu1
 *
 */
public class UploadFileServlet extends HttpServlet{
	
	 // �ϴ��ļ���
    private File fileUpload;
    // �ϴ��ļ�����
    private String imageContentType;
    // ��װ�ϴ��ļ���
    private String imageFileName;
    private String objectNo ;
    private String objectType ;
    private String filePath ;
    private String fileName ;
    private String userId ;
    private String fileType ;
    private String address ;
    private File uploadFile ; 
    private long fileLength ;
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF8") ;
		resp.setCharacterEncoding("UTF8") ;
		boolean isMultipart = ServletFileUpload.isMultipartContent(request) ;
		Transaction Sqlca = null;
//		String sFileSavePath = "/appfs/ncmsFile/als/Upload";    
		FormatDocConfig config = FormatDocConfig.getInstance();
		String sFileSavePath = config.getUploadSavePath();    
 		String sFileNameType = "SRC";       					
 		String sFileSaveMode = "Disk";		//����ļ���������
 		
		if(isMultipart){
			/*String dir = request.getSession().getServletContext().getRealPath("/images") ;
			File fileDir = new File(dir) ;
			if(!fileDir.exists()) fileDir.mkdirs() ;*/
			FileItemFactory factory = new DiskFileItemFactory() ;
			ServletFileUpload upload = new ServletFileUpload(factory) ;
			try {
				List<FileItem> items =  upload.parseRequest(request) ;
				
	        	Sqlca = DBLink.getSqlca();
	        	SqlObject so = null;
	        	String sFullPath = "";
	        	String sFilePath = "";
	        	
				DBKeyHelp.setDataSource("als");
	        	String sDocNo = DBKeyHelp.getSerialNo("REST_ATTACHMENT", "DOCNO");
	        	
				String sAttachmentNo = DBKeyHelp.getSerialNoFromDB("REST_ATTACHMENT","ATTACHMENTNO","DocNo='"+sDocNo+"'","","0000",new java.util.Date(),Sqlca);   
	        	
				for(FileItem item:items){
					if(item.isFormField()){
						if(item.getFieldName().equals("ObjectNo")){
							objectNo = item.getString() ;
						}else if(item.getFieldName().equals("ObjectType")){
							objectType = item.getString() ;
						}else if(item.getFieldName().equals("FilePath")){
							filePath = item.getString() ;
							filePath = new String(filePath.getBytes("iso-8859-1"), "UTF-8");
						}else if(item.getFieldName().equals("FileName")){
							fileName = item.getString() ;
							//�õ�����·�����ļ���
							fileName = StringFunction.getFileName(fileName);
							if(sFileSaveMode.equals("Disk")){ 
			             		sFullPath = getFullPath(sDocNo, sAttachmentNo,fileName, sFileSavePath, sFileNameType);
			              		//�õ������·�����ļ���
			             		sFilePath = FileNameHelper.getFilePath(sDocNo,sAttachmentNo,fileName,sFileNameType);
								ARE.getLog().info("�ļ����浽" + sFullPath);
							}
						}else if(item.getFieldName().equals("UserId")){
							userId = item.getString() ;
						}else if(item.getFieldName().equals("FileType")){
							fileType = item.getString() ;
						}else if(item.getFieldName().equals("Address")){
							address = item.getString() ;
							address = new String(address.getBytes("iso-8859-1"), "UTF-8");
							//System.out.println("address===============>"+address);
						}else{
							address = "" ;
						}
					}else{
						uploadFile = new File(sFullPath) ;
						item.write(uploadFile) ;
						FileInputStream fis = new FileInputStream(uploadFile) ; 
						fileLength = fis.available() ;
						fis.close() ;
					}
				}
				ASUser curUser = ASUser.getUser(userId, Sqlca);	
				String orgId = curUser.getOrgID();
				String sNewSql = "insert into REST_ATTACHMENT(DocNo,ObjectNo,ObjectType,AttachmentNo,Address) values(:DocNo,:ObjectNo,:ObjectType,:AttachmentNo,:Address)";
				so = new SqlObject(sNewSql).setParameter("DocNo",sDocNo).setParameter("ObjectNo", objectNo).setParameter("ObjectType", objectType).setParameter("Address", address).setParameter("AttachmentNo",sAttachmentNo);
				Sqlca.executeSQL(so);
				
				ASResultSet rs = Sqlca.getASResultSetForUpdate("SELECT REST_ATTACHMENT.* FROM REST_ATTACHMENT WHERE DocNo='"+sDocNo+"' and AttachmentNo='"+sAttachmentNo+"'");
				if(rs.next()){
		     		try {
		        		java.util.Date dateNow = new java.util.Date();
		        		SimpleDateFormat sdfTemp = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
		        		String sBeginTime=sdfTemp.format(dateNow);
		        		
						dateNow = new java.util.Date();
						String sEndTime=sdfTemp.format(dateNow);
			
						rs.updateString("FilePath",sFilePath); 
						rs.updateString("FullPath",sFullPath);
						rs.updateString("FileSaveMode",sFileSaveMode);  
						rs.updateString("FileName",fileName);  
						rs.updateString("ContentType",fileType);
						rs.updateString("ContentLength",fileLength+"");	
						rs.updateString("BeginTime",sBeginTime);
						rs.updateString("EndTime",sEndTime);
						rs.updateString("InputUser",userId);
						rs.updateString("InputOrg",orgId);
						rs.updateString("ContentStatus", "");
						rs.updateString("Address", address);
						rs.updateRow();
						rs.getStatement().close();

					}catch(Exception e){
						e.printStackTrace();
			           	sNewSql = "delete FROM REST_ATTACHMENT WHERE DocNo=:DocNo and AttachmentNo=:AttachmentNo";
			           	so = new SqlObject(sNewSql).setParameter("DocNo",sDocNo).setParameter("AttachmentNo",sAttachmentNo);
			           	Sqlca.executeSQL(so);
			           	rs.getStatement().close();
		     		}
			   	}
				
				
			} catch (Exception e) {
				System.out.println("�ļ��ϴ�ʧ��");
	            e.printStackTrace();
				try {
					Sqlca.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
			}finally {
	            try {
					Sqlca.commit();
					Sqlca.disConnect();
				} catch (SQLException e) {
					e.printStackTrace();
				}
	        }
		}else{
			//������ȡ
			doGet(request, resp) ;
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(null, resp) ;
	}

	public File getFileUpload() {
		return fileUpload;
	}

	public void setFileUpload(File fileUpload) {
		this.fileUpload = fileUpload;
	}

	public String getImageContentType() {
		return imageContentType;
	}

	public void setImageContentType(String imageContentType) {
		this.imageContentType = imageContentType;
	}

	public String getImageFileName() {
		return imageFileName;
	}

	public void setImageFileName(String imageFileName) {
		this.imageFileName = imageFileName;
	}

	private void close(FileOutputStream fos, FileInputStream fis) {
        if (fis != null) {
            try {
                fis.close();
                fis=null;
            } catch (IOException e) {
                System.out.println("FileInputStream�ر�ʧ��");
                e.printStackTrace();
            }
        }
        if (fos != null) {
            try {
                fos.close();
                fis=null;
            } catch (IOException e) {
                System.out.println("FileOutputStream�ر�ʧ��");
                e.printStackTrace();
            }
        }
    }
	/**
	 * 	��ȡ�ļ�ȫ·��
	 * @param sDocNo
	 * @param sAttachmentNo
	 * @param sFileName
	 * @param sFileSavePath
	 * @param sFileNameType
	 * @return
	 * @throws Exception
	 */
	public static String getFullPath(String sDocNo, String sAttachmentNo, String sFileName, String sFileSavePath, String sFileNameType)throws Exception{
	    
		File dFile = null;
	    String sBasePath = sFileSavePath;		//als7c.xml�����ļ������õ��ϴ��ļ���·��

	    String sFullPath = sBasePath + "/" + FileNameHelper.getMidPath(sDocNo, sAttachmentNo);
	    dFile = new File(sFullPath);
	    try {
	      if ((dFile.exists()) || (dFile.mkdirs())) {
	    	  
	        ARE.getLog().info("�������渽���ļ�·��[" + sFullPath + "]�����ɹ�����");
	      } else {
	    	  
	        ARE.getLog().trace("�������渽���ļ�·��[" + sFullPath + "]����ʧ�ܣ���");
	        throw new IOException("�������渽���ļ�·��[" + sFullPath + "]����ʧ�ܣ���");
	      }
	    } catch (SecurityException e) {
	      ARE.getLog().error(e.getMessage(), e);
	      throw new SecurityException("�������渽���ļ�����·��[" + sFullPath + "]�޷�����������Ŀ¼��дȨ�ޣ�");
	    }
	
	    String sFullName = sBasePath + "/" + FileNameHelper.getFilePath(sDocNo, sAttachmentNo, sFileName, sFileNameType);
	    return sFullName;
  }
	
}
