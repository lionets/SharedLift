package com.amarsoft.webservice.proj.nh.approve;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.Transaction;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.context.ASUser;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.webservice.DBLink;

/**
 * ����������Ϣ�鿴
 * ���������
		����������ˮ�ţ�SerialNo
	
 * ���������
	
	
 * @author jwu1 2015-11-20
 *
 */
public class ApproveDetailGroupHandler extends JSONHandlerWithSession {
	private String SerialNo = "";
	private String Relative = "";
	
	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		if(request.containsKey("SerialNo")){
			this.SerialNo = request.get("SerialNo").toString();
		}else{
			//throw new HandlerException("ȱ�ٲ���SerialNo");
		}
		if(request.containsKey("ApplyNo")){
			this.SerialNo = request.get("ApplyNo").toString();
		}
		if(request.containsKey("Relative")){		//BA:Business_Apply
			this.Relative = request.get("Relative").toString();
		}
		
		String sUserId = SessionManager.getUserId(this.getSessionKey());	//��ǰ��¼�û�ID

		//��ǰ����
		String today = StringFunction.getToday();

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sSql = "";
		String list = "";
		JSONObject result = new JSONObject();
		JSONArray resultArray = new JSONArray();
		
		if(Relative.equals("BA")){
			
			sSql = " Select SERIALNO,CUSTOMERNAME,BusinessSum,getBusinessName(BusinessType) as SmeBusinessTypeName,getItemName('Currency',BusinessCurrency) as BusinessCurrency From Business_Apply where SerialNo='"+SerialNo+"'  ";
		}else{
			
			sSql = "select SERIALNO,CUSTOMERNAME,BusinessSum,getBusinessName(BusinessType) as SmeBusinessTypeName,getItemName('Currency',BusinessCurrency) as BusinessCurrency from business_approve where SerialNo='"+SerialNo+"' ";
		}
		
		try {
			//�������ݿ�
			conn= ARE.getDBConnection("als");
			
			ARE.getLog().info(sSql);
			ps = conn.prepareStatement(sSql);
			JSONObject json=new JSONObject();
			JSONArray jsonArray = new JSONArray();
			rs = ps.executeQuery();
			
			if(Relative.equals("BA")){
				while(rs.next()){
					result.put("ApplyNo", rs.getString("SERIALNO")==null?"":rs.getString("SERIALNO"));//��ˮ��
					result.put("CustomerName", rs.getString("CUSTOMERNAME"));//�ͻ�����
					result.put("BusinessSum", (new DecimalFormat("#0.00").format(rs.getDouble("BusinessSum")/10000))+"��Ԫ");//���Ž��
					result.put("BusinessTypeName", rs.getString("SmeBusinessTypeName"));//ҵ��Ʒ��
					result.put("BusinessCurrencyName", rs.getString("BusinessCurrency"));//����
				}
			}else{
				while(rs.next()){
					json.put("ApplyNo", rs.getString("SERIALNO")==null?"":rs.getString("SERIALNO"));//��ˮ��
					json.put("CustomerName", rs.getString("CUSTOMERNAME"));//�ͻ�����
					json.put("BusinessSum", (new DecimalFormat("#0.00").format(rs.getDouble("BusinessSum")/10000))+"��Ԫ");//���Ž��
					json.put("BusinessTypeName", rs.getString("SmeBusinessTypeName"));//ҵ��Ʒ��
					json.put("BusinessCurrencyName", rs.getString("BusinessCurrency"));//����
				}
			}
			rs.getStatement().close();
			ps.close();
			result.put("ApproveLine", json);//
			
			//��ȡ�ӹ�˾��������Ϣ
			if(Relative.equals("BA")){
				
				list = "select ba.SerialNo,getBusinessName(ba.BusinessType) as SmeBusinessTypeName,ba.BusinessSum,ba.CustomerName as CustomerName,ba.CustomerID as CustomerID,(select OrgNature from ent_info where customerid=ba.CustomerID) as OrgNature from business_apply ba,APPROVE_RELATIVE ar where ba.serialno=ar.objectno and ar.serialno='"+SerialNo+"' and ba.BusinessType<>'3020'";
			}else{
				
				list = "select bap.SerialNo as SerialNo,getBusinessName(bap.BusinessType) as SmeBusinessTypeName,bap.BusinessSum,bap.CustomerName as CustomerName,bap.CustomerID as CustomerID,(select OrgNature from ent_info where customerid=bap.CustomerID) as OrgNature from business_approve bap,APPROVE_RELATIVE ar where bap.serialno=ar.objectno and ar.serialno='"+SerialNo+"' and bap.BusinessType<>'3020' ";	
			}
			
			ARE.getLog().info(list);
			ps = conn.prepareStatement(list);
			rs = ps.executeQuery();
			String CustomerType2="";
			while(rs.next()){
				JSONObject js=new JSONObject();
				js.put("ApplyNo", rs.getString("SerialNo"));//��ˮ��
				js.put("BusinessTypeName", rs.getString("SmeBusinessTypeName"));//ҵ��Ʒ��
				js.put("BusinessSum", (new DecimalFormat("#0.00").format(rs.getDouble("BusinessSum")/10000))+"��Ԫ");//���
				js.put("RelativeSerialNo", "BAP");//���
				js.put("CustomerType", "Group");
				js.put("CustomerName", rs.getString("CustomerName"));
				js.put("CustomerID", rs.getString("CustomerID"));
				if((rs.getString("OrgNature").equals("0101"))||(rs.getString("OrgNature").equals("0102"))){//����/�Ƿ�����ҵ//codeno = 'CustomerOrgType'
						CustomerType2="021";//021
					} else if((rs.getString("OrgNature").equals("0103"))//��ҵ��λ/��������/�������/���ڻ���/���幤�̻�/����
						||(rs.getString("OrgNature").equals("0104"))
						||(rs.getString("OrgNature").equals("0105"))
	  		            ||(rs.getString("OrgNature").equals("0106"))
	  		            ||(rs.getString("OrgNature").equals("0107"))
						||(rs.getString("OrgNature").equals("0199"))){
							CustomerType2="022";//022
					} else {
						throw new Exception("��˾�ͻ��������ʹ���");
				}
				js.put("CustomerType2", CustomerType2);//�ͻ�����
				jsonArray.add(js);
			}
			rs.getStatement().close();
			ps.close();
			if(Relative.equals("BA")){
				result.put("ArrayRelative", jsonArray);
			}else{
				result.put("ApproveLineArray", jsonArray);
			}
			
			
			return result;
		}catch (Exception e) {
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		finally{
			try{
				if(ps!=null)ps.close();
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
	}

}
