package com.amarsoft.webservice.proj.nh.approve;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.webservice.proj.nh.CreditOpinionSave;
/**
 * ��˾���Ŷ��ҵ�����������
 * @author Administrator
 * FlowTaskNo  ����approvelist����
   RelativeNo ����Approvelist��������ObjectNo��
   CustomerNo  ����approvelist����
   CustomerName ����approvelist����
   BusinessSum ��� �����洫��
   TermMonth ���ޣ����洫��
   CorpusPayMethod ���ʽ �����洫��
   VouchType ��Ҫ������ʽ �����洫��
   CycleFlag �Ƿ�ѭ�� �����洫��
   RateFloat ���ʸ���ֵ�����洫��
   BusinessType ҵ��Ʒ�֣����洫��
 *
 */

public class OpinionInsertHandler extends JSONHandlerWithSession {

	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		JSONObject response = new JSONObject();
		Connection conn = null;
		String sUserId = SessionManager.getUserId(this.getSessionKey());
		String sGetName = "select belongorg from user_info where userid = ?";
		String orgid = "";
		try {
			conn = ARE.getDBConnection("als");
			conn.setAutoCommit(false);
			PreparedStatement ps = conn.prepareStatement(sGetName);
			ps.setString(1, sUserId);
			ARE.getLog().info(sGetName+" userid="+sUserId);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				orgid = rs.getString("belongorg");
			}
			rs.getStatement().close();
			
			// ��ù�������
			String getBusinessInfo = "SELECT objecttype  FROM apply_relative where serialno =?";
			PreparedStatement psInfo = conn.prepareStatement(getBusinessInfo);
			psInfo.setString(1, request.get("RelativeNo").toString());
			ARE.getLog().info(getBusinessInfo);
			ResultSet rsInfo = psInfo.executeQuery();
			String relativeType = "";
			if(rsInfo.next()){
				relativeType = rsInfo.getString("objecttype");
				if(relativeType==null) relativeType="";
			}
			rsInfo.getStatement().close();
			
			ARE.getLog().info("��ȡ�����������Ϣ��������....");
			CreditOpinionSave creditOpinionSave = new CreditOpinionSave(
					request.get("FlowTaskNo").toString(), 
					relativeType,
					request.get("RelativeNo").toString(),
//					request.get("ObjectNo").toString(),
					"",
					request.get("CustomerNo").toString(),
					request.get("CustomerName").toString(),
//					request.get("BusinessCurrency").toString(),
					"",
					Double.parseDouble(request.get("BusinessSum").toString()),
					Integer.parseInt(request.get("TermMonth").toString()),
					"","",
//					request.get("BaseRateType").toString(),
//					request.get("RateFloatType").toString(),
					Double.parseDouble(request.get("RateFloat").toString()),
					request.get("BusinessType").toString(),
					0,0,0,
//					Double.parseDouble(request.get("BusinessRate").toString()),
//					Double.parseDouble(request.get("ExecuteYearRate").toString()),
//					Double.parseDouble(request.get("BaseRate").toString()),
					request.get("CorpusPayMethod").toString(),
					request.get("VouchType").toString(),
					request.get("CycleFlag").toString(), 0,0,0,0,
//					Double.parseDouble(request.get("BailSum").toString()),
//					Double.parseDouble(request.get("BailRatio").toString()),
//					Double.parseDouble(request.get("PdgSum").toString()),
//					Double.parseDouble(request.get("PdgRatio").toString()),
					orgid,
					sUserId, 
					"1");
			creditOpinionSave.save(conn);
		
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			throw new HandlerException(e.getMessage());
		}

		finally {
			try {
				conn.commit();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				ARE.getLog().error("���ݿ�ر�ʧ��:" + e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}
}
