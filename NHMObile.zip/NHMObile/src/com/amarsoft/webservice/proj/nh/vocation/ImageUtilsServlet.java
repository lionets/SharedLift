package com.amarsoft.webservice.proj.nh.vocation;

/**
 * @author lxu1
 *
 */
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import com.amarsoft.are.ARE;
import com.amarsoft.mobile.webservice.security.Base64;
public class ImageUtilsServlet extends HttpServlet {
	
	private static final long serialVersionUID = 124354567890543L;

	public void service(HttpServletRequest request, HttpServletResponse response) {
		
		JSONObject result = JSONObject.fromObject(request.getParameter("params")) ;
		
		String sDocNo = result.getString("DocNo");
		String sPhotoID = result.getString("ObjectNo");
		String sObjectType = result.getString("ObjectType");		//����Ԥ�������鿴&Ӱ������ͼƬ�鿴	flag:AfterLoan(Ӱ��) flag:RiskSignalApply
		
		Connection conn = null;
		ResultSet rs = null;
		String photoPath = "";		//ͼƬ·��
		String sSql = "";
		
		try {
			//��ȡͼƬ·��
			if(sObjectType.equals("AfterLoan")){
				
				//sSql = " SELECT DocumentID as PhotoPath FROM ecm_page where serialno='"+sPhotoID+"' ";	
				sSql = " SELECT EPF.documentId||'/'||EPF.FileName as PhotoPath FROM   ECM_PAGE_NEW EPN,ECM_PAGE_FILE EPF" +
						" where (EPF.EndTime='' or EPF.EndTime is null or EPN.ModifyTime <= EPF.EndTime) and EPN.TypeNo=EPF.TypeNo and EPN.DocumentID=EPF.DocumentID " +
						"and EPF.SerialNo='"+sPhotoID+"' and EPN.ObjectType='AfterLoan' and EPN.documentId is not null  with ur ";	

			}else if(sObjectType.equals("RiskSignalApply")){
				sSql = " select FullPath as PhotoPath from REST_ATTACHMENT where ObjectNo='"+sPhotoID+"' and ObjectType='"+sObjectType+"' and DocNo='"+sDocNo+"' ";
			}
			//�������ݿ�
			conn= ARE.getDBConnection("als");
			ARE.getLog().info(sSql);
			PreparedStatement ps = conn.prepareStatement(sSql);
			rs = ps.executeQuery();
			if(rs.next()){
				photoPath = rs.getString("PhotoPath")==null?"":rs.getString("PhotoPath").toString();
			}
			rs.getStatement().close();
			/*multipart/form-data*/
			response.setContentType("text/html;charset=UTF-8");
			FileInputStream fis=new FileInputStream(photoPath);
			ByteArrayOutputStream baos=new ByteArrayOutputStream();
			byte[] buffer=new byte[8192];
			int count=0;
			while((count=fis.read(buffer))>=0){
			baos.write(buffer);
			}
			String str=new String(Base64.encode(baos.toByteArray()));
			PrintWriter pw=response.getWriter();
			pw.write(str);
			pw.flush();
			pw.close();
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally{
			
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
	}

}
