package com.amarsoft.webservice.proj.nh.bizquery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
/**
 * ��������ҵ���ѯ
 * ���������
	SearchKey ����������֤�����룬�ͻ����ƣ�
	CurPage - ����ҳ��
	PageSize - ÿҳ��ʾ������
 * ���������
 * DueArray:
	CustomerName -- �ͻ�����
	CustomerNo --�ͻ����
	LoanBalance -- �������
 * @author 
 *
 */

public class CustomerBizListHandler extends JSONHandlerWithSession {

	private String sOrgID = "";
	private String SearchKey = "";
	private int PageSize = 20;
	private int CurPage = 0;
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		JSONObject response = new JSONObject();
		Connection conn = null;
		
		if(request.containsKey("SearchKey"))//��ѯ����
			this.SearchKey = request.get("SearchKey").toString();
		if(request.containsKey("PageSize"))
			this.PageSize = Integer.parseInt(request.get("PageSize").toString());
		if(request.containsKey("CurPage"))
			this.CurPage = Integer.parseInt(request.get("CurPage").toString());
		
		String sUserId = SessionManager.getUserId(this.getSessionKey());//�û���
		String sSql = "select belongorg as InputOrgID FROM USER_INFO " +
				      " where userid = ?";
		
		try {
			conn= ARE.getDBConnection("als");
			PreparedStatement ps = conn.prepareStatement(sSql);
			ps.setString(1, sUserId);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				this.sOrgID = rs.getString("InputOrgID");
			}
			rs.getStatement().close();
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		
		String sSqlDuel = " select bd.CustomerName as CustomerName," +//�ͻ�����
						" bd.CustomerID as CustomerNo, "+//�ͻ����
						" sum(bd.balance) as LoanBalance,"+//�������
						" rownumber() over(order by sum(bd.balance) desc) AS rn"+
						" from  BUSINESS_DUEBILL bd" +
						" where  bd.OperateOrgID in  (select OrgID from ORG_INFO where SortNo like '"+sOrgID+"%') " +
						" and (bd.FinishDate is null  or bd.FinishDate = ' ' or bd.FinishDate = '')" ;

		if((SearchKey==null) || SearchKey.equals("")){//��ʼҳ�棬��ѯ����Ϊ��
			String sWhereClause = " and 1=2 ";
			sSqlDuel+=sWhereClause;
		}
		else {
			String sWhereClause = " and (bd.customerid in (select customerid from customer_info where certid like '%"+SearchKey+"%') or bd.customername like '%"+SearchKey+"%')";
			sSqlDuel+=sWhereClause;
		}
		String sGroup = " group by bd.customerid,bd.customername order by LoanBalance desc";
		sSqlDuel+=sGroup;
		
		try {
			conn= ARE.getDBConnection("als");
//			PreparedStatement ps = conn.prepareStatement(sSql);
//			ps.setString(1, sUserId);
//			ResultSet rs = ps.executeQuery();
//			if(rs.next()){
//				this.sOrgID = rs.getString("InputOrgID");
//			}
//			rs.getStatement().close();
			
//			sSqlDuel = Pageable.getPageable().getPagedSqlByPageNum(sSqlDuel, this.CurPage, this.PageSize);
			sSqlDuel = "SELECT * FROM (" + sSqlDuel + ") as PAGETABLE where PAGETABLE.rn BETWEEN "+ (this.PageSize * this.CurPage + 1) + " AND " + ((1 + this.CurPage) * this.PageSize);
			JSONArray resultArray = new JSONArray();
			PreparedStatement psDue = conn.prepareStatement(sSqlDuel);
//			psDue.setString(1, sOrgID);
			ARE.getLog().info(sSqlDuel);
			ResultSet rsDue = psDue.executeQuery();
			while(rsDue.next()){
				JSONObject obj = new JSONObject();
				obj.put("CustomerName", rsDue.getString("CustomerName"));//�ͻ�����
				obj.put("CustomerNo", rsDue.getString("CustomerNo"));//�ͻ����
				obj.put("LoanBalance", (new DecimalFormat("#0.00").format(rsDue.getDouble("LoanBalance")/10000))+"��Ԫ");//�������
				resultArray.add(obj);
			}
			rsDue.getStatement().close();
			response.put("DueArray", resultArray);
			
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}

}
