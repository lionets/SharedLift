package com.amarsoft.webservice.proj.nh.afterloan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.security.Base64;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.webservice.proj.nh.PhotoSave;
/**
 * �����鱣��
 * ���������
  CheckNums ����
  CustomerNums �ͻ����
  CheckDes ���˵��
  CheckTime ���ʱ��
  CheckDate �������
  PhotoDes ��Ƭ����
  PhotoDatas ��Ƭ����
 * ���������

 * @author 
 *
 */

public class CheckSaveHandler extends  JSONHandlerWithSession{
//	private String CustomerNo;
//	private String CustomerType;
	
	public static String sbizType = "Afterloan";
	public static String sObjetctype = "Afterloan";
	
	
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		
	
		Connection conn = null;
		JSONObject response = new JSONObject();
		String date;
		String time;
		String orgId="";
		int isHas =1;
		
	    String objectNo = request.get("CustomerNums").toString();//�ͻ����
		String SerialNo = request.get("CheckNums").toString();//����
		ARE.getLog().info(SerialNo+"cccccccccccc");
		String InputDate = request.get("CheckDate").toString();
		String CheckDes = request.get("CheckDes").toString();		
		String CheckTime = request.get("CheckTime").toString();
		
		try {
			  conn= ARE.getDBConnection("als");
			  
			  String sUserId = SessionManager.getUserId(this.getSessionKey());//�û���
 
			  String sql=" select belongorg from user_info where userid=?";
			  
			  PreparedStatement ps1 = conn.prepareStatement(sql);
			  
			  ps1.setString(1, sUserId);
			  
			  ResultSet rs1 = ps1.executeQuery();
			  if(rs1.next()) {
				  orgId = rs1.getString("belongorg");
			  }
			  rs1.getStatement().close();
			
			  Calendar calendat = Calendar.getInstance();
		      Date date_2 = calendat.getTime();
		        
		      //����  
		      SimpleDateFormat simpleDateFormate_2 = new SimpleDateFormat("yyyy/MM/dd");
		       //ʱ��
		      SimpleDateFormat simpleDateFormate_3 = new SimpleDateFormat("HH:mm:ss");
		        
	          date = simpleDateFormate_2.format(date_2);//����
	          time =simpleDateFormate_3.format(date_2);//ʱ��
	          System.out.println("yyyy-MM-dd HH:mm:ss"+simpleDateFormate_2.format(date_2));
	          System.out.println("HH:mm:ss"+simpleDateFormate_3.format(date_2));
	          
	          //�����¼
			  String sqlinsert ="insert into INSPECT_INFO(ObjectType,ObjectNo,SerialNo,remark,"
					+ "InputUserID,InputOrgID,InputDate,INSPECTDATE,Opinion1,steptype) values"
					+ "(?,?,?,?,?,?,?,?,?,?)";
			  //�鿴�Ƿ��Ѵ��ڼ�¼
			  String sql3 = " select * from inspect_info where  objecttype='MobileCustomer' and serialno =? and objectno=?";
			  //���¼�¼
			  String sqlupdate = " update inspect_info set INSPECTDATE=?,INSPECTUSERID=?,"
			  			+ "remark=?,OPINION1=?,UPDATEDATE=?"//opinion1 �洢ʱ��
			  			+ " where objecttype='MobileCustomer' and objectno=? and serialno =?";
			
			//ɾ����Ƭ��Ϣ
			String sDeletePhoto = " delete from photo_info where biztype = 'Afterloan' and objecttype = 'Afterloan' and objectno = ?";
			
			
			
			PreparedStatement psIs = conn.prepareStatement(sql3); 
			psIs.setString(1,SerialNo);
			psIs.setString(2,objectNo);
			ResultSet rsIs = psIs.executeQuery();
			if(rsIs.next()) {
				  isHas=0;
			}
			rsIs.getStatement().close();
			ARE.getLog().info(sql3+" "+SerialNo+" "+objectNo);
			ARE.getLog().info("ishas:"+isHas);
			conn.setAutoCommit(false);
			if(isHas==1){//����������insert
				PreparedStatement psinsert = conn.prepareStatement(sqlinsert);
				
				psinsert.setString(1, "MobileCustomer");	
				psinsert.setString(2, objectNo);
				psinsert.setString(3, SerialNo);	
				psinsert.setString(4, CheckDes);	
				psinsert.setString(5, sUserId);	
				psinsert.setString(6, orgId);	
				psinsert.setString(7, date);	
				psinsert.setString(8, date);	
				psinsert.setString(9, time);
				psinsert.setString(10, "1");//add by ldfang
				ARE.getLog().info(sqlinsert);
				psinsert.executeUpdate();
				
				if(!request.containsKey("PhotoDatas")){
					throw new HandlerException("ȱ��ͼƬ����");
				}
				else if (!(request.get("PhotoDatas").toString().equals(""))) {//����Ƭ
					PhotoSave psave = new PhotoSave(sbizType,sObjetctype,SerialNo);
					ArrayList<byte[]> photoDatalist = createPhotoDataList(request.get("PhotoDatas").toString());
					psave.setInputUser(sUserId);
					psave.setPhotoDesc(request.get("PhotoDes").toString());
					psave.setLatitude(Double.parseDouble(request.get("Latitude").toString()));
					psave.setLongitude(Double.parseDouble(request.get("Longitude").toString()));
//             		psave.setAddress(request.get("Address").toString());
					psave.save(photoDatalist, conn);
				}
				else {//����Ƭ
					
				}
			
			}
			else if (isHas==0) {//���±��������update
				PreparedStatement psupdate = conn.prepareStatement(sqlupdate);
				
				psupdate.setString(1, InputDate);
				psupdate.setString(2, sUserId);	
				psupdate.setString(3, CheckDes);	
				psupdate.setString(4, CheckTime);	
				psupdate.setString(5, date);	
				psupdate.setString(6, objectNo);	
				psupdate.setString(7, SerialNo);	
				psupdate.executeUpdate();
				ARE.getLog().info(sqlupdate);
				if(!request.containsKey("PhotoDatas")){
					throw new HandlerException("ȱ��ͼƬ����");
				}
				else {//������ɾ����
					//ɾ��ԭ��Ƭ��¼
					PreparedStatement psDelete = conn.prepareStatement(sDeletePhoto);
					psDelete.setString(1, SerialNo);
					ARE.getLog().info(sDeletePhoto);
					psDelete.executeUpdate();
					if(!(request.get("PhotoDatas").toString().equals(""))){//�������Ƭ��Ϣ��������
						//������Ƭ
						PhotoSave psave = new PhotoSave(sbizType,sObjetctype,SerialNo);
						ArrayList<byte[]> photoDatalist = createPhotoDataList(request.get("PhotoDatas").toString());
						psave.setInputUser(sUserId);
						psave.setPhotoDesc(request.get("PhotoDes").toString());
						psave.setLatitude(Double.parseDouble(request.get("Latitude").toString()));
						psave.setLongitude(Double.parseDouble(request.get("Longitude").toString()));
//	        	        psave.setAddress(request.get("Address").toString());
						psave.save(photoDatalist, conn);
					}
				}
			}
			conn.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			
			
		} finally{
			try{
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		
		return response;
		
		
	
	}
	//������Ƭ�����б�
		private ArrayList<byte[]> createPhotoDataList(String photodatas)throws Exception{
			String[] photoDatas = photodatas.split("\\,");
			ArrayList<byte[]> photoDatalist = new ArrayList<byte[]>();
			for(int i=0;i<photoDatas.length;i++)
				photoDatalist.add(Base64.decode(photoDatas[i]));
			return photoDatalist;
		}
	
	
	
	
}