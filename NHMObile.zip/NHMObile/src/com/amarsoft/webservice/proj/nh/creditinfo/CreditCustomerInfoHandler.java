/**
 * 
 */
package com.amarsoft.webservice.proj.nh.creditinfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;

/**
 * @author Administrator
 * �����ͽ��棩��ÿͻ���Ϣ��ѡ���
 */
public class CreditCustomerInfoHandler extends JSONHandlerWithSession{

	private int pageSize = 20;
	private String BStatus = "01";
	private int curPage = 0;
	private String SearchKey = "";
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
//		Pageable.setDBType("DB2");
		Connection conn = null;
		JSONObject response = new JSONObject();
		if(request.containsKey("BStatus"))//�ͻ�����
			this.BStatus = request.get("BStatus").toString();
		
		if(request.containsKey("PageSize")){//ÿҳ����
			this.pageSize = Integer.parseInt(request.get("PageSize").toString());
		}
		if(request.containsKey("CurPage")){//��ǰҳ��
			this.curPage = Integer.parseInt(request.get("CurPage").toString());
		}
		if (request.containsKey("SearchKey")) {//��ѯ�������ƶ��绰/�ͻ�����/֤�����룩
			this.SearchKey = request.get("SearchKey").toString();
		}
		String sUserId = SessionManager.getUserId(this.getSessionKey());//�û���
		
		//��˾�ͻ�
		String sSql2 =  " select CI.CustomerName as CustomerName,CB.CustomerID as CustomerID," +
						" CI.LoanCardNo as LoanCardNo " +
						" from CUSTOMER_INFO CI,CUSTOMER_BELONG CB,ENT_INFO EI"+ 
						" where CI.CustomerID = CB.CustomerID and CB.UserID =? and CI.CustomerType like '0110%' and EI.CustomerID=CI.CustomerID "
						+ " and (EI.COOPERATIONTYPE=' ' or EI.COOPERATIONTYPE is null) "
						 + " and  CB.BelongAttribute1='1' ";//���в鿴Ȩ
		if(!(SearchKey.equals(""))){//��ѯ�������ͻ����ƺ�֤�����룩
			String sWhereClause2 = " and (CI.CustomerName like '%"+SearchKey+"%' or CI.CertID like '%"+SearchKey+"%')";
			sSql2+=sWhereClause2;
		}					  
		String sOrderClause2 = " order by CI.CustomerID desc";
		sSql2+=sOrderClause2;
		
		//���˿ͻ�
		String sSql3 = " select CI.CustomerName as CustomerName,CB.CustomerID as CustomerID," +
					   " CI.CertID as CertID,CI.CertType as CertType,getItemName('CertType',CI.CertType) as CertTypeName "+
					   " from CUSTOMER_INFO CI,CUSTOMER_BELONG CB,IND_INFO II"+
					   " where CI.CustomerID = CB.CustomerID and CB.UserID =? and CI.CustomerType like '0310%'  and II.CustomerID=CI.CustomerID "
					   + " and  CB.BelongAttribute1='1' ";//���в鿴Ȩ
		if(!(SearchKey.equals(""))){//��ѯ��������ϵ���롢�ͻ����ơ�֤������
			String sWhereClause3 = " and (CI.CustomerName like '%"+SearchKey+"%' or II.MOBILETELEPHONE like '%"+SearchKey+"%' or CI.CertID like '%"+SearchKey+"%')";
			sSql3+=sWhereClause3;
		}					  
		String sOrderClause3 = " order by CI.CustomerID desc";
		sSql3+=sOrderClause3;

		try {
			conn= ARE.getDBConnection("als");
			JSONArray result = new JSONArray();
		
			if("01".equals(BStatus)){//��˾�ͻ�
				sSql2 = Pageable.getPageable().getPagedSqlByPageNum(sSql2, this.curPage, this.pageSize);
				ARE.getLog().info(sSql2);
				PreparedStatement ps = conn.prepareStatement(sSql2);
				ps.setString(1, sUserId);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					JSONObject obj = new JSONObject();
					obj.put("CustomerID", rs.getString("CustomerID"));
					obj.put("CustomerName", rs.getString("CustomerName"));
					obj.put("LoanCardNo", rs.getString("LoanCardNo"));
					result.add(obj);
				}
				rs.getStatement().close();
			}
			else if("02".equals(BStatus)){//���˿ͻ�
				sSql3 = Pageable.getPageable().getPagedSqlByPageNum(sSql3, this.curPage, this.pageSize);
				ARE.getLog().info(sSql3);
				PreparedStatement ps = conn.prepareStatement(sSql3);
				ps.setString(1, sUserId);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					JSONObject obj = new JSONObject();
					obj.put("CustomerID", rs.getString("CustomerID"));//�ͻ����
					obj.put("CustomerName", rs.getString("CustomerName"));//�ͻ�����
					obj.put("CertTypeName", rs.getString("CertTypeName"));//֤�����ʹ���
					obj.put("CertType", rs.getString("CertType"));//֤����������
					obj.put("CertID", rs.getString("CertID"));//֤������
					result.add(obj);
				}
				rs.getStatement().close();
			}
			response.put("array", result);	
			
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	
	}

}
