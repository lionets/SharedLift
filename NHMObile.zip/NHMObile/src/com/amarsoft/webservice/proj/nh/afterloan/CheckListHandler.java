package com.amarsoft.webservice.proj.nh.afterloan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.DBHandler;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;

/**
 * �������б� ���������
 * PageSize
 * CurPage
 * BStatus
 * ���������
 * CustomerId
 * CustomerName
 * CheckDate
 * TelePhone
 * SerialNo
 * 
 * @author
 * 
 */

public class CheckListHandler extends JSONHandlerWithSession {

	private int pageSize;

	// add 20140214
	private int curPage = 0;

	private String SearchKey = "";
	private String CustomerType = "";

	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {

		Connection conn = null;
		JSONObject response = new JSONObject();

		if (request.containsKey("PageSize")) {// ÿҳ����
			this.pageSize = Integer
					.parseInt(request.get("PageSize").toString());
		}
		if (request.containsKey("CurPage")) {// ��ǰҳ��
			this.curPage = Integer.parseInt(request.get("CurPage").toString());
		}
		if (request.containsKey("SearchKey")) {// ��ѯ������֤�����룩
			this.SearchKey = request.get("SearchKey").toString();
		}
		if (request.containsKey("BStatus")) {// ��ѯ������֤�����룩
			this.CustomerType = request.get("BStatus").toString();
		}

		String sUserId = SessionManager.getUserId(this.getSessionKey());// �û���
		JSONArray result = new JSONArray();

		String sSql1 = " select objectno as CustomerId,getCustomerName(objectno) as CustomerName,INSPECTDATE as CheckDate,serialno as SerialNo,rownumber() over(order by serialno desc) AS rn "
					+ " from inspect_info where objecttype = 'MobileCustomer'  and objectno in (select customerid from customer_info where customertype like '01%') and inputuserid=?";

		String sSql2 = " select objectno as CustomerId,getCustomerName(objectno) as CustomerName,INSPECTDATE as CheckDate,serialno as SerialNo,rownumber() over(order by serialno desc) AS rn "
				+ " from inspect_info where objecttype = 'MobileCustomer'  and objectno in (select customerid from customer_info where customertype like '03%') and inputuserid=?";

		
		if (!(SearchKey.equals(""))) {// ��ѯ�������ͻ����ƺ�֤�����룩
			String sWhereClause1 = "  and ( getCustomerName(objectno) like '%" + SearchKey
					+ "%' or objectno in (select customerid from customer_info where certid like '%"+ SearchKey + "%'))";
			sSql1 += sWhereClause1;
			sSql2 += sWhereClause1;
		}
		
		String sOrderClause1 = " order by inspect_info.SerialNo desc";
        
		sSql1+=sOrderClause1;
		sSql2+=sOrderClause1;
		


		try {
			conn = ARE.getDBConnection("als");

			if (CustomerType.equals("01")) {//��˾
				System.out.println("before-----");
				Pageable.setDBType("db2");

				sSql1 = "SELECT * FROM (" + sSql1 + ") as PAGETABLE where PAGETABLE.rn BETWEEN "+ (this.pageSize * this.curPage + 1) + " AND " + ((1 + this.curPage) * this.pageSize);
				
				ARE.getLog().info(sSql1);

				PreparedStatement ps = conn.prepareStatement(sSql1);
				ps.setString(1, sUserId);

				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					JSONObject obj = new JSONObject();

					obj.put("CustomerName", rs.getString("CustomerName"));

					obj.put("SerialNo", rs.getString("SerialNo"));
					obj.put("CheckDate", rs.getString("CheckDate"));

					obj.put("CustomerId", rs.getString("CustomerId"));
					String sCustomerid = rs.getString("CustomerId");
					String sql11 = " select OFFICETEL from ent_info where customerid=?";
					PreparedStatement pssql=conn.prepareStatement(sql11);
					pssql.setString(1, sCustomerid);
					ResultSet rssql =pssql.executeQuery();
					if (rssql.next()) {
						obj.put("TelePhone", rssql.getString("OFFICETEL"));
					}
					rssql.getStatement().close();
					result.add(obj);
				}

				rs.getStatement().close();
			} else if (CustomerType.equals("02")) {//�ͻ�


				sSql2 = "SELECT * FROM (" + sSql2 + ") as PAGETABLE where PAGETABLE.rn BETWEEN "+ (this.pageSize * this.curPage + 1) + " AND " + ((1 + this.curPage) * this.pageSize);
				ARE.getLog().info(sSql2);

				PreparedStatement ps = conn.prepareStatement(sSql2);
				ps.setString(1, sUserId);
				ResultSet rs = ps.executeQuery();

				System.out.println("after-----");
				ARE.getLog().info(sSql2);
				while (rs.next()) {
					JSONObject obj = new JSONObject();

					obj.put("CustomerName", rs.getString("CustomerName"));
//					obj.put("TelePhone", rs.getString("TelePhone"));
					obj.put("SerialNo", rs.getString("SerialNo"));
					obj.put("CheckDate", rs.getString("CheckDate"));
//					obj.put("InputOrgID", rs.getString("InputOrgID"));
					obj.put("CustomerId", rs.getString("CustomerId"));
					String sCustomerid = rs.getString("CustomerId");
					String sql11 = " select MOBILETELEPHONE from ind_info where customerid=?";
					PreparedStatement pssql=conn.prepareStatement(sql11);
					pssql.setString(1, sCustomerid);
					ResultSet rssql =pssql.executeQuery();
					if (rssql.next()) {
						obj.put("TelePhone", rssql.getString("MOBILETELEPHONE"));
					}
					rssql.getStatement().close();
					result.add(obj);
				}
				rs.getStatement().close();
			}

			response.put("array", result);

		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			return null;
		}

		finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				ARE.getLog().error("���ݿ�ر�ʧ��:" + e.getMessage());
				e.printStackTrace();
			}
		}

		return response;

	}

}
