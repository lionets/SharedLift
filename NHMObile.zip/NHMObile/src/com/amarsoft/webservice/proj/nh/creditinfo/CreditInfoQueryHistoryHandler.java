package com.amarsoft.webservice.proj.nh.creditinfo;

import java.sql.Connection;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.DBHandler;
/**
 * ���Ų�ѯ����ʷ
 * ���������

 * ���������

 * @author 
 *
 */

public class CreditInfoQueryHistoryHandler extends DBHandler {
	private int pageSize = 20;
	private String BStatus = "01";
	private int CreTime = 0;
	protected Object createReponseWithDB(JSONObject request, Properties arg1,
			Connection conn) {
		if(request.containsKey("BStatus"))
			this.BStatus = request.get("BStatus").toString();
		if(request.containsKey("CreTime"))
			this.CreTime = Integer.parseInt(request.get("CreTime").toString());
		conn = null;
		try {
			conn= ARE.getDBConnection("als");
			JSONObject response = new JSONObject();
			JSONArray result = new JSONArray();
			if("01".equals(BStatus)){
				if(CreTime == 0){
					for (int i = 0; i < pageSize; i++) {
						JSONObject obj = new JSONObject();
						obj.put("QueryDate", "20140121-"+i);
						obj.put("CustomerName", "�Ϻ�ĳ��ҵA-"+i);
						obj.put("CustomerPhone", "1383838383-"+i);
						result.add(obj);
					}
				}else if(CreTime > 0 && CreTime < 3){
					for (int i = 0; i < pageSize; i++) {
						JSONObject obj = new JSONObject();
						obj.put("QueryDate", "20150121-"+i);
						obj.put("CustomerName", "�Ϻ�ĳ��ҵB-"+i);
						obj.put("CustomerPhone", "1393939393-"+i);
						result.add(obj);
					}
				}else{
					for (int i = 0; i < 5; i++) {
						JSONObject obj = new JSONObject();
						obj.put("QueryDate", "20160121-"+i);
						obj.put("CustomerName", "�Ϻ�ĳ��ҵC-"+i);
						obj.put("CustomerPhone", "1404040404-"+i);

						result.add(obj);
					}
				}
			}else if("02".equals(BStatus)){
				if(CreTime == 0){
					for (int i = 0; i < pageSize; i++) {
						JSONObject obj = new JSONObject();
						obj.put("QueryDate", "20000121-"+i);
						obj.put("CustomerName", "�Ϻ�ĳ��˾A-"+i);
						obj.put("CustomerPhone", "11111111111-"+i);
						result.add(obj);
					}
				}else if(CreTime > 0 && CreTime < 3){
					for (int i = 0; i < pageSize; i++) {
						JSONObject obj = new JSONObject();
						obj.put("CustomerNo", "20010121-"+i);
						obj.put("CustomerName", "�Ϻ�ĳ��˾B-"+i);
						obj.put("CustomerPhone", "22222222222-"+i);
						result.add(obj);
					}
				}else{
					for (int i = 0; i < 5; i++) {
						JSONObject obj = new JSONObject();
						obj.put("CustomerNo", "20020121-"+i);
						obj.put("CustomerName", "�Ϻ�ĳ��˾C-"+i);
						obj.put("CustomerPhone", "33333333333-"+i);
						result.add(obj);
					}
				}
			
			}
			response.put("array", result);
			return response;
			
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		
		finally{
			try{
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

	}

}
