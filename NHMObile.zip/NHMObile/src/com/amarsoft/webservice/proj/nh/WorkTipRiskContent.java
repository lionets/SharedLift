/**
 * 
 */
package com.amarsoft.webservice.proj.nh;

/**
 * @author Administrator
 * 
 */
public class WorkTipRiskContent {

	// ҵ���ڣ�5��
	private String sql0 = "select count(*) as count from BUSINESS_DUEBILL where Maturity >= ? and Maturity<=? and OperateOrgID = ? and OperateUserID = ? and (FinishDate is null or FinishDate = '' or FinishDate=' ') ";

	private String sql01 = "select '['|| CustomerName|| ']'|| getBusinessName(businesstype) || ' �����գ�'||Maturity || ' ���Ž�'||BusinessSum || '  ��'||Balance as detail,"
			+ "BusinessType,BusinessSum,Balance,Maturity,InterestBalance1,InterestBalance2,FineBalance1,FineBalance2  from BUSINESS_DUEBILL where Maturity >= ? "
			+ "and Maturity<=? and OperateOrgID = ? and OperateUserID = ? and (FinishDate is null or FinishDate = '' or FinishDate=' ') ";
	// ҵ����(15)
	private String sql1 = "select count(*) as count from BUSINESS_DUEBILL where Maturity >= ? and Maturity<=? and OperateOrgID = ? and OperateUserID = ? and (FinishDate is null or FinishDate = '' or FinishDate=' ') ";

	private String sql11 = "select '['|| CustomerName|| ']'|| getBusinessName(businesstype) || ' �����գ�'||Maturity || ' ���Ž�'||BusinessSum || '  ��'||Balance as detail,"
			+ "BusinessType,BusinessSum,Balance,Maturity,InterestBalance1,InterestBalance2,FineBalance1,FineBalance2  from BUSINESS_DUEBILL where Maturity >= ? "
			+ "and Maturity<=? and OperateOrgID = ? and OperateUserID = ? and (FinishDate is null or FinishDate = '' or FinishDate=' ') ";
	// ����ҵ��
	private String sql2 = "select count(*) as count from BUSINESS_DUEBILL where   to_date(MATURITY,'yyyy-mm-dd') < current_date  and OperateUserID=? and OperateOrgID=? ";
	private String sSql22 = "select '['|| CustomerName|| ']'|| getBusinessName(businesstype) || ' ����������'||nvl(OVERDUEDAYS,0) || '��   ��'||Balance as detail,"
			+ " BUSINESS_DUEBILL.CUSTOMERNAME as CUSTOMERNAME,BUSINESS_DUEBILL.BUSINESSTYPE as BUSINESSTYPE,BUSINESS_DUEBILL.BILLNO as BILLNO,BUSINESS_DUEBILL.BUSINESSSUM as BUSINESSSUM,BUSINESS_DUEBILL.BALANCE as BALANCE,BUSINESS_DUEBILL.PutoutDate as PutoutDate,BUSINESS_DUEBILL.Maturity as Maturity,BUSINESS_DUEBILL.OVERDUEDAYS as OVERDUEDAYS,BUSINESS_DUEBILL.INPUTUSERID as INPUTUSERID,getUserName(INPUTUSERID) as InputUserName,BUSINESS_DUEBILL.InputOrgID as InputOrgID,getOrgName(InputOrgID) as InputOrgName,BUSINESS_DUEBILL.SerialNo as SerialNo "
			+ " from BUSINESS_DUEBILL where   to_date(MATURITY,'yyyy-mm-dd') < current_date  and OperateUserID=? and OperateOrgID=?  order by OVERDUEDAYS desc";
	// ǷϢҵ��
	private String sql3 = "select count(*) as count from BUSINESS_DUEBILL bd,IND_INFO II where    bd.CUSTOMERID = II.CUSTOMERID and  ( BD.Tabalance > 0 or bd.TaInterestBalance > 0) and BD.OperateUserID=?  and BD.OperateOrgID=? ";
	private String sSql33 = "select '['|| BD.CustomerName|| ']'|| getBusinessName(BD.businesstype) || ' Ƿ��ǷϢ���ϼƣ�'||(BD.Tabalance+BD.TaInterestBalance+BD.FineBalance2) || '  ��'||BD.Balance as detail,"
			+ "BD.SerialNo as SerialNo,II.CustomerID as CustomerID,BD.CUSTOMERNAME as CUSTOMERNAME,II.Familytel as FamilyTel,II.WorkTel as WorkTel,II.MobileTelephone as MobileTelephone,II.CertType as CertType,getItemName('CertType',II.CertType) as CertTypeName,II.CertID as CertID,BD.BUSINESSTYPE as BUSINESSTYPE,BD.BILLNO as BILLNO,BD.BUSINESSSUM as BUSINESSSUM,BD.BALANCE as BALANCE,BD.Tabalance as TaBalance,BD.TaInterestBalance as TaInterestBalance,BD.FineBalance2 as FineBalance2,(BD.Tabalance+BD.TaInterestBalance+BD.FineBalance2) as AllSum,BD.PutoutDate as PutoutDate,BD.Maturity as Maturity,BD.INPUTUSERID as INPUTUSERID,getUserName(BD.INPUTUSERID) as InputUserName,BD.InputOrgID as InputOrgID,getOrgName(BD.InputOrgID) as InputOrgName from BUSINESS_DUEBILL bd,IND_INFO II where    bd.CUSTOMERID = II.CUSTOMERID and  ( BD.Tabalance > 0 or bd.TaInterestBalance > 0) and BD.OperateUserID=?  and BD.OperateOrgID=?  order by AllSum desc";
	// ����ƻ����ڣ�5�죩
	private String sql4 = "select count(*) as count from BUSINESS_DUEBILL where Maturity >=? and Maturity<=? and OperateOrgID = ? and OperateUserID = ? and (FinishDate is null or FinishDate = '' or FinishDate=' ')";
	private String sSql44 = "select '['|| CustomerName|| ']'|| getBusinessName(businesstype) || ' �����գ�'||Maturity || ' ���Ž�'||BusinessSum || '  ��'||Balance as detail,"
			+ "RelativeSerialNo2,SerialNo,CustomerName,BusinessType,BusinessSum,Balance,Maturity,InterestBalance1,InterestBalance2,FineBalance1,FineBalance2,PutoutDate from BUSINESS_DUEBILL where Maturity >=? and Maturity<=? and OperateOrgID =? and OperateUserID =? and (FinishDate is null or FinishDate = '' or FinishDate=' ') ";
	// ����ƻ����ڣ�15�죩
	private String sql5 = "select count(*) as count from BUSINESS_DUEBILL where Maturity >=? and Maturity<=? and OperateOrgID = ? and OperateUserID = ? and (FinishDate is null or FinishDate = '' or FinishDate=' ')";
	private String sSql55 = "select '['|| CustomerName|| ']'|| getBusinessName(businesstype) || ' �����գ�'||Maturity || ' ���Ž�'||BusinessSum || '  ��'||Balance as detail,"
			+ "RelativeSerialNo2,SerialNo,CustomerName,BusinessType,BusinessSum,Balance,Maturity,InterestBalance1,InterestBalance2,FineBalance1,FineBalance2,PutoutDate from BUSINESS_DUEBILL where Maturity >=? and Maturity<=? and OperateOrgID =? and OperateUserID =? and (FinishDate is null or FinishDate = '' or FinishDate=' ') ";
	public String getSql0() {
		return sql0;
	}
	public void setSql0(String sql0) {
		this.sql0 = sql0;
	}
	public String getSql01() {
		return sql01;
	}
	public void setSql01(String sql01) {
		this.sql01 = sql01;
	}
	public String getSql1() {
		return sql1;
	}
	public void setSql1(String sql1) {
		this.sql1 = sql1;
	}
	public String getSql11() {
		return sql11;
	}
	public void setSql11(String sql11) {
		this.sql11 = sql11;
	}
	public String getSql2() {
		return sql2;
	}
	public void setSql2(String sql2) {
		this.sql2 = sql2;
	}
	public String getsSql22() {
		return sSql22;
	}
	public void setsSql22(String sSql22) {
		this.sSql22 = sSql22;
	}
	public String getSql3() {
		return sql3;
	}
	public void setSql3(String sql3) {
		this.sql3 = sql3;
	}
	public String getsSql33() {
		return sSql33;
	}
	public void setsSql33(String sSql33) {
		this.sSql33 = sSql33;
	}
	public String getSql4() {
		return sql4;
	}
	public void setSql4(String sql4) {
		this.sql4 = sql4;
	}
	public String getsSql44() {
		return sSql44;
	}
	public void setsSql44(String sSql44) {
		this.sSql44 = sSql44;
	}
	public String getSql5() {
		return sql5;
	}
	public void setSql5(String sql5) {
		this.sql5 = sql5;
	}
	public String getsSql55() {
		return sSql55;
	}
	public void setsSql55(String sSql55) {
		this.sSql55 = sSql55;
	}
	
}
