package com.amarsoft.webservice.proj.nh;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;

/**
 * 
 * �����б�Ȩ�޿���
 * @author amarsoft
 *
 */
public class FunctionControlHandler extends JSONHandlerWithSession {

	private String roleid = "" ;
	private String cusRole = "" ;
	private String applyRole = "" ;
	
	private boolean customer=false;
	private boolean apply=false;
	
	@Override
	public Object createResponse(JSONObject arg0, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		JSONObject response = new JSONObject();
		Connection conn = null;
		String userid = SessionManager.getUserId(this.getSessionKey());//�û���
		String sql = " select roleid from user_role where userid=?";
		
		String menuRole="select * from awe_role_menu  where menuid=?";
		try {
			conn = ARE.getDBConnection("als");
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, userid);
			ResultSet rs = ps.executeQuery(); 
			while (rs.next()) {
				roleid += rs.getString("roleid");
				roleid += ",";
			}
			rs.getStatement().close();
			String[] role = roleid.split(",");//��ȡ����ǰ�û������н�ɫ
			
			//��ȡ�ͻ�����ģ��Ľ�ɫ
			PreparedStatement psCus = conn.prepareStatement(menuRole);
			psCus.setString(1, "21");
			ResultSet rsCus = psCus.executeQuery(); 
			while (rsCus.next()) {
				cusRole += rsCus.getString("roleid");
				cusRole += ",";
			}
			rsCus.getStatement().close();
			String[] CusRole = cusRole.split(",");//��ȡ����ǰ�û������н�ɫ
			
			//��ȡҵ������ģ��(��ǰ����ģ��ֻ�������ձ�С΢ҵ������)
			PreparedStatement psApply = conn.prepareStatement(menuRole);
			psApply.setString(1, "250010");
			ResultSet rsApply = psApply.executeQuery(); 
			while (rsApply.next()) {
				applyRole += rsApply.getString("roleid");
				applyRole += ",";
			}
			rsApply.getStatement().close();
			String[] ApplyRole = applyRole.split(",");//��ȡ����ǰ�û������н�ɫ
			
			//��ȡҵ���ѯģ��Ľ�ɫ
			
			
			//�ж�Ȩ��
			List<String> customerlist = Arrays.asList(CusRole);
			List<String> applylist = Arrays.asList(ApplyRole);
			for (int i = 0; i < role.length; i++) {
				if(customerlist.contains(role[i])){
					customer = true;//�ͻ�����  
				}
				if(applylist.contains(role[i])){
					apply = true;//ҵ������
				}
			}
			response.put("Customer", customer);//�ͻ�ģ��
			response.put("Apply", apply);//����ģ��
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			throw new HandlerException(e.getMessage());
		}finally{
			try{
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}

}
