package com.amarsoft.webservice.proj.nh.creditinfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;

/*
 * ������ʷ��ѯ
 */

public class CreditQueryListHandler extends JSONHandlerWithSession {

	private int PageSize = 20;
	private int CurPage = 0;
	private String BStatus = "01";
	private String SearchKey = "";
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
	JSONObject response = new JSONObject();
	Connection conn = null;
	if(request.containsKey("BStatus"))//����/��ҵ
		this.BStatus = request.get("BStatus").toString();
	if(request.containsKey("SearchKey"))//����������֤������/�ͻ����ƣ�
		this.SearchKey = request.get("SearchKey").toString();
	if(request.containsKey("PageSize")){//ÿҳ����
		this.PageSize = Integer.parseInt(request.get("PageSize").toString());
	}
	if(request.containsKey("CurPage")){//��ǰҳ��
		this.CurPage = Integer.parseInt(request.get("CurPage").toString());
	}
	String sUserID = SessionManager.getUserId(this.getSessionKey());
	String sSqlInd = " select cc.customerid as CustomerID,"
			+ " ci.customername as CustomerName,"
			+ " cc.reportno as ReportNo, "
			+ " cc.reportdate as ReportDate,ii.MOBILETELEPHONE as TelePhone "
			+ " from creditreport_catalog cc,customer_info ci,ind_info ii where cc.customerid = ci.customerid"
			+ " and ii.customerid = ci.customerid and cc.reportuserid=?" ;
	
	String sSqlEnt = " select cc.customerid as CustomerID,"
			+ " ci.customername as CustomerName,"
			+ " cc.reportno as ReportNo, "
			+ " cc.reportdate as ReportDate,ei.OFFICETEL as TelePhone "
			+ " from creditreport_catalog cc,customer_info ci,ent_info ei where cc.customerid = ci.customerid"
			+ " and ei.customerid = ci.customerid and cc.reportuserid=?" ;
	
    if (!SearchKey.trim().equals("")) {//��������
			String sWhereClause = " and  (ci.customername like '%"+SearchKey+"%' or ci.certid like '%"+SearchKey+"%')";
			sSqlInd+=sWhereClause;
			sSqlEnt+=sWhereClause;		
	}
    
    String sOrderClause = " order by cc.reportdate desc";
    sSqlEnt+=sOrderClause;
    sSqlInd+=sOrderClause;
	
	try{
		conn = ARE.getDBConnection("als");
		JSONArray array = new JSONArray();
		JSONArray CertTypeArray = getSql("CertType", conn);//֤������
		JSONArray IcrReasonArray = new JSONArray();//��ѯԭ�򣨸��ˣ�
		JSONArray EcrReasonArray = new JSONArray();//��ѯԭ����ҵ��
		JSONObject object1 = new JSONObject();
		object1.put("CodeNo", "01E");
		object1.put("CodeName", "��ǰ���");
		EcrReasonArray.add(object1);
		JSONObject object2 = new JSONObject();
		object2.put("CodeNo", "02E");
		object2.put("CodeName", "���в���");
		EcrReasonArray.add(object2);
		JSONObject object3 = new JSONObject();
		object3.put("CodeNo", "03E");
		object3.put("CodeName", "�������");
		EcrReasonArray.add(object3);
		JSONObject object4 = new JSONObject();
		object4.put("CodeNo", "04E");
		object4.put("CodeName", "��������");
		EcrReasonArray.add(object4);		
	
		JSONObject object01 = new JSONObject();
		object01.put("CodeNo", "01I");
		object01.put("CodeName", "�������");
		IcrReasonArray.add(object01);
		JSONObject object02 = new JSONObject();
		object02.put("CodeNo", "02I");
		object02.put("CodeName", "��������");
		IcrReasonArray.add(object02);
		JSONObject object03 = new JSONObject();
		object03.put("CodeNo", "03I");
		object03.put("CodeName", "���ÿ�����");
		IcrReasonArray.add(object03);
		JSONObject object05 = new JSONObject();
		object05.put("CodeNo", "05I");
		object05.put("CodeName", "����˲�");
		IcrReasonArray.add(object05);
		JSONObject object08 = new JSONObject();
		object08.put("CodeNo", "08I");
		object08.put("CodeName", "�����ʸ����");
		IcrReasonArray.add(object08);
		JSONObject object16 = new JSONObject();
		object16.put("CodeNo", "16I");
		object16.put("CodeName", "��������ȡ����");
		IcrReasonArray.add(object16);
		JSONObject object19 = new JSONObject();
		object19.put("CodeNo", "19I");
		object19.put("CodeName", "��Լ�̻�ʵ�����");
		IcrReasonArray.add(object19);


		if(BStatus.equals("01")){//��˾
			sSqlEnt = Pageable.getPageable().getPagedSqlByPageNum(sSqlEnt, this.CurPage, this.PageSize);
			PreparedStatement ps = conn.prepareStatement(sSqlEnt);
			ps.setString(1, sUserID);
			ARE.getLog().info(sSqlEnt);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				JSONObject object = new JSONObject();
				object.put("ReportDate", rs.getString("ReportDate"));//�������
				object.put("CustomerName", rs.getString("CustomerName"));//�ͻ�����
				object.put("TelePhone", rs.getString("TelePhone"));//��ϵ�绰
				object.put("ReportNo", rs.getString("ReportNo"));//������
				array.add(object);
			}
		}
		else if (BStatus.equals("02")) {//����
			sSqlInd = Pageable.getPageable().getPagedSqlByPageNum(sSqlInd, this.CurPage, this.PageSize);
			PreparedStatement ps = conn.prepareStatement(sSqlInd);
			ps.setString(1, sUserID);
			ARE.getLog().info(sSqlInd);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				JSONObject object = new JSONObject();
				object.put("ReportDate", rs.getString("ReportDate"));//�������
				object.put("CustomerName", rs.getString("CustomerName"));//�ͻ�����
				object.put("TelePhone", rs.getString("TelePhone"));//��ϵ�绰
				object.put("ReportNo", rs.getString("ReportNo"));//������
				array.add(object);
			}
		}
		else {
			throw new Exception("����������");
		}
		response.put("CreditInfoArray", array);//�б�
		response.put("CertTypeArray", CertTypeArray);//֤�����������б�
		response.put("IcrReasonArray", IcrReasonArray);//��ѯԭ�򣨸��˿ͻ���
		response.put("EcrReasonArray", EcrReasonArray);//��ѯԭ�򣨹�˾�ͻ���
	}
	catch (Exception e) {
		// TODO: handle exception
		ARE.getLog().error(e.getMessage());
		e.printStackTrace();
		throw new HandlerException(e.getMessage());
	}
	
	finally{
		try{
			conn.commit();
			if(conn!=null)conn.close();
		}
		catch(Exception e){
			ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
			e.printStackTrace();
		}
	}

	return response;
}

	//��ȡ�����ֵ�����
		private static JSONArray getSql(String codeno,Connection conn) throws Exception{
			String sSql = "select itemno,itemname from code_library where codeno='"+codeno+"' and IsInuse = '1'";
			if(codeno.equals("CertType"))
				sSql = sSql+" and itemno like 'Ind%'";//����֤������
			PreparedStatement psCode = conn.prepareStatement(sSql);
			ARE.getLog().info(sSql);
			ResultSet rsCode = psCode.executeQuery();
			JSONArray result = new JSONArray();		
			while(rsCode.next()){
				JSONObject obj = new JSONObject();
				obj.put("CodeNo", rsCode.getString("itemno"));
				obj.put("CodeName", rsCode.getString("itemname"));
				result.add(obj);
			}
			rsCode.getStatement().close();
			return result;
		}
}
