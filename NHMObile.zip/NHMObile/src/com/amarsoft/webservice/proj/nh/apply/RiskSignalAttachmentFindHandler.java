package com.amarsoft.webservice.proj.nh.apply;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.security.Base64;

/**
 * @author lxu1
 * 
 */
public class RiskSignalAttachmentFindHandler extends JSONHandlerWithSession {

	private String docNo;
	private String objectType;
	private String objectNo;

	@Override
	public Object createResponse(JSONObject arg0, Properties arg1)
			throws HandlerException {
		JSONObject response = new JSONObject();
		Connection conn = null;
		ResultSet rs = null;
		String photoPath = "";
		FileInputStream fis = null ;
		ByteArrayOutputStream baos = null ;
		if (arg0.containsKey("DocNo")) {
			this.docNo = arg0.get("DocNo").toString();
		} else {
			throw new HandlerException("ȱ�ٲ���docNo");
		}
		if (arg0.containsKey("ObjectNo")) {
			this.objectNo = arg0.get("ObjectNo").toString();
		} else {
			throw new HandlerException("ȱ�ٲ���ObjectNo");
		}
		if (arg0.containsKey("ObjectType")) {
			this.objectType = arg0.get("ObjectType").toString();
		} else {
			throw new HandlerException("ȱ�ٲ���ObjectType");
		}
		String sSql = "";
		if (objectType.equals("AfterLoan")) {

		/*	sSql = " SELECT DocumentID as PhotoPath FROM ecm_page where serialno='"
					+ docNo + "' ";*/
			sSql = " SELECT EPF.documentId||'/'||EPF.FileName as PhotoPath FROM   ECM_PAGE_NEW EPN,ECM_PAGE_FILE EPF" +
					" where (EPF.EndTime='' or EPF.EndTime is null or EPN.ModifyTime <= EPF.EndTime) and EPN.TypeNo=EPF.TypeNo and EPN.DocumentID=EPF.DocumentID " +
					"and EPF.SerialNo='"+docNo+"' and EPN.ObjectType='AfterLoan' and EPN.documentId is not null  with ur ";	


		} else if (objectType.equals("RiskSignalApply")) {
			sSql = " select FullPath as PhotoPath from REST_ATTACHMENT where ObjectNo='"
					+ objectNo
					+ "' and ObjectType='"
					+ objectType
					+ "' and DocNo='" + docNo + "' ";
		}
		PreparedStatement ps = null;
		
		try {
			conn = ARE.getDBConnection("als");

			ARE.getLog().info(sSql);
			ps = conn.prepareStatement(sSql);
			rs = ps.executeQuery();
			if (rs.next()) {
				photoPath = rs.getString("PhotoPath") == null ? "" : rs
						.getString("PhotoPath").toString();
			}
			rs.getStatement().close();
			fis = new FileInputStream(new File(photoPath));
			baos = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int count = 0;
			while ((count = fis.read(buffer)) >= 0) {
				baos.write(buffer);
			}
			String str = new String(Base64.encode(baos.toByteArray()));
			response.put("data", str) ;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(ps!=null)ps.close();
				conn.commit();
				if(conn!=null)conn.close();
				fis.close() ;
				baos.close() ;
			} catch (Exception e) {
				e.printStackTrace();
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
			}
		}
		return response;
	}
}
