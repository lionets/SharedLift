package com.amarsoft.webservice.proj.nh.vocation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.Transaction;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.context.ASUser;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;

/**
 * ��Ա�ݼ�����
 * 
 * ���������
 * SerialNo ��ˮ��
 * 
 * ���������
 * LeaveUserID �ݼ���
 * LeaveUserName �ݼ���
 * AssigneeID ������
 * AssigneeName ������
 * BeginDate ��ʼ����
 * EndDate �������� 
 * Status �ݼ�״̬
 * StatusName �ݼ�״̬
 * RandomCode ��֤��
 * CancelDate ��������
 * 
 * @author lyue 2015-04-17
 *
 */
public class UserLeaveInfoHandler extends JSONHandlerWithSession {
	
	private String sSerialNo = "";
	private String sUserId= "";
	Transaction Sqlca;

	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		
        Connection conn=null;
        
        sUserId = SessionManager.getUserId(this.getSessionKey());// �û���
		
		JSONObject response = new JSONObject();
		if (request.containsKey("SerialNo")) {
			this.sSerialNo = request.get("SerialNo").toString();
		}else{
			throw new HandlerException("ȱ����ˮ�Ų���");
		}
		
		String sql = "select SERIALNO,LEAVEUSERID,getUserName(LeaveUserID) as LeaveUserName,ASSIGNEEID,getUserName(AssigneeID) as AssigneeName,REMAK,BEGINDATE,ENDDATE,STATUS,getItemName('EffStatus',Status) as StatusName,CANCELDATE,RANDOMCODE from USER_LEAVE_TRANS where SERIALNO = ? ";
		PreparedStatement ps = null;
		
		try {
			
			conn= ARE.getDBConnection("als");
			Sqlca = new Transaction(conn);
			
			if(sSerialNo.equals("")){//����ʱ
				//��ȡ�û�
				ASUser curUser = ASUser.getUser(sUserId, Sqlca);
				String orgId = curUser.getOrgID();
				
				//��ȡ�������б�
				JSONArray arrayUser = getSql(orgId, sUserId, conn);
				
				response.put("UserArray", arrayUser);
			}else{//�ݼ�����
				ps = conn.prepareStatement(sql);
				ps.setString(1, sSerialNo);
				ARE.getLog().info(sql);
				ResultSet rs = ps.executeQuery();
				if(rs.next()){
					response.put("SerialNo", rs.getString("SERIALNO"));//
					response.put("LeaveUserID", rs.getString("LEAVEUSERID"));//
					response.put("LeaveUserName", rs.getString("LeaveUserName"));//
					response.put("AssigneeID", rs.getString("ASSIGNEEID"));//
					response.put("AssigneeName", rs.getString("AssigneeName"));//
					response.put("BeginDate", rs.getString("BEGINDATE"));//
					response.put("EndDate", rs.getString("ENDDATE"));//
					response.put("Status", rs.getString("STATUS"));//
					response.put("StatusName", rs.getString("StatusName"));//
					response.put("CancelDate", rs.getString("CANCELDATE"));//
					response.put("RandomCode", rs.getString("RANDOMCODE"));//
					//end
				}
				rs.getStatement().close();
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}finally{
			try{
				if(ps!=null){
					ps.close();
				}
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}
	
	//��ȡ���������б�
	private static JSONArray getSql(String belongorg,String userId,Connection conn) throws Exception{
		String sql1 = "select UserID,UserName,BelongOrg,getOrgName(BelongOrg) as BelongOrgName from USER_INFO where BelongOrg=? and Status = '1' and UserID <> ?";
		PreparedStatement psCode = conn.prepareStatement(sql1);
		psCode.setString(1, belongorg);
		psCode.setString(2, userId);
		ARE.getLog().info(sql1);
		ResultSet rsCode = psCode.executeQuery();
		JSONArray result = new JSONArray();		
		while(rsCode.next()){
			JSONObject obj = new JSONObject();
			obj.put("UserID", rsCode.getString("UserID"));
			obj.put("UserName", rsCode.getString("UserName"));
			obj.put("BelongOrg", rsCode.getString("BelongOrg"));
			obj.put("BelongOrgName", rsCode.getString("BelongOrgName"));
			result.add(obj);
		}
		rsCode.getStatement().close();
		psCode.close();
		return result;
	}

}
