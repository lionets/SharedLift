/**
 * 
 */
package com.amarsoft.webservice.proj.nh.approve;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;

/**
 * @author Administrator
 * �޸ı��� - ����ҵ����Ϣ
 * SerialNo(�����б�����ˮ��)
 * BStatus 01 ������һ�֣�02�����ڶ���
 */
public class OpinionSignSaveHandler extends JSONHandlerWithSession{

	private String SerialNo = "";
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		JSONObject response = new JSONObject();
		if (!request.containsKey("SerialNo"))
			throw new HandlerException("��Ҫ��ˮ�Ų���");
		else {
			SerialNo = request.get("SerialNo").toString();
		}
		String updateInfo1 = " update flow_creditopinion set BusinessSum=? "
				+ "where serialno=?";
		String updateInfo2 = " update flow_creditopinion set BusinessSum=?,"
				+ "TermMonth=?,"
				+ "RateFloat=?,"
				+ "ExecuteYearRate=?,"
				+ "BusinessRate=?,"
				+ "CorpusPayMethod=?,"
				+ "VouchType=?,"
				+ "CycleFlag=?"
				+ "where serialno=?";
		try{
			conn = ARE.getDBConnection("als");
			conn.setAutoCommit(false);
			if(request.get("BStatus").toString().equals("01")){
				PreparedStatement psPreparedStatement = conn.prepareStatement(updateInfo1);
				psPreparedStatement.setDouble(1, Double.parseDouble(request.get("BusinessSum").toString()));
				psPreparedStatement.setString(2, SerialNo);
				psPreparedStatement.executeUpdate();
				psPreparedStatement.close();
			}
			else if(request.get("BStatus").toString().equals("02")){
				PreparedStatement psPreparedStatement = conn.prepareStatement(updateInfo2);
				psPreparedStatement.setDouble(1, Double.parseDouble(request.get("BusinessSum").toString()));
				psPreparedStatement.setInt(2, Integer.parseInt(request.get("TermMonth").toString()));
				psPreparedStatement.setDouble(3, Double.parseDouble(request.get("RateFloat").toString()));
				psPreparedStatement.setDouble(4, Double.parseDouble(request.get("ExecuteYearRate").toString()));
				psPreparedStatement.setDouble(5, Double.parseDouble(request.get("BusinessRate").toString()));
				psPreparedStatement.setString(6, request.get("CorpusPayMethodName").toString());
				psPreparedStatement.setString(7, request.get("VouchTypeName").toString());
				psPreparedStatement.setString(8, request.get("CycleFlagName").toString());
				psPreparedStatement.setString(9, SerialNo);
				psPreparedStatement.executeUpdate();
				psPreparedStatement.close();
			}
			else {
				throw new Exception("����������");
			}
			conn.commit();
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				ARE.getLog().error("���ݿ�ر�ʧ��:" + e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}

}
