package com.amarsoft.webservice.proj.nh.approve;

import java.util.Properties;

import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;

/**
 * �������水ť��ʾȨ�޿���
 * @author amarsoft
 *
 */
public class ApproveBtnControlHandler extends JSONHandlerWithSession {

	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Boolean flag = false;
		String flowno="";
		String phaseno="";
		
		JSONObject response = new JSONObject();
		
		if(request.containsKey("FlowNo")){
			   flowno=request.get("FlowNo").toString();
		}else{
			throw new HandlerException("��Ҫ���̱�Ų���");
		}
			
		if(request.containsKey("PhaseNo")){
			 phaseno=request.get("PhaseNo").toString();
		}else{
			throw new HandlerException("��Ҫ�׶α�Ų���");
		}
		
	     flag = TakeBackControl.getBackControl(flowno, phaseno);
	     if(flag){
	    	 response.put("TakeBack", "true");
	     }else{
	    	 response.put("TakeBack", "false");
	     }
		
		return response;
	}

}
