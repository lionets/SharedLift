/**
 * 
 */
package com.amarsoft.webservice.proj.nh;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.DBKeyHelp;

/**
 * @author Administrator ��������ݿ���
 */
public class OpinionSave {

	private String SerialNo = "";
	private String ObjectType = "";
	private String ObjectNo = "";
	private String CustomerID = "";
	private String CustomerName = "";
	private String BusinessCurrency = "";
	private double BusinessSum = 0;
	private int TermMonth = 0;
	private String BaseRateType = "";
	private String RateFloatType = "";
	private double RateFloat = 0;
	private double BusinessRate = 0;
	private double BaseRate = 0;
	private double PdgRatio = 0;
	private double PdgSum = 0;
	private double BailRatio = 0;
	private double BailSum = 0;
	private String InputOrgID = "";
	private String InputUserID = "";

	public void save(Connection conn) throws Exception {
		String getFlowCredit = " INSERT INTO FLOW_OPINION(SERIALNO, OPINIONNO, objecttype, OBJECTNO, CUSTOMERID, "
				+ " CUSTOMERNAME, BUSINESSCURRENCY,"
				+ " BUSINESSSUM, TERMMONTH, BASERATETYPE, RATEFLOATTYPE, RATEFLOAT,  BUSINESSRATE, "
				+ " BASERATE, BailSum,BailRatio,PdgSum,PdgRatio,INPUTORG, INPUTUSER, INPUTTIME)  "
				+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(getFlowCredit);
		// ��¼���ݿ�
		String Opinionno = DBKeyHelp.getSerialNo("FLOW_OPINION", "OPINIONNO");
		ps.setString(1, SerialNo);
		ps.setString(2, Opinionno);
		ps.setString(3, ObjectType);
		ps.setString(4, ObjectNo);
		ps.setString(5, CustomerID);
		ps.setString(6, CustomerName);
		ps.setString(7, BusinessCurrency);
		ps.setDouble(8, BusinessSum);
		ps.setInt(9, TermMonth);
		ps.setString(10, BaseRateType);
		ps.setString(11, RateFloatType);
		ps.setDouble(12, RateFloat);
		ps.setDouble(13, BusinessRate);
		ps.setDouble(14, BaseRate);
		ps.setDouble(15, BailSum);
		ps.setDouble(16, BailRatio);
		ps.setDouble(17, PdgSum);
		ps.setDouble(18, PdgRatio);
		ps.setString(19, InputOrgID);
		ps.setString(20, InputUserID);
		ps.setString(21, StringFunction.getToday());
		ps.executeUpdate();
		ARE.getLog().info(getFlowCredit);
		ps.close();
	}

	public OpinionSave(String serialNo, String objectType, String objectNo,
			String customerID, String customerName, String businessCurrency,
			double businessSum, int termMonth, String baseRateType,
			String rateFloatType, double rateFloat, double businessRate,
			double baseRate, double pdgRatio, double pdgSum, double bailRatio,
			double bailSum, String inputOrgID, String inputUserID) {
		super();
		SerialNo = serialNo;
		ObjectType = objectType;
		ObjectNo = objectNo;
		CustomerID = customerID;
		CustomerName = customerName;
		BusinessCurrency = businessCurrency;
		BusinessSum = businessSum;
		TermMonth = termMonth;
		BaseRateType = baseRateType;
		RateFloatType = rateFloatType;
		RateFloat = rateFloat;
		BusinessRate = businessRate;
		BaseRate = baseRate;
		PdgRatio = pdgRatio;
		PdgSum = pdgSum;
		BailRatio = bailRatio;
		BailSum = bailSum;
		InputOrgID = inputOrgID;
		InputUserID = inputUserID;
	}

	public String getSerialNo() {
		return SerialNo;
	}

	public void setSerialNo(String serialNo) {
		SerialNo = serialNo;
	}

	public String getObjectType() {
		return ObjectType;
	}

	public void setObjectType(String objectType) {
		ObjectType = objectType;
	}

	public String getObjectNo() {
		return ObjectNo;
	}

	public void setObjectNo(String objectNo) {
		ObjectNo = objectNo;
	}

	public String getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}

	public String getCustomerName() {
		return CustomerName;
	}

	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}

	public String getBusinessCurrency() {
		return BusinessCurrency;
	}

	public void setBusinessCurrency(String businessCurrency) {
		BusinessCurrency = businessCurrency;
	}

	public double getBusinessSum() {
		return BusinessSum;
	}

	public void setBusinessSum(double businessSum) {
		BusinessSum = businessSum;
	}

	public int getTermMonth() {
		return TermMonth;
	}

	public void setTermMonth(int termMonth) {
		TermMonth = termMonth;
	}

	public String getBaseRateType() {
		return BaseRateType;
	}

	public void setBaseRateType(String baseRateType) {
		BaseRateType = baseRateType;
	}

	public String getRateFloatType() {
		return RateFloatType;
	}

	public void setRateFloatType(String rateFloatType) {
		RateFloatType = rateFloatType;
	}

	public double getRateFloat() {
		return RateFloat;
	}

	public void setRateFloat(double rateFloat) {
		RateFloat = rateFloat;
	}

	public double getBusinessRate() {
		return BusinessRate;
	}

	public void setBusinessRate(double businessRate) {
		BusinessRate = businessRate;
	}

	public double getBaseRate() {
		return BaseRate;
	}

	public void setBaseRate(double baseRate) {
		BaseRate = baseRate;
	}

	public double getPdgRatio() {
		return PdgRatio;
	}

	public void setPdgRatio(double pdgRatio) {
		PdgRatio = pdgRatio;
	}

	public double getPdgSum() {
		return PdgSum;
	}

	public void setPdgSum(double pdgSum) {
		PdgSum = pdgSum;
	}

	public double getBailRatio() {
		return BailRatio;
	}

	public void setBailRatio(double bailRatio) {
		BailRatio = bailRatio;
	}

	public double getBailSum() {
		return BailSum;
	}

	public void setBailSum(double bailSum) {
		BailSum = bailSum;
	}

	public String getInputOrgID() {
		return InputOrgID;
	}

	public void setInputOrgID(String inputOrgID) {
		InputOrgID = inputOrgID;
	}

	public String getInputUserID() {
		return InputUserID;
	}

	public void setInputUserID(String inputUserID) {
		InputUserID = inputUserID;
	}

	

}
