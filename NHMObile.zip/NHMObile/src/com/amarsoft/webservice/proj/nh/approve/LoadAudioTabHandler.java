package com.amarsoft.webservice.proj.nh.approve;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.SpecialTools;
import com.amarsoft.awe.util.Transaction;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.biz.formatdoc.model.FormatDocConfig;
import com.amarsoft.biz.formatdoc.model.FormatToolManager;
import com.amarsoft.biz.formatdoc.model.IFormatTool;
import com.amarsoft.context.ASUser;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.webservice.app.HtmlToString;
/**�ſ���˱�
 * ���������
 * objectno - ������ˮ��

 * ���������
 *    html

 * @author 
 *
 */
public class LoadAudioTabHandler extends JSONHandlerWithSession{

	private String objectno = "";
	private String SavePath = "";
	private String shtml="";
	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		StringBuffer result = new StringBuffer();
		Connection conn = null;
		Transaction sqlca =new Transaction("als");
		if(!request.containsKey("objectno"))throw new HandlerException("ȱ��objectid");
		
		if(request.containsKey("objectno"))
			this.objectno = request.get("objectno").toString();
		
		String sUserId = SessionManager.getUserId(this.getSessionKey());
		
		
		try {
			
			//******************���� �ſ���˱�**************
			String docID = "FDSH";
			String sql = "select IndFlag from Business_PutOut where SerialNo='"+objectno+"'";
			String indFlag = sqlca.getString(sql);
			if("1".equals(indFlag)||"2".equals(indFlag)){
				docID = "FDSHGJJ";
			}
			String sDocID = FormatToolManager.getTrueDocId("PutOutApply",objectno,docID);//�ҵ����ʰ汾��DOCID
			IFormatTool formatTool = FormatToolManager.getFormatTool(sDocID,"");
			ASUser CurUser  = ASUser.getUser(SpecialTools.real2Amarsoft(sUserId),sqlca);
//			formatTool.genDocument(new FormatDocConfig(),"/db2data/als7uat/als/WorkDoc",CurUser,"PutOutApply",objectno,sDocID );
			//FormatDocData
			FormatDocConfig config = FormatDocConfig.getInstance();
			formatTool.genDocument(config,config.getWorkDocSavePath(),CurUser,"PutOutApply",objectno,sDocID );
			
			//��ſ���˱�·��
			String sSqlPaths="SELECT savepath FROM AWE_ERPT_RECORD O WHERE O.ObjectType='PutOutApply' AND O.ObjectNo=? AND O.DocID='FDSH'";
			conn= ARE.getDBConnection("als");
			PreparedStatement ps=null;
			ResultSet rs = null;
			
			ps = conn.prepareStatement(sSqlPaths);
			ps.setString(1, objectno);
			rs = ps.executeQuery();
			
			if (rs.next()) {
				SavePath = rs.getString("SavePath");//�洢·��
			}
			rs.getStatement().close();

			if (SavePath==null||SavePath.equals("")) {
				shtml = "";
			}
			else {
				shtml = HtmlToString.getHtmlTemplate(SavePath);
			}
			if(shtml.equals("")){
				result.append("<!DOCTYPE html>");
				result.append("<html><head><meta charset=\"utf-8\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><Title>�޷ſ���˱�</title>");
				result.append("</head><body>�޷ſ���˱�</body></html>");
			}else{
				result.append(shtml);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			throw new HandlerException(e.getMessage());
		}finally{
			try{
				sqlca.disConnect();
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return result;
	
	}
}
