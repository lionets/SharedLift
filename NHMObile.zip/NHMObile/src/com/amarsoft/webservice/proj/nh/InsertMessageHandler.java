/**
 * 
 */
package com.amarsoft.webservice.proj.nh;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.innerpush.PushFactory;

/**
 * @author Administrator
 *
 */
public class InsertMessageHandler extends JSONHandlerWithSession{

	private int count0 = 0;
	private int count1 = 0;
	private int count2 = 0;
	private int count3 = 0;
	private int count4 = 0;
	private int count5 = 0;
	private int count6 = 0;
	private int count7 = 0;
	private int count8 = 0;
	private int count9 = 0;
	private int count10 = 0;
	private int count11 = 0;
	private int count12 = 0;
	private int count13 = 0;
	private int count14 = 0;
	private int count15 = 0;
	private int count16 = 0;
	private int count17 = 0;
	private int count18 = 0;
	private int count19 = 0;
	private int count20 = 0;
	private int count21 = 0;
	private int count22 = 0;
	private int count23 = 0;
	private int count24 = 0;
	private int count25 = 0;
	private int count26 = 0;
	private int count27 = 0;
	private int count28 = 0;
	private int count29 = 0;
	private int count30 = 0;
	private int count31 = 0;
	private int count32 = 0;

	 public JSONObject createResponse(JSONObject request, Properties paramProperties)
			    throws HandlerException{
		 		JSONObject response = new JSONObject();
		 		WorkTipMessageContent workTipMessageContent = new WorkTipMessageContent();
		 		if (!request.containsKey("k")) {
					return null;
				}
			    String operateUserId = request.get("k").toString();
			    String date = StringFunction.getToday();
			    Connection conn = null;
			    ResultSet rs = null;
			    PreparedStatement ps = null;
			    String sql = " select belongorg from user_info where userid=?";
			    String orgid = "";
			    try
			    {
			    	conn = ARE.getDBConnection("als");
			    	ps = conn.prepareStatement(sql);
			    	ps.setString(1, operateUserId);
			    	rs = ps.executeQuery();
			    	if (rs.next()) {
			    		orgid = rs.getString("belongorg");
						ARE.getLog().info(orgid);
					}
			    	rs.getStatement().close();
			    	// ���������Ŵ�ҵ������1
			    	ps = conn.prepareStatement(workTipMessageContent.getSql0());
			    	ps.setString(1, operateUserId);
			    	rs = ps.executeQuery();
			    	if(rs.next()){
			    		count0 = rs.getInt("count");
			    	}
			    	rs.getStatement().close();

					// �������Ĺ����ƻ�2
					ps = conn.prepareStatement(workTipMessageContent.getSql1());
					ps.setString(1, date);
					ps.setString(2, date);
					ps.setString(3, operateUserId);

					rs = ps.executeQuery();
					if (rs.next()) {
						
						count1 = rs.getInt("count");

					}
					rs.getStatement().close();
					
//					// �������� ���õȼ�����3
//					ps = conn.prepareStatement(workTipMessageContent.getSql2());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count2 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ���ǼǺ�ͬ������4
//					ps = conn.prepareStatement(workTipMessageContent.getSql3());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count3 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//					
//					// ������������5
//					ps = conn.prepareStatement(workTipMessageContent.getSql4());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						count4 = rs.getInt("count");
//							
//					}
//					rs.getStatement().close();
//
//					// �������ķſ�6
//					ps = conn.prepareStatement(workTipMessageContent.getSql5());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {						
//						count5 = rs.getInt("count");						

//							
//					}
//					rs.getStatement().close();
//
//					// ���ǼǺ�ͬ������7
//					ps = conn.prepareStatement(workTipMessageContent.getSql6());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						count6 = rs.getInt("count");			

//							
//					}
//					rs.getStatement().close();
//					
//					// �������Ŵ����ݱ��(��ȷ��)8
//					ps = conn.prepareStatement(workTipMessageContent.getSql7());
////					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count7 = rs.getInt("count");
//						

//							
//					}
//					rs.getStatement().close();
//					
//					// ��������������������9
//					ps = conn.prepareStatement(workTipMessageContent.getSql8());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count8 = rs.getInt("count");
//						
//					}
//					rs.getStatement().close();
//					
//					// �������ı��շ�ά������10
//					ps = conn.prepareStatement(workTipMessageContent.getSql9());
//					ps.setString(1, operateUserId);
//
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count9 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// �������Ŀͻ�Ȩ������ 11
//					ps = conn.prepareStatement(workTipMessageContent.getSql100());
//					ps.setString(1, operateUserId);
//
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count10 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ��������Ԥ���ź�12
//					ps = conn.prepareStatement(workTipMessageContent.getSql110());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {	
//						count11 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ����⹤������13
//					ps = conn.prepareStatement(workTipMessageContent.getSql120());
//					ps.setString(1, operateUserId);
//					ps.setString(2, orgid);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count12 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ���Ǽ������������������14
//					ps = conn.prepareStatement(workTipMessageContent.getSql130());
//					ps.setString(1, orgid+"%");
//					ps.setString(2, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						count13 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ��������֧��15
//					ps = conn.prepareStatement(workTipMessageContent.getSql140());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count14 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// �����ʲ���ȫ�����ʼ�16
//					ps = conn.prepareStatement(workTipMessageContent.getSql150());
//					ps.setString(1, date);
//					ps.setString(2, date);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count15 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ��������¥��׼������17
//					ps = conn.prepareStatement(workTipMessageContent.getSql160());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count16 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ��������С΢ҵ����������18
//					ps = conn.prepareStatement(workTipMessageContent.getSql170());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count17 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// �����������/���������19
//					ps = conn.prepareStatement(workTipMessageContent.getSql180());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count18 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ����������ʽ��������20
//					ps = conn.prepareStatement(workTipMessageContent.getSql190());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count19 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ����������ʱ��������21
//					ps = conn.prepareStatement(workTipMessageContent.getSql200());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count20 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ��������ѹ���˳���ά������22
//					ps = conn.prepareStatement(workTipMessageContent.getSql210());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count21 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ����Ч�ĵǼǺ�ͬ23
//					ps = conn.prepareStatement(workTipMessageContent.getSql220());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count22 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// ��������Ԥ���ź�24
//					ps = conn.prepareStatement(workTipMessageContent.getSql230());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count23 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// �������ĵ����������25
//					ps = conn.prepareStatement(workTipMessageContent.getSql240());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count24 = rs.getInt("count");
//						if (!count!=0){	

//					}
//					rs.getStatement().close();
//
//					// �������ĳ��������26
//					ps = conn.prepareStatement(workTipMessageContent.getSql250());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count25 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// �������Ľ��Ĺ�����������27
//					ps = conn.prepareStatement(workTipMessageContent.getSql260());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count26 = rs.getInt("count");

//					}
//					rs.getStatement().close();
//
//					// �������ķ���Ԥ�����28
//					ps = conn.prepareStatement(workTipMessageContent.getSql270());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count27 = rs.getInt("count");
//					}
//					rs.getStatement().close();
//
//					// �������Ĵ�����ƻ���������29
//					ps = conn.prepareStatement(workTipMessageContent.getSql280());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count28 = rs.getInt("count");
//					}
//					rs.getStatement().close();
//
//					// ���������ʲ����շ����϶���������30
//					ps = conn.prepareStatement(workTipMessageContent.getSql290());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count29 = rs.getInt("count");
//					}
//					rs.getStatement().close();
//
//					// �������ķſ�Ҫ����������31
//					ps = conn.prepareStatement(workTipMessageContent.getSql300());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count30 = rs.getInt("count");
//					}
//					rs.getStatement().close();
//
//					// �������Ĵ�ǰ����������������32
//					ps = conn.prepareStatement(workTipMessageContent.getSql310());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count31 = rs.getInt("count");
//					}
//					rs.getStatement().close();
//
//					// �������ĸ�������������������33
//					ps = conn.prepareStatement(workTipMessageContent.getSql320());
//					ps.setString(1, operateUserId);
//					rs = ps.executeQuery();
//					if (rs.next()) {
//						
//						count32 = rs.getInt("count");
//					}
//					rs.getStatement().close(); 
					
					int count=count0+count1+count2+count3+count4+count5+count6+count7+count8
							+count9+count10+count11+count12+count13+count14+count15+count16+count17+count18
							+count19+count20+count21+count22+count23+count24+count25+count26+count27+count28
							+count29+count30+count31+count32;
					ARE.getLog().info("count="+count);
					if(count0!=0||count1!=0||count2!=0||count3!=0||count4!=0||count5!=0
							||count6!=0||count7!=0||count8!=0||count9!=0||count10!=0
							||count11!=0||count12!=0||count13!=0||count14!=0||count15!=0||count16!=0||count17!=0||count18!=0||count19!=0||count20!=0
							||count21!=0||count22!=0||count23!=0||count24!=0||count25!=0||count26!=0||count27!=0||count28!=0||count29!=0||count30!=0
							||count31!=0||count32!=0){
						if(count0!=0){
							PushFactory.getPushReceiveManager().insertMessage("�Ϻ�ũ�����Ŵ�ϵͳ-����̨��ʾ", "���������� "+count+"��,"+"�ֻ��˿�����ҵ��"+count0+"��", 1, operateUserId);
						}
						else {
							PushFactory.getPushReceiveManager().insertMessage("�Ϻ�ũ�����Ŵ�ϵͳ-����̨��ʾ", "���������� "+count+"��", 0, operateUserId);
						}
						
					}
						
			  } catch (Exception e) {
					// TODO: handle exception
					ARE.getLog().error(e.getMessage());
					e.printStackTrace();
					throw new HandlerException(e.getMessage());
				}
				
				finally{
					try{
						if(conn!=null)conn.close();
					}
					catch(Exception e){
						ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
						e.printStackTrace();
					}
				}
				return response;
	

	 }
}
