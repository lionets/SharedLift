package com.amarsoft.webservice.proj.nh.bizquery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.sql.Pageable;
/**
 * �����������б�
 * ���������
	CustomerNo - �ͻ��б�
	CurPage - ����ҳ��
	PageSize - ÿҳ��ʾ������
 * ���������
 * DueArray
		SerialNo - ��ݺ�
		BusinessTypeName - ҵ��Ʒ��
		OccurDate - ������
		Maturity - ������
		BusinessRate - ����
		LoanBalance -- �������
 * @author 
 *
 */
public class CustomerBizInfoHandler extends JSONHandlerWithSession{
	private String CustomerNo = "";
	private int PageSize = 20;
	private int CurPage = 0;

	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		JSONObject response = new JSONObject();
		Connection conn = null;
		if(request.containsKey("CustomerNo"))
			this.CustomerNo = request.get("CustomerNo").toString();
		if(request.containsKey("PageSize"))
			this.PageSize = Integer.parseInt(request.get("PageSize").toString());
		if(request.containsKey("CurPage"))
			this.CurPage = Integer.parseInt(request.get("CurPage").toString());
		
		String sSqlDuel = 	" select bd.SerialNo as SerialNo," +//��ݺ�
							" ba.BusinessRate as BusinessRate," +//����
							" bd.BusinessSum as BusinessSum," +//���Ž��
							" bd.balance as LoanBalance,"+//�������
							" bd.PUTOUTDATE as OccurDate," +//������ ��20140304��modify
							" getBusinessName(ba.BusinessType) as BusinessTypeName," +//ҵ��Ʒ��
							" bd.Maturity as Maturity" +//������
							" from  BUSINESS_DUEBILL bd, Business_Approve ba " +
							" where bd.RELATIVESERIALNO2 = ba.serialNo and bd.customerid =?" +
							" and (bd.FinishDate is null  or bd.FinishDate = ' ' or bd.FinishDate = '') ";
		try {
			conn= ARE.getDBConnection("als");
			sSqlDuel = Pageable.getPageable().getPagedSqlByPageNum(sSqlDuel, this.CurPage, this.PageSize);
			PreparedStatement ps = conn.prepareStatement(sSqlDuel);
			JSONArray resultArray = new JSONArray();
			ps.setString(1, CustomerNo);
			ARE.getLog().info(sSqlDuel);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				JSONObject obj = new JSONObject();
				obj.put("SerialNo", rs.getString("SerialNo"));
				obj.put("BusinessTypeName", rs.getString("BusinessTypeName"));
				obj.put("OccurDate", rs.getString("OccurDate"));
				obj.put("Maturity", rs.getString("Maturity"));
				obj.put("BusinessRate", (new DecimalFormat("#0.00").format(rs.getDouble("BusinessRate"))));
				obj.put("LoanBalance", (new DecimalFormat("#0.00").format(rs.getDouble("LoanBalance")/10000))+"��Ԫ");
				resultArray.add(obj);
			}
			rs.getStatement().close();
			
			response.put("DueArray", resultArray);
			
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}

}
