package com.amarsoft.webservice.proj.nh.vocation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;



import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.DBKeyHelp;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandler;
import com.amarsoft.mobile.webservice.session.SessionManager;
/**
 * ��¼����
 * ���������
 * 		userid:�û���
 * ���������
 * 		sessionKey:��¼��ʾ
 * 		roleid:��ɫ���
 * 		orgid:�������
 *      orgname����������
 * 		username:�û�����
 * @author flian
 *
 */

public class VocationLogonHandler extends JSONHandler {

	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		DBKeyHelp.setDataSource("als");
		JSONObject result = logon(request);
		String sSessionKey = createSessionKey(request);
		
		
		System.out.println(sSessionKey+"-------------------------------------------");
	
			//���ؽ��
			try{
				result.put("sessionKey", sSessionKey);
				return result;
			}
			catch(Exception e){
				e.printStackTrace();
				ARE.getLog().error(e.toString());
				throw new HandlerException("logon.createKey.fail");
			
		}

	}
	
	private JSONObject logon(JSONObject request)throws HandlerException {
		if(request.get("userid")==null){
			throw new HandlerException("�������û���");
		}
		//String sql = "select i.belongorg,r.roleid,i.username from user_info i,user_role r where i.userid = r.userid and i.userid=? and i.password=? and i.status='1'";
		String sql = "select i.belongorg,i.username,i.userid,getOrgName(i.belongorg) as OrgName from user_info i where i.userid=? and i.status='1'";
		Connection conn = null;
		try{
			JSONObject result = new JSONObject();
			conn = ARE.getDBConnection("als");
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, request.get("userid").toString());
			ARE.getLog().info(sql+",userid="+request.get("userid").toString());
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				result.put("username", rs.getString("username"));
				result.put("orgid", rs.getString("belongorg"));
				result.put("orgname", rs.getString("OrgName"));//add 20140328
				result.put("userid", rs.getObject("userid"));
				rs.getStatement().close();
				String sql2 = "select r.roleid from user_role r where r.userid=?";
				PreparedStatement ps2 = conn.prepareStatement(sql2);
				ps2.setString(1, request.get("userid").toString());
				ARE.getLog().info(sql2+",userid="+request.get("userid").toString());
				rs = ps2.executeQuery();
				while(rs.next()){
					if(!result.containsKey("roleid")){
						result.put("roleid", rs.getString("roleid"));
					}
					else{
						result.put("roleid", result.get("roleid").toString() + "," +  rs.getString("roleid"));
					}
				}
				rs.getStatement().close();
			}
			else{
				rs.getStatement().close();
				throw new HandlerException("�û������������");
			}
			
			
			return result;
		}
		catch(HandlerException e){
			throw e;
		}
		catch(Exception e){
			e.printStackTrace();
			throw new HandlerException("�û��˺���֤������"+ e.toString());
		}
		finally{
			try{
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
		}
	}
	

	private String createSessionKey(JSONObject businessRequest){
		try{
			return SessionManager.createSessionKey(businessRequest.get("userid").toString(),"");
		}
		catch(Exception e){
			return null;
		}
	}
}