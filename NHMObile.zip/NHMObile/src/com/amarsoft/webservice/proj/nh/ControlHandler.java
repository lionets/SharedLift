package com.amarsoft.webservice.proj.nh;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.Properties;
import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;

import java.util.List;

/**
 * @author ldfang
 * ����ģ��Ȩ�޿���(����ģ�鶼���ã�ȡֵtrue|false)
 * 
 *     Customer �ͻ�ģ��
	   Apply ����ģ��
	   Approve ����ģ��
	   Accredit ��Ȩģ��
	   AfterLoan ����ģ��
	   BizQuery ҵ���ѯ
	   CreditQuery ���Ų�ѯ
	   Memo   ����¼
 */
public class ControlHandler extends JSONHandlerWithSession{

	private String roleid = "" ;
	private static String[] ApproveRole = {"410","411","441","442","443","444","445",
										"446","448","449","450","455",
										"040","041","042","043","044",
										"045","046","047","048","049",
										"053","054","055","056","063",
										"011","012","013","014","015",
										"017","018","019","020"};
	
	
	private static String[] CustomerRole = {"480","481","482","080","081","082"};
	private static String[] ManageRole = {"410","022","027","028","029","050","051","052"};
	private boolean customer=false;
	private boolean apply=false;
	private boolean approve=false;
	private boolean accredit=false;
	private boolean afterloan=false;
	private boolean bizquery=false;
	private boolean creditquery=false;
	private boolean memo=false;
	
	/* (non-Javadoc)
	 * @see com.amarsoft.mobile.webservice.business.JSONHandler#createResponse(com.amarsoft.awe.util.json.JSONObject, java.util.Properties)
	 */
	@Override
	public JSONObject createResponse(JSONObject arg0, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		JSONObject response = new JSONObject();
		Connection conn = null;
		String userid = SessionManager.getUserId(this.getSessionKey());//�û���
		String sql = " select roleid from user_role where userid=?";
		try {
			conn = ARE.getDBConnection("als");
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, userid);
			ResultSet rs = ps.executeQuery(); 
			List<String> customerlist = Arrays.asList(CustomerRole);
			List<String> approvelist = Arrays.asList(ApproveRole);
			List<String> managelist = Arrays.asList(ManageRole);
			while (rs.next()) {
				roleid += rs.getString("roleid");
				roleid += ",";
			}
			rs.getStatement().close();
			String[] role = roleid.split(",");
			for (int i = 0; i < role.length; i++) {
				if(customerlist.contains(role[i])){//�ͻ�����
					customer = true;//�ͻ�����
					apply = true; //����
					afterloan = true;//����
					memo = true;//����¼
					creditquery = true;//����
					
				}
				if(approvelist.contains(role[i])){//�Ŵ�����Ա
					accredit = true;//��Ȩ
					approve = true;//����
				}
				if (managelist.contains(role[i])) {//�Ŵ�����Ա
					bizquery = true;//ҵ���ѯ
				}			
			}
			
			response.put("Customer", customer);//�ͻ�ģ��
			response.put("Apply", apply);//����ģ��
			response.put("Approve", approve);//����ģ��
			response.put("Accredit", accredit);//��Ȩģ��
			response.put("AfterLoan", afterloan);//����ģ��
			response.put("BizQuery", bizquery);//ҵ���ѯ
			response.put("CreditQuery", creditquery);//���Ų�ѯ
			response.put("Memo", memo);//����¼
		}catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			throw new HandlerException(e.getMessage());
		}
		
		finally{
			try{
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}

}
