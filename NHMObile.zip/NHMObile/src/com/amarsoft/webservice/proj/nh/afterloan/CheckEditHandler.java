package com.amarsoft.webservice.proj.nh.afterloan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.DBKeyHelp;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;

/**
 * ���������� ���������
 * SearchKey(�ͻ�����)
 * CurPage
 * PageSize
 * BStatus
 * ���������
 * customerNames(����) { CustomerId��CustomerName}
 * CheckNums
   CheckDate
   CheckTime
 * @author
 * 
 */

public class CheckEditHandler extends JSONHandlerWithSession {

	private int pageSize;

	// add 20140214
	private int curPage = 0;

	private String SearchKey = "";
	private String CustomerType = "";
	
	private String sOrgID = "";

	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		JSONObject response = new JSONObject();
		String serialNO;
		JSONArray customerNames = new JSONArray();
		String date;
		String time;

		try {
			conn = ARE.getDBConnection("als");

			Calendar calendat = Calendar.getInstance();

			// Calendar��java.util.Date��ת��
			Date date_2 = calendat.getTime();

			SimpleDateFormat simpleDateFormate_2 = new SimpleDateFormat(
					"yyyy/MM/dd");

			SimpleDateFormat simpleDateFormate_3 = new SimpleDateFormat(
					"HH:mm:ss");

			date = simpleDateFormate_2.format(date_2);
			time = simpleDateFormate_3.format(date_2);
			System.out.println("yyyy-MM-dd HH:mm:ss"
					+ simpleDateFormate_2.format(date_2));
			System.out.println("HH:mm:ss" + simpleDateFormate_3.format(date_2));

			if (request.containsKey("PageSize")) {// ÿҳ����
				this.pageSize = Integer.parseInt(request.get("PageSize")
						.toString());
			}
			if (request.containsKey("CurPage")) {// ��ǰҳ��
				this.curPage = Integer.parseInt(request.get("CurPage")
						.toString());
			}
			if (request.containsKey("SearchKey")) {// ��ѯ������֤�����룩
				this.SearchKey = request.get("SearchKey").toString();
			}
			if (request.containsKey("BStatus")) {// ��ѯ������֤�����룩
				this.CustomerType = request.get("BStatus").toString();
			}
			System.out.println("-----CustomerType" + CustomerType);

			serialNO = DBKeyHelp.getSerialNo("inspect_info", "SerialNo");
			String sUserId = SessionManager.getUserId(this.getSessionKey());// �û���

			//add ldfang20140414
			String  sqlInd = "select CustomerID,CustomerName, rownumber() over(order by CustomerID desc) AS rn "+
							" from CUSTOMER_INFO where customertype like '03%' and "+
							" CUSTOMERCLASSIFY = '0130' and CustomerID in(Select CustomerID from Customer_Belong where BelongAttribute='1' and UserID=?)";
			
			String  sqlEnt =  "select CustomerID,CustomerName, rownumber() over(order by CustomerID desc) AS rn "+
							" from CUSTOMER_INFO where customertype like '01%' and "+
							" CUSTOMERCLASSIFY = '0130' and CustomerID in(Select CustomerID from Customer_Belong where BelongAttribute='1' and UserID=?)";
			//end ldfang
			String sgetorg = " select belongorg from user_info where userid =?";//������

			if (!(SearchKey.equals(""))) {// ��ѯ�������ͻ����ƣ�
				String sWhereClause1 = " and ( CustomerName like '%"
						+ SearchKey + "%')";
				//add ldfang 
				sqlEnt+=sWhereClause1;
				sqlInd+=sWhereClause1;
				//end
			}


			conn = ARE.getDBConnection("als");
			//add by ldfang 20140527
			PreparedStatement psorg = conn.prepareStatement(sgetorg);
			psorg.setString(1, sUserId);

			ResultSet rsorg = psorg.executeQuery();

			if (rsorg.next()) {
				sOrgID=rsorg.getString("belongorg");
			}
			rsorg.getStatement().close();
			//end 
			if (CustomerType.equals("01")) {//��˾
				System.out.println("before-----");
				Pageable.setDBType("db2");

				
				sqlEnt = "SELECT * FROM (" + sqlEnt + ") as PAGETABLE where PAGETABLE.rn BETWEEN "+ (this.pageSize * this.curPage + 1) + " AND " + ((1 + this.curPage) * this.pageSize);

				ARE.getLog().info(sqlEnt);

				PreparedStatement ps = conn.prepareStatement(sqlEnt);
				ps.setString(1, sUserId);

				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					JSONObject obj = new JSONObject();

					obj.put("CustomerName", rs.getString("CustomerName"));
					obj.put("CustomerId", rs.getString("CustomerID"));
					//add ldfang
					String certifyInfo = getLateDate(rs.getString("CustomerID"), sUserId, sOrgID, conn).toString();
					String riskInfo = getRisk(rs.getString("CustomerID"), sUserId, sOrgID, conn).toString();
					obj.put("CertifyInfo", certifyInfo);
					obj.put("RiskInfo", riskInfo);
					//end
					customerNames.add(obj);

				}

				rs.getStatement().close();
			} else if (CustomerType.equals("02")) {//����

				
				sqlInd = "SELECT * FROM (" + sqlInd + ") as PAGETABLE where PAGETABLE.rn BETWEEN "+ (this.pageSize * this.curPage + 1) + " AND " + ((1 + this.curPage) * this.pageSize);
				ARE.getLog().info(sqlInd);

				PreparedStatement ps = conn.prepareStatement(sqlInd);
				ps.setString(1, sUserId);
				ResultSet rs = ps.executeQuery();

				System.out.println("after-----");
				ARE.getLog().info(sqlInd);
				while (rs.next()) {
					JSONObject obj = new JSONObject();

					obj.put("CustomerName", rs.getString("CustomerName"));
					obj.put("CustomerId", rs.getString("CustomerID"));
					//add ldfang
					String certifyInfo = getLateDate(rs.getString("CustomerID"), sUserId, sOrgID, conn).toString();
					String riskInfo = getRisk(rs.getString("CustomerID"), sUserId, sOrgID, conn).toString();
					obj.put("CertifyInfo", certifyInfo);
					obj.put("RiskInfo", riskInfo);
					//end
					
					customerNames.add(obj);
				}
				rs.getStatement().close();
			}

			response.put("customerNames", customerNames);
			response.put("CheckNums", serialNO);
			response.put("CheckDate", date);
			response.put("CheckTime", time);

		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			throw new HandlerException(e.getMessage());

		}

		finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				ARE.getLog().error("���ݿ�ر�ʧ��:" + e.getMessage());
				e.printStackTrace();
			}
		}

		return response;
	}
	
	private static String getLateDate(String sCustomerNo,String sUserId,String sOrgID,Connection conn) throws Exception{
		String day = StringFunction.getToday();
		String day10 = StringFunction.getRelativeDate(day, 10);
		StringBuffer certifyInfo=new StringBuffer("");
		
	    //֤��������Ϣ
		String sLicense = " select count(*) as cnt from CUSTOMER_BELONG CB,ENT_INFO EI, CUSTOMER_INFO CI where  CB.CustomerID=EI.CustomerID  and  CB.CustomerID=CI.CustomerID and cb.BELONGATTRIBUTE2 = '1' "
				+ " and CI.customerid=? and cb.UserID =? and CB.INPUTORGID=? and    LICENSEMATURITY<= ? and LICENSEMATURITY >= to_char(current_date,'yyyy/MM/dd')";
		String sOrgNo = "select count(*) as cnt from CUSTOMER_BELONG CB,ENT_INFO EI, CUSTOMER_INFO CI where  CB.CustomerID=EI.CustomerID  and  CB.CustomerID=CI.CustomerID and CI.certType='Ent01'  and cb.BELONGATTRIBUTE2 = '1' and CI.CUSTOMERID = ? and cb.UserID =? and CB.INPUTORGID=? and  corpmaturitydate<=? and corpmaturitydate >= to_char(current_date,'yyyy/MM/dd')";
		String sTrust = "select count(*) as cnt from CUSTOMER_BELONG CB,ENT_INFO EI, CUSTOMER_INFO CI where  CB.CustomerID=EI.CustomerID  and  CB.CustomerID=CI.CustomerID and CI.CUSTOMERID =? AND cb.BELONGATTRIBUTE2 = '1' and cb.UserID =? and CB.INPUTORGID=? and  CreditCodeMaturityDate<=? and CreditCodeMaturityDate >= to_char(current_date,'yyyy/MM/dd')";
		String sHouse = " select count(*) as cnt from  CUSTOMER_BELONG CB, CUSTOMER_INFO CI,ENT_REALTYAUTH ER where  CB.CustomerID=CI.CustomerID  and ER.CUSTOMERID=CI.CUSTOMERID and "+
                        " cb.BELONGATTRIBUTE2 = '1'  and ER.CorpMaturityDate >= to_char(current_date,'yyyy/MM/dd')  and  ER.CorpMaturityDate<=?"+
                        " and cb.UserID =? and CB.INPUTORGID=? and CI.CUSTOMERID=?";
		String sTrade = " select count(*) as cnt from  CUSTOMER_BELONG CB, CUSTOMER_INFO CI,ENT_ENTRANCEAUTH EE where  CB.CustomerID=CI.CustomerID  and EE.CUSTOMERID=CI.CUSTOMERID and "+
						" cb.BELONGATTRIBUTE2 = '1'  and EE.CorpMaturityDate >= to_char(current_date,'yyyy/MM/dd')  and  EE.CorpMaturityDate<=? "+
						" and cb.UserID =? and CB.INPUTORGID=? And CI.CUSTOMERID =?";
		String sTexuWork = "select count(*) as cnt from  CUSTOMER_BELONG CB, CUSTOMER_INFO CI,ENT_AUTH EA where  CB.CustomerID=CI.CustomerID  and EA.CUSTOMERID=CI.CUSTOMERID and"+ 
						" cb.BELONGATTRIBUTE2 = '1'  and EA.CorpMaturityDate >= to_char(current_date,'yyyy/MM/dd')  and  EA.CorpMaturityDate<=?"+
						" and cb.UserID =? and CB.INPUTORGID=? and CI.CUSTOMERID=?";
		String sAbout = " select count(*) as cnt from  CUSTOMER_BELONG CB, CUSTOMER_INFO CI,ENT_AUTH EA where  CB.CustomerID=CI.CustomerID  and EA.CUSTOMERID=CI.CUSTOMERID and"+ 
						" cb.BELONGATTRIBUTE2 = '1'  and EA.Validdate >= to_char(current_date,'yyyy/MM/dd')  and  EA.Validdate<=?"+
						" and cb.UserID =? and CB.INPUTORGID=? and CI.CUSTOMERID=?";
		
		//֤������
		//Ӫҵִ��
		PreparedStatement psLicense = conn.prepareStatement(sLicense);
		psLicense.setString(1, sCustomerNo);
		psLicense.setString(2, sUserId);
		psLicense.setString(3, sOrgID);
		psLicense.setString(4, day10);
		ARE.getLog().info(sLicense);
		ResultSet rsLicense = psLicense.executeQuery();
		while(rsLicense.next()) {
			JSONObject obj = new JSONObject();
			if(rsLicense.getInt("cnt")!=0){

			   certifyInfo.append("Ӫҵִ��10���ڵ���").append(";");

			}
		}
		rsLicense.getStatement().close();
		
		//��֯��������
		PreparedStatement psOrgNo = conn.prepareStatement(sOrgNo);
		psOrgNo.setString(1, sCustomerNo);
		psOrgNo.setString(2, sUserId);
		psOrgNo.setString(3, sOrgID);
		psOrgNo.setString(4, day10);
		ARE.getLog().info(sOrgNo);
		ResultSet rsOrgNo = psOrgNo.executeQuery();
		while(rsOrgNo.next()) {
			JSONObject obj = new JSONObject();
			if(rsOrgNo.getInt("cnt")!=0){
			   certifyInfo.append("��֯�ṹ����֤10���ڵ���").append(";");
					}
		}
		rsOrgNo.getStatement().close();
		
		//�������ô���֤
		PreparedStatement psTrust = conn.prepareStatement(sTrust);
		psTrust.setString(1, sCustomerNo);
		psTrust.setString(2, sUserId);
		psTrust.setString(3, sOrgID);
		psTrust.setString(4, day10);
		ARE.getLog().info(sTrust);
		ResultSet rsTrust = psTrust.executeQuery();
		while(rsTrust.next()) {
		
			if(rsTrust.getInt("cnt")!=0){
			 
			   certifyInfo.append("�������ô���֤10���ڵ���;").append(";");
		
			}
		}
		rsTrust.getStatement().close();
		
		//���ز�����֤��
		PreparedStatement psHouse = conn.prepareStatement(sHouse);
		psHouse.setString(1, day10);
		psHouse.setString(2, sUserId);
		psHouse.setString(3, sOrgID);
		psHouse.setString(4, sCustomerNo);
		ARE.getLog().info(sHouse);
		ResultSet rsHouse = psHouse.executeQuery();
		while(rsHouse.next()) {
			
			if(rsHouse.getInt("cnt")!=0){
			  
			   
			   certifyInfo.append("���ز�����֤��10���ڵ���").append(";");
			
			}
		}
		rsHouse.getStatement().close();
		
		//������ó��֤��
		PreparedStatement psTrade = conn.prepareStatement(sTrade);
		psTrade.setString(1, day10);
		psTrade.setString(2, sUserId);
		psTrade.setString(3, sOrgID);
		psTrade.setString(4, sCustomerNo);
		ARE.getLog().info(sTrade);
		ResultSet rsTrade = psTrade.executeQuery();
		while(rsTrade.next()) {
		
			if(rsTrade.getInt("cnt")!=0){
			  
			   certifyInfo.append("������ó��֤��10���ڵ���").append(";");
			}
		}
		rsTrade.getStatement().close();
		
		//������ҵ��Ӫ֤��
		PreparedStatement pstexu = conn.prepareStatement(sTexuWork);
		pstexu.setString(1, day10);
		pstexu.setString(2, sUserId);
		pstexu.setString(3, sOrgID);
		pstexu.setString(4, sCustomerNo);
		ARE.getLog().info(sTexuWork);
		ResultSet rsTexu = pstexu.executeQuery();
		while(rsTexu.next()) {
			
			if(rsTexu.getInt("cnt")!=0){
			   certifyInfo.append("������ҵ��Ӫ֤��10���ڵ���").append(";");
			}
		}
		rsTexu.getStatement().close();
		
		//�����֤��Ϣ
		PreparedStatement psabout = conn.prepareStatement(sAbout);
		psabout.setString(1, day10);
		psabout.setString(2, sUserId);
		psabout.setString(3, sOrgID);
		psabout.setString(4, sCustomerNo);
		ARE.getLog().info(sAbout);
		ResultSet rsabout = psabout.executeQuery();
		while(rsabout.next()) {
		
			if(rsabout.getInt("cnt")!=0){
			   certifyInfo.append("�����֤��Ϣ10���ڵ���");
			}
		}
		rsabout.getStatement().close();
		
		return certifyInfo.toString();
	}
	
	//Ԥ����Ϣ
	private static String getRisk(String customerid,String sUserId,String sOrgId,Connection conn) throws Exception{
		String day = StringFunction.getToday();
		String day10 = StringFunction.getRelativeDate(day, 10);
		StringBuffer riskInfo=new StringBuffer("");
	    //֤��������Ϣ
		String sYujing = " select RISK_ANALYSE.RISKINFO as RISKINFO From RISK_ANALYSE,FLOW_OBJECT Where FLOW_OBJECT.OBJECTNO=RISK_ANALYSE.SERIALNO  and FLOW_OBJECT.ObjectType =  'RiskAnalyseApply' and FLOW_OBJECT.PhaseType='1030'  and FLOW_OBJECT.ApplyType='RiskAnalyseApply'  and FLOW_OBJECT.UserID=? and RISK_ANALYSE.CUSTOMERID=?";
			
		PreparedStatement ps = conn.prepareStatement(sYujing);
		ps.setString(1, sUserId);
		ps.setString(2, customerid);
		ARE.getLog().info(sYujing);
		ResultSet rs = ps.executeQuery();	
		while(rs.next()){
			riskInfo.append(rs.getString("RISKINFO")).append(";");
		}
		rs.getStatement().close();
		return riskInfo.toString();
	}
			

}
