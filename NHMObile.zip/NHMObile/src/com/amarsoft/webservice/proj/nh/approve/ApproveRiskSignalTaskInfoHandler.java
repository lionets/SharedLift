/**
 * 
 */
package com.amarsoft.webservice.proj.nh.approve;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;

/**
 * �����϶���������
 * 
 * ���������
 * 		SerialNo
 * ���������
 * 		��������ҳ��Ҫ��
 * 
 * @author jwu1  2015/11/02
 *
 */
public class ApproveRiskSignalTaskInfoHandler extends JSONHandlerWithSession{

	private String sSerialNo = "";
	
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		if(request.containsKey("SerialNo")){
			sSerialNo = request.get("SerialNo").toString();
		}else{
			throw new HandlerException("ȱ�ٲ���SerialNo");
		}
		
		JSONObject response = new JSONObject();
		
		String  sSqlApply = "Select getCustomerName(CustomerID) as CustomerName,getItemName('ClassifyResult',FinallyResult) as FinallyResultName,getItemName('ClassifyResult',Result5) as LastestResultName,"
				+ " getItemName('ClassifyResult',Result5) as Result5Name,getItemName('ClassifyResult',MatrixResult) as MatrixResultName,getItemName('ClassifyResult',Result1) as Result1Name,getItemName('ClassifyResult',Result2) as Result2Name,"
				+ " getItemName('ClassifyResult',Result3) as Result3Name,getItemName('ClassifyResult',Result4) as Result4Name,BusinessBalance,CreditBalance,OverdueDays,OverdueInterestDays,"
				+ " OverdueTerms,getItemName('LowRiskFlag',LowRiskFlag) as LowRiskFlag,getItemName('YesNo',FlowRight) as FlowRightName,getItemName('ClassifySource',ClassifySource) as ClassifySourceName,"
				+ " getUserName(InputUserID) as InputUserName,getOrgName(InputOrgID) as InputOrgName,getItemName('YesNo',Disputed) as DisputedName  "
				+ " from CLASSIFY_CUSTOMER where SerialNo='"+sSerialNo+"' ";
		
		try {
			conn = ARE.getDBConnection("als");
			
			PreparedStatement psApply = conn.prepareStatement(sSqlApply);
			ARE.getLog().info(sSqlApply);
			ResultSet rs = psApply.executeQuery();
			if(rs.next()){
				response.put("CustomerName", rs.getString("CustomerName")==null?"":rs.getString("CustomerName"));//�ͻ�����
				response.put("FinallyResultName", rs.getString("FinallyResultName")==null?"":rs.getString("FinallyResultName"));//���շ�����
				response.put("Result5Name", rs.getString("Result5Name")==null?"":rs.getString("Result5Name"));//���ڷ�����
				response.put("LastestResultName", rs.getString("LastestResultName")==null?"":rs.getString("LastestResultName"));//�ϼ��ȷ�����
				response.put("MatrixResultName", rs.getString("MatrixResultName")==null?"":rs.getString("MatrixResultName"));//���������
				response.put("Result1Name", rs.getString("Result1Name")==null?"":rs.getString("Result1Name"));//�ͻ������϶����
				response.put("Result2Name", rs.getString("Result2Name")==null?"":rs.getString("Result2Name"));//֧���϶�С���϶����
				response.put("Result3Name", rs.getString("Result3Name")==null?"":rs.getString("Result3Name"));//�����϶�С���϶����
				response.put("Result4Name", rs.getString("Result4Name")==null?"":rs.getString("Result4Name"));//���з��չ���ίԱ���϶����
				response.put("BusinessBalance", (new DecimalFormat("#0.00").format(rs.getDouble("BusinessBalance")/10000))+"��Ԫ");//�������
				response.put("BusinessBalance", (new DecimalFormat("#0.00").format(rs.getDouble("CreditBalance")/10000))+"��Ԫ");//�������
				response.put("OverdueDays", rs.getString("OverdueDays")==null?"":rs.getString("OverdueDays"));//Ƿ������
				response.put("OverdueInterestDays", rs.getString("OverdueInterestDays")==null?"":rs.getString("OverdueInterestDays"));//ǷϢ����
				response.put("OverdueTerms", rs.getString("OverdueTerms")==null?"":rs.getString("OverdueTerms"));//ΥԼ����
				response.put("LowRiskFlag", rs.getString("LowRiskFlag")==null?"":rs.getString("LowRiskFlag"));//�ͷ��ձ�־
				response.put("FlowRightName", rs.getString("FlowRightName")==null?"":rs.getString("FlowRightName"));//�Ƿ�����Ȩ��
				response.put("ClassifySourceName", rs.getString("ClassifySourceName")==null?"":rs.getString("ClassifySourceName"));//������Դ
				response.put("FlowRightName", rs.getString("FlowRightName")==null?"":rs.getString("FlowRightName"));//�Ƿ�����Ȩ��
				response.put("DisputedName", rs.getString("DisputedName")==null?"":rs.getString("DisputedName"));//�Ƿ�������
				response.put("InputUserName", rs.getString("InputUserName")==null?"":rs.getString("InputUserName"));//�ܻ���
				response.put("InputOrgName", rs.getString("InputOrgName")==null?"":rs.getString("InputOrgName"));//�ܻ�����
				
			}
			rs.getStatement().close();
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}

}
