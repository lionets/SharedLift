package com.amarsoft.webservice.proj.nh.approve;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.Transaction;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.context.ASUser;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;
import com.amarsoft.webservice.DBLink;

/**
 * ����������Ʒ����ǩ�����ʱѡ���Ÿ�����
 * ���������
		FlowNo��
		PhaseNo��
		SearchKey:��������
		
 * ���������(�б�����)array:
		�û���ţ�
		�û�������
		�û���λ��
		
 * @author myli1  2016/2/19
 *
 */
public class ApproveSelectListHandler extends JSONHandlerWithSession {
	private String sRoleID = "";
	private String sFlowNo = "";
	private String sPhaseNo = "";
	private String searchKey = "";
	
	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		Pageable.setDBType("DB2");
		Connection conn = null;
		if(request.containsKey("FlowNo")){
			this.sFlowNo = request.get("FlowNo").toString();
		}else{
			throw new HandlerException("ȱ��״̬����FlowNo");
		}
		if(request.containsKey("PhaseNo")){
			this.sPhaseNo = request.get("PhaseNo").toString();
		}else{
			throw new HandlerException("ȱ��״̬����PhaseNo");
		}
		if(request.containsKey("SearchKey")&&!request.get("SearchKey").toString().equals("")){
			this.searchKey = request.get("SearchKey").toString();
		}else{
			this.searchKey = "";
		}
		
		String sUserId = SessionManager.getUserId(this.getSessionKey());
		
		
		Transaction sqlca = DBLink.getSqlca();
		ASUser curUser = null;
		String sOrgID = "";
		String sSql = "";
		
		try {
			curUser = ASUser.getUser(sUserId,sqlca);
			sOrgID = curUser.getOrgID();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if(sOrgID.equals("10010")){
			sRoleID="0035";//��˾��������
		}else if(sOrgID.equals("10030")){
			sRoleID="0034";//���ʲ�������
		}else if(sOrgID.equals("10050")){
			sRoleID="062";//�������ʲ�����
		}
		if((sFlowNo.equals("CreditFlow")&&sPhaseNo.equals("0070"))){
			sSql = "select UI.UserID as UserID,UI.UserName as UserName,RI.RoleName as RoleName from USER_INFO UI,USER_ROLE UR,AWE_ROLE_INFO RI  "
					+ "where UI.UserID = UR.UserID and UR.RoleID = RI.RoleID and "
					+ "UI.BelongOrg = '"+sOrgID+"' and UI.Status = '1' and UR.RoleID like '"+sRoleID+"'and UI.UserName like '%"+searchKey+"%'";
		}else if((sFlowNo.equals("CreditFlow")&&sPhaseNo.equals("0075"))||(sFlowNo.equals("EntCreditChangeFlow")&&sPhaseNo.equals("0025"))){
			sSql = "select UI.UserID as UserID,UI.UserName as UserName,RI.RoleName as RoleName from USER_INFO UI,USER_ROLE UR,AWE_ROLE_INFO RI  "
					+ "where UI.UserID = UR.UserID and UR.RoleID = RI.RoleID and "
					+ "UI.Status = '1' and UR.RoleID = '"+sRoleID+"'";
		}
		
		JSONObject response = new JSONObject();
		JSONArray resultArray = new JSONArray();

		ResultSet rs = null;
		PreparedStatement ps = null;
		
		try {
			conn= ARE.getDBConnection("als");
			//��ѯ�б�����
			ARE.getLog().info(sSql);
			ps = conn.prepareStatement(sSql);
			rs = ps.executeQuery();
			while(rs.next()){
				JSONObject obj = new JSONObject();
				obj.put("UserID", rs.getString("UserID"));		//�û����
				obj.put("UserName", rs.getString("UserName"));		//�û����
				obj.put("RoleName", rs.getString("RoleName"));		//�û���λ
				resultArray.add(obj);
			}
			rs.getStatement().close();
			response.put("DueArray", resultArray);
			
		} catch (Exception e) {

			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		finally{
			try{
				sqlca.disConnect();
				conn.commit();
				if(conn!=null)conn.close();
				if(ps!=null)ps.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	
	}
	
}
