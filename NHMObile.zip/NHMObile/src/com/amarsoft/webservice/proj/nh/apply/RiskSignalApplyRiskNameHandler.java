package com.amarsoft.webservice.proj.nh.apply;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.Transaction;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.context.ASUser;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;
import com.amarsoft.webservice.DBLink;

/**
 * �������--
 * ���������
	
 * �����������array��
	
	
 * @author jwu1 2015-10-28
 *
 */
public class RiskSignalApplyRiskNameHandler extends JSONHandlerWithSession {
	private String sRiskType = "";	//Ԥ������
	private String sRiskLevel = "";	//���ռ���
	
	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		
		if(request.containsKey("RiskType")){
			this.sRiskType = request.get("RiskType").toString();
		}
		if(request.containsKey("RiskLevel")){
			this.sRiskLevel = request.get("RiskLevel").toString();
		}
		
		String sWhereCond = "";
		String sUserId = SessionManager.getUserId(this.getSessionKey());	//��ǰ��¼�û�ID
		Transaction Sqlca = DBLink.getSqlca();	//��ȡ����
		ArrayList<String> roleList = null;		//��ѯ��ǰ�û���ӵ�е����н�ɫ
		String sOrgID = "";	//��ǰ�û����ڻ���
		try {
			ASUser curUser = ASUser.getUser(sUserId, Sqlca);
			sOrgID = curUser.getOrgID();
			roleList = curUser.getRoleTable();
			
		} catch (Exception e0) {
			e0.printStackTrace();
		}
		
		//����Ԥ���б���ѯ
		String query = "";
		
		Connection conn = null;
		JSONObject result = new JSONObject();
		JSONArray resultArray = new JSONArray();
		
		try {
			//�������ݿ�
			conn= ARE.getDBConnection("als");
			
			ARE.getLog().info(query);
			PreparedStatement ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				JSONObject obj = new JSONObject();
				obj.put("SerialNo", rs.getString("SerialNo"));	//������ˮ��
				obj.put("CustomerName", rs.getString("CustomerName"));	//�ͻ�����
				resultArray.add(obj);
				
			}
			rs.getStatement().close();
			result.put("DueArray", resultArray);
			
		
		}catch (Exception e) {
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		
		return result;
	}

}
