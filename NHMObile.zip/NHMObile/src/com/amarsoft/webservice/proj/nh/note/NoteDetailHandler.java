package com.amarsoft.webservice.proj.nh.note;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.app.httpclient.CMSHttpClient;
import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;
/**
 * ��������
 * ���������
	DocNo - �ĵ����
	CurPage - ���ص�ҳ��
	PageSize - ÿҳ������
 * ���������
 * array��
    MentNo - �������
    MentName - ��������
    MentPath - ����ȫ·��
 * @author 
 *
 */

public class NoteDetailHandler extends JSONHandlerWithSession {
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		JSONObject result = new JSONObject();
		CMSHttpClient client = new CMSHttpClient();
		request.put("userid", SessionManager.getUserId(this.getSessionKey()));
		result = client.httpClient("noteDetail", request);
		if (result.containsKey("Exception")) {
			String exception=result.get("Exception").toString();
			throw new HandlerException(exception);
		}
		return result;
	}
}
