package com.amarsoft.webservice.proj.nh.bizquery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
/**
 * ������ҵ�ṹ��ѯ3
 * ���������
	SearchKey - ��ѯ��������������)[�޴�֧�У�����֧��....]
	Month - ��ѯ�����������ĳ���·ݣ�
 * ���������
	html

 * @author 
 *
 */

public class TableQueryHandler extends JSONHandlerWithSession {

	private String SearchKey = "";
	private String month = "";
	private String sdate = StringFunction.getToday().substring(0,4);//��ǰ���
	
	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		StringBuffer result = new StringBuffer();
		if(request.containsKey("Month")){//���
			this.month = request.get("Month").toString();
		}
		if(request.containsKey("SearchKey")){//��ѯ����(��������)
			this.SearchKey =request.get("SearchKey").toString();
		}

		String query = " select industry,getItemName('IndustryType',Industry) as IndustryTypeName,industrybalance,industryrate from mobile_org_industry"
				+ " where currentyear=? and querymonth=? and substr(inputtime,6,2)=(select max(substr(inputtime,6,2)) from mobile_org_industry) ";
		if((SearchKey==null) || SearchKey.equals("")){//��ʼҳ�棬��ѯ����Ϊ��
			String sWhereClause = " and 1=2 ";
			query+=sWhereClause;
		}
		else {//��ѯ���������ƣ���ݣ�
			String sWhereClause = " and orgname = '"+SearchKey+"'";
			query+=sWhereClause;
		}
		String sOrderClause = " order by industry ";
		query+=sOrderClause;
		try {
		
			conn= ARE.getDBConnection("als");
			
			result.append("<!DOCTYPE html>");
			result.append("<html><head><meta charset=\"utf-8\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><Title>����������ҵ�ṹ��ѯ</title>");
			

			result.append("<style type=\"text/css\">");
			result.append("body { padding:0px;margin:5px;font-size:12px;font-family:\"΢���ź�\";}");
			result.append("table { border:1px solid #d8d8d8;padding:0px;margin-top:10px;-moz-border-radius: 10px 10px 0px 0px;-webkit-border-radius: 3px 3px 0px 0px;border-radius:10px 10px 0px 0px;}");
			result.append("th { padding-left:8px;background:#e8e8e8;color:#d4537a;font-size:14px;-moz-border-radius: 10px 10px 0px 0px;-webkit-border-radius: 3px 3px 0px 0px;border-radius:10px 10px 0px 0px;}");
			result.append("td { background:#FFFfff; color:#333333;padding-left:8px;line-height:24px;border-bottom:1px dotted #CCCCCC;}.left{ color:#333333; text-align:left; font-weight:bold;}.right{ color:#666666; text-align:right;padding-right:8px;}");
			
			result.append("</style></head><body><TABLE CELLSPACING=\"0\" COLS=\"3\" BORDER=\"1\" cellpadding=\"0\" style=\"border-collapse: collapse\"  bordercolor=\"#111111\" width=\"100%\">");
			result.append("	<TR>");
			result.append("		<TD colspan=\"1\" ALIGN=\"CENTER\" HEIGHT=\"20\" ALIGN=\"LEFT\" VALIGN=BOTTOM><FONT COLOR=\"#000000\">����</FONT></TD>");
			result.append("		<TD colspan=\"2\" HEIGHT=\"20\" ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#000000\">"+(SearchKey.equals("All") ? "���л���" : SearchKey )+"</FONT></TD>");//add 20140305
			result.append("	</TR>");
			result.append("	<TR>");
			result.append("		<TD colspan=\"1\" ALIGN=\"CENTER\" ALIGN=\"LEFT\" VALIGN=BOTTOM><FONT COLOR=\"#000000\">�·�(����)</FONT></TD>");
			result.append("		<TD colspan=\"2\" ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#000000\">"+month+"</FONT></TD>");//add 20140305
			result.append("	</TR>");
			result.append("	<TR>");
			result.append("		<TD  HEIGHT=\"45\" ALIGN=\"CENTER\" VALIGN=MIDDLE><B><FONT COLOR=\"#000000\">��ҵ</FONT></B></TD>");
			result.append("		<TD  ALIGN=\"CENTER\" VALIGN=MIDDLE><B><FONT COLOR=\"#000000\">�������</FONT></B></TD>");
			result.append("		<TD  ALIGN=\"CENTER\" VALIGN=MIDDLE><B><FONT COLOR=\"#000000\">ռ��</FONT></B></TD>");
			result.append("	</TR>");
	
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, sdate);
			ps.setString(2, month);
			ARE.getLog().info(query);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				result.append("	<TR>");
				result.append("		<TD  HEIGHT=\"45\" ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#000000\">"+rs.getString("IndustryTypeName")+"</FONT></TD>");//��ҵ
				result.append("		<TD  ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#000000\">"+(new DecimalFormat("#0.00").format(rs.getDouble("industrybalance")))+"</FONT></TD>");//�������
				result.append("		<TD  ALIGN=\"CENTER\" VALIGN=MIDDLE><FONT COLOR=\"#000000\">"+(new DecimalFormat("#0.00").format(rs.getDouble("industryrate")))+"</FONT></TD>");//ռ��
				result.append("	</TR>");
			}
			rs.getStatement().close();
		
		}catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		return result;
	}

}
