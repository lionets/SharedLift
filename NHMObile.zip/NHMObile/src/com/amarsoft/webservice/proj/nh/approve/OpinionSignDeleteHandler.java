/**
 * 
 */
package com.amarsoft.webservice.proj.nh.approve;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;

/**
 * ɾ������
 * @author Administrator
 * �����б�����ˮ�� SerialNo
 *
 */
public class OpinionSignDeleteHandler extends JSONHandlerWithSession{

	private String SerialNo = "";
	private String relativeNo = "";
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		JSONObject response = new JSONObject();
		if (!request.containsKey("SerialNo"))
			throw new HandlerException("��Ҫ��ˮ�Ų���");
		else {
			SerialNo = request.get("SerialNo").toString();
		}
		String isCredit = " select relativeno from flow_creditopinion where serialno=?";
		String deleteInfo = " update flow_creditopinion set OpinionState='0' where serialno=?"; 
		try{
			conn = ARE.getDBConnection("als");
			conn.setAutoCommit(false);
			PreparedStatement psPreparedStatement = conn.prepareStatement(isCredit);
			psPreparedStatement.setString(1, SerialNo);
			ResultSet rSet = psPreparedStatement.executeQuery();
			if(rSet.next()){
				relativeNo = rSet.getString("relativeno");
			}
			rSet.getStatement().close();
			if(relativeNo==null||relativeNo.equals("")){
				throw new Exception("��ҵ����ɾ����");
			}
			else {//ɾ��ҵ��
				PreparedStatement psUpdate = conn.prepareStatement(deleteInfo);
				psUpdate.setString(1, SerialNo);
				ARE.getLog().info(deleteInfo+" serialno="+SerialNo);
				psUpdate.executeUpdate();
				conn.commit();
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				ARE.getLog().error("���ݿ�ر�ʧ��:" + e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}

}
