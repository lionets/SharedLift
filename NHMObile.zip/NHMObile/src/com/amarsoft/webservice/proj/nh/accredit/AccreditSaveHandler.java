package com.amarsoft.webservice.proj.nh.accredit;

import java.sql.Connection;
import java.util.Properties;

import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.DBHandler;

/**
 * ҵ����Ȩ����
 * 
 * ���������
 * 
 * ���������
 * 
 * @author jyli
 */
public class AccreditSaveHandler extends DBHandler {

	@Override
	protected Object createReponseWithDB(JSONObject request, Properties arg1,
			Connection conn) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
