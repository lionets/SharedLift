package com.amarsoft.webservice.proj.nh.apply;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.DBKeyHelp;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.session.SessionManager;

/**
 * �������--����Ԥ�������ʼ������
 * ���������
		
		
 * ���������
	    result��success\fail
	
 * @author jwu1 2015-11-05
 *
 */
public class RiskSignalApplyInitFlowHandler extends JSONHandlerWithSession {
	private String SerialNo = "";
	
	@Override
	public Object createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		if(request.containsKey("SerialNo")){
			this.SerialNo = request.get("SerialNo").toString();
		}
		
		String sUserId = SessionManager.getUserId(this.getSessionKey());	//��ǰ��¼�û�ID
		String query = " ";
		
		if(SerialNo.equals("")){
			query = "  ";
			
		}else{
			query = " update RISK_SIGNAL set CustomerID=?,CustomerName=?,CustomerType=?,IndustryType=?,RiskType=?,RiskLevel=?,RiskName=?,"
					+"RiskOrigin=?,MeaSure=?,RiskInfo=?,Remark=? where SerialNo='"+SerialNo+"' ";
			
		}
		
		Connection conn = null;
		JSONObject result = new JSONObject();
		JSONArray resultArray = new JSONArray();
		
		try {
			//�������ݿ�
			conn= ARE.getDBConnection("als");
			
			//������ˮ��
			String SerialNo0 = DBKeyHelp.getSerialNo("RISK_SIGNAL", "SERIALNO","yyyyMMdd", "00000000", new Date());
			
			ARE.getLog().info(query);
			PreparedStatement ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				
				
			}
			rs.getStatement().close();
			result.put("DueArray", resultArray);
			
		
		}catch (Exception e) {
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		}
		finally{
			try{
				conn.commit();
				if(conn!=null)conn.close();
			}
			catch(Exception e){
				ARE.getLog().error("���ݿ�ر�ʧ��:"+e.getMessage());
				e.printStackTrace();
			}
		}
		
		return result;
	}

}
