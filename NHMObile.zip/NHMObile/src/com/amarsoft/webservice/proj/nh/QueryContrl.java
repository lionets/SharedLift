package com.amarsoft.webservice.proj.nh;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QueryContrl {

	/**
	 * �ж��Ƿ��ѯȨ��
	 * 0���ͻ�����Ȩ��
	 * 1������Ȩ��
	 * OrgID ֧�м�֧�в���Ȩ��
	 * @param userID
	 * @param conn
	 * @return
	 */
	public  static String getCondition(String userID,Connection conn){
		String sReturn = "1";
		ResultSet rs = null;
		try {
			rs = conn.createStatement().executeQuery("Select 1 from User_Role where Userid='"+userID+"' and RoleID in('480','481','482')");
			if(rs.next()){
				sReturn = "0";
			}
			rs.close();
			if("1".equals(sReturn)){
				rs = conn.createStatement().executeQuery("select OrgID from Org_Info where OrgID=(select BelongOrg from User_Info where UserID='"+userID+"') and OrgLevel in('6','9')");
				if(rs.next()){
					sReturn = rs.getString(1);
				}
				rs.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sReturn;
	}
}
