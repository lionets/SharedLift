package com.amarsoft.webservice.proj.nh.accredit;

import java.sql.Connection;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.DBHandler;

/**
 * ҵ����Ȩ����
 * 
 * 
 * 
 * ���������
 * 
 * ���������
 * 
 * @author jyli
 */
public class AccreditEditHandler extends DBHandler {

	@Override
	protected Object createReponseWithDB(JSONObject request, Properties arg1,
			Connection conn) throws Exception {
		// TODO Auto-generated method stub
		conn = null;
		try {
			conn = ARE.getDBConnection("als");
			JSONObject obj = new JSONObject();
			obj.put("AccreditOrgName", "�Ϻ�֧��");
			obj.put("CustomerName", "��ĳĳ");
			obj.put("BusinessType", "XXXXX");
			obj.put("CreditMoney", "1000");
			obj.put("Process", "XXXX");
			return obj;

		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}

		finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}
