package com.amarsoft.webservice.proj.nh.vocation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.common.attachment.FileNameHelper;
import com.amarsoft.awe.util.ASResultSet;
import com.amarsoft.awe.util.DBKeyHelp;
import com.amarsoft.awe.util.GetSerialNo;
import com.amarsoft.awe.util.SqlObject;
import com.amarsoft.awe.util.Transaction;
import com.amarsoft.biz.formatdoc.model.FormatDocConfig;
import com.amarsoft.context.ASUser;
import com.amarsoft.webservice.DBLink;

/**
 * ����ͻ���鱨�棺Ӱ�������ϴ�
 * 2015/11/27
 * @author WJ
 *
 */
public class UploadReportPhotoServlet extends HttpServlet{
	
	 // �ϴ��ļ���
    private File fileUpload;
    // �ϴ��ļ�����
    private String imageContentType;
    // ��װ�ϴ��ļ���
    private String imageFileName;
    private String objectNo ;
    private String objectType ;
    private String filePath ;
    private String fileName ;
    private String userId ;
    private String fileType ;
    private String address ;
    private File uploadFile ; 
    private long fileLength ;
	private String sCustomerID="";

	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF8") ;
		resp.setCharacterEncoding("UTF8") ;
		boolean isMultipart = ServletFileUpload.isMultipartContent(request) ;
		Transaction Sqlca = null;
//		String sFileSavePath = "/appfs/ncmsFile/als/Image";    
		FormatDocConfig config = FormatDocConfig.getInstance();
		String sFileSavePath = config.getUploadSavePath();
		ARE.getLog().info("sFileSavePath:"+sFileSavePath);
 		String sFileNameType = "SRC";       					
 		String sFileSaveMode = "Disk";		//����ļ���������
 		System.out.println("request========="+request);
 		String sDocNo = ""; //�ĵ����
		String sTypeNo = ""; 
		String sBranchMenu = ""; 
		String sNewSql = "";
		String sSql = "",sSql1="";
		String preTempStr="",lastTempStr="";
 		//System.out.println("_______________��������____________________");
		if(isMultipart){
			
			java.util.Date dateNow = new java.util.Date();
    		SimpleDateFormat sdfTemp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    		String sBeginTime=sdfTemp.format(dateNow);

			FileItemFactory factory = new DiskFileItemFactory() ;
			ServletFileUpload upload = new ServletFileUpload(factory) ;
			try {
				List<FileItem> items =  upload.parseRequest(request) ;
				
	        	Sqlca = DBLink.getSqlca();
	        	SqlObject so = null,so1=null;
	        	String sFullPath = "";
	        	String sFilePath = "";
	        	
				DBKeyHelp.setDataSource("als");
	        	sDocNo = DBKeyHelp.getSerialNo("REST_ATTACHMENT", "DOCNO");
	        	ARE.getLog().info("sDocNo:"+sDocNo);
	        	String sAttachmentNo = DBKeyHelp.getSerialNoFromDB("DOC_ATTACHMENT","AttachmentNo","DocNo='"+sDocNo+"'","","000",new java.util.Date(),Sqlca);   
	        	sNewSql = "insert into DOC_ATTACHMENT(DocNo,AttachmentNo) values(:DocNo,:AttachmentNo)";
				so = new SqlObject(sNewSql).setParameter("DocNo",sDocNo).setParameter("AttachmentNo",sAttachmentNo);
				Sqlca.executeSQL(so);
				
				for(FileItem item:items){
					if(item.isFormField()){
						System.out.println("item.getFieldName()="+item.getFieldName()+" item.getString()="+ item.getString());
						if(item.getFieldName().equals("TypeNo")){
							sTypeNo = item.getString() ;
						}else if(item.getFieldName().equals("ObjectNo")){
							objectNo = item.getString() ;
						}else if(item.getFieldName().equals("ObjectType")){
							objectType = item.getString() ;
						}else if(item.getFieldName().equals("FilePath")){
							filePath = item.getString() ;
							filePath = new String(filePath.getBytes("iso-8859-1"), "UTF-8");
						}else if(item.getFieldName().equals("FileName")){
							fileName = item.getString() ;
							//�õ�����·�����ļ���
							fileName = StringFunction.getFileName(fileName);
							
							System.out.println("fileName===="+fileName);
							
							if(sFileSaveMode.equals("Disk")){ 
								sFullPath = getFullPath(sDocNo, sAttachmentNo,fileName, sFileSavePath, sFileNameType);
			              		//�õ������·�����ļ���
			             		sFilePath = FileNameHelper.getMidPath(sDocNo, sAttachmentNo)+"/"+sDocNo+"_"+sAttachmentNo+"_"+"/"+fileName;
			             		preTempStr = sFullPath.substring(0,sFullPath.lastIndexOf("/"));
			             		lastTempStr = sFullPath.substring(sFullPath.lastIndexOf("/")+1);
			             		ARE.getLog().info("�ļ����浽" + sFullPath);
							}
						}else if(item.getFieldName().equals("UserId")){
							userId = item.getString() ;
						}else if(item.getFieldName().equals("FileType")){
							fileType = item.getString() ;
						}else if(item.getFieldName().equals("Address")){
							address = item.getString() ;
							address = new String(address.getBytes("iso-8859-1"), "UTF-8");
						}else{
							address = "" ;
						}
					}else{
						uploadFile = new File(sFullPath) ;
						item.write(uploadFile) ;
						FileInputStream fis = new FileInputStream(uploadFile) ; 
						fileLength = fis.available() ;
						fis.close() ;
					}
				}
				ASUser curUser = ASUser.getUser(userId, Sqlca);	
	        	userId = curUser.getUserID();
				String orgId = curUser.getOrgID();
				sNewSql = "insert into REST_ATTACHMENT(DocNo,ObjectNo,ObjectType,AttachmentNo,Address) values(:DocNo,:ObjectNo,:ObjectType,:AttachmentNo,:Address)";
				so = new SqlObject(sNewSql).setParameter("DocNo",sDocNo).setParameter("ObjectNo", objectNo).setParameter("ObjectType", objectType).setParameter("Address", address).setParameter("AttachmentNo",sAttachmentNo);
				Sqlca.executeSQL(so);
				
				ASResultSet rs = Sqlca.getASResultSetForUpdate("SELECT DOC_ATTACHMENT.* FROM DOC_ATTACHMENT WHERE DocNo='"+sDocNo+"' and AttachmentNo='"+sAttachmentNo+"'");
				if(rs.next()){
		     		try {
						dateNow = new java.util.Date();
						String sEndTime=sdfTemp.format(dateNow);
			
						rs.updateString("FilePath",sFilePath); 
						rs.updateString("FullPath",sFullPath);
						rs.updateString("FileSaveMode",sFileSaveMode);  
						rs.updateString("FileName",fileName);  
						rs.updateString("ContentType", fileType);
						rs.updateString("ContentLength",fileLength+"");
						rs.updateString("BeginTime",sBeginTime);
						rs.updateString("EndTime",sEndTime);
						rs.updateString("ObjectType",objectType);
						rs.updateString("InputUser",userId);
						rs.updateString("InputOrg",orgId);
						rs.updateString("UploadPhaseType","1010");
						
						if(fileName.contains(".pdf") || fileName.contains(".PDF")){
							rs.updateString("ContentStatus","01");
						}else{
							rs.updateString("ContentStatus","");
						}
						
						rs.updateString("TypeNo",sTypeNo);
						rs.updateString("BranchMenu",sBranchMenu);
						rs.updateRow();
						rs.getStatement().close();

					}catch(Exception e){
						e.printStackTrace();
						sNewSql = "delete FROM doc_attachment WHERE DocNo=:DocNo and AttachmentNo=:AttachmentNo";
			           	so = new SqlObject(sNewSql).setParameter("DocNo",sDocNo).setParameter("AttachmentNo",sAttachmentNo);
			           	Sqlca.executeSQL(so);
			           	rs.getStatement().close();
		     		}
			   	}
				
				//�����ĵ���Ҫ����DOC_RELATIVE
				if((fileName.contains(".pdf") || fileName.contains(".PDF"))){
					String sBusinessDate = StringFunction.getToday();
					String type = "image";
					sSql = "insert into DOC_RELATIVE (DocNo,ObjectType,ObjectNo,Type) values (:DocNo,:ObjectType,:ObjectNo,:Type)";
					so = new SqlObject(sSql);
					so.setParameter("DocNo", sDocNo).setParameter("ObjectType", objectType).setParameter("ObjectNo", objectNo).setParameter("Type",type);
					Sqlca.executeSQL(so);
				}else if(fileName.toUpperCase().contains(".JPG") || fileName.toUpperCase().contains(".PNG") || fileName.toUpperCase().contains(".JPEG")){
					 dateNow = new java.util.Date();
				      sdfTemp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				        String sModifyTime=sdfTemp.format(dateNow);
						String sOperateUser = userId;
						ARE.getLog().info(sSql);
						GetSerialNo.setDataSource("als");
						String sSerialNo = GetSerialNo.getSerialNo("ECM_PAGE_FILE","SERIALNO"); //��ȡ��ˮ��
//						sSql = "insert into ECM_PAGE (ObjectType,ObjectNo,TypeNo,DocumentID,UploadPhase,BranchMenu,ModifyTime,OperateUser,Remark,ImageInfo,SerialNo,PageType) values (:ObjectType,:ObjectNo,:TypeNo,:DocumentID,:UploadPhase,:BranchMenu,:ModifyTime,:OperateUser,:Remark,:ImageInfo,:SerialNo,:PageType)";
//						so = new SqlObject(sSql);
//						so.setParameter("ObjectType", sObjectType).setParameter("ObjectNo", sObjectNo).setParameter("TypeNo", sTypeNo).setParameter("DocumentID", sFullPath).setParameter("UploadPhase", sObjectType).setParameter("BranchMenu", sBranchMenu).setParameter("ModifyTime", sModifyTime).setParameter("OperateUser", sOperateUser).setParameter("Remark", "").setParameter("ImageInfo", address).setParameter("SerialNo", sSerialNo).setParameter("PageType", "AfterLoan");
//						Sqlca.executeSQL(so);
						String sOperateOrg = orgId;
						//sSql = "insert into ECM_PAGE_NEW (ObjectType,ObjectNo,TypeNo,DocumentID,UploadPhase,BranchMenu,ModifyTime,OperateUser,Remark,SerialNo,PageType) values (:ObjectType,:ObjectNo,:TypeNo,:DocumentID,:UploadPhase,:BranchMenu,:ModifyTime,:OperateUser,:Remark,:SerialNo,:PageType)";
						//�ж���ECM_PAGE_NEW�����Ƿ����һ����¼�����û�������һ��
						String sCountSql1="select count(1) from ECM_PAGE_NEW EPN where EPN.ObjectType=:ObjectType and EPN.ObjectNo=:ObjectNo and EPN.TypeNo=:TypeNo and EPN.DocumentID=:DocumentID";
						String sCount1 = Sqlca.getString(new SqlObject(sCountSql1).setParameter("ObjectType", objectType).setParameter("ObjectNo", objectNo).setParameter("TypeNo", sTypeNo).setParameter("DocumentID", preTempStr));
						System.out.println("sCount1="+sCount1);
						System.out.println("objectType==="+objectType);
						if( sCount1 == null || Integer.parseInt(sCount1) <=0){
							//��ȡ�ͻ����
							if("Customer".equals(objectType)){
								sCustomerID=objectNo;
							}else if("CreditApply".equals(objectType)){
								sCustomerID = Sqlca.getString("select CustomerID from Business_Apply where SerialNo='"+objectNo+"'");
							}else if("CreditApplyChange".equals(objectType)){
								sCustomerID = Sqlca.getString("select CustomerID from APPROVE_CHANGE where SerialNo='"+objectNo+"'");
							}else if("ApproveApply".equals(objectType)){
								sCustomerID = Sqlca.getString("select CustomerID from Business_Approve where SerialNo='"+objectNo+"'");
							}else if("ElectronContract".equals(objectType)){
								sCustomerID = Sqlca.getString("select CustomerID from Electron_Contract where SerialNo='"+objectNo+"'");
							}else if("GuarantyContract".equals(objectType)){
								sCustomerID = Sqlca.getString("select CustomerID from Guaranty_Contract where SerialNo='"+objectNo+"'");
							}else if("PutOutApply".equals(objectType)){
								sCustomerID = Sqlca.getString("select CustomerID from Business_PutOut where SerialNo='"+objectNo+"'");
							}else if("AfterLoan".equals(objectType)){
								sCustomerID = Sqlca.getString("select ObjectNo from Inspect_Info where ObjectType='Customer' and SerialNo='"+objectNo+"'");
							}
							sSql = "insert into ECM_PAGE_NEW (ObjectType,ObjectNo,TypeNo,CustomerID,DocumentID,BeginTime,EndTime,ModifyTime,OperateUser,OperateOrg,UploadPhase,PhaseNo,BranchMenu) values(:ObjectType,:ObjectNo,:TypeNo,:CustomerID,:DocumentID,:BeginTime,:EndTime,:ModifyTime,:OperateUser,:OperateOrg,:UploadPhase,:PhaseNo,:BranchMenu)";
							so = new SqlObject(sSql);
							so.setParameter("ObjectType", objectType).setParameter("ObjectNo", objectNo).setParameter("TypeNo", sTypeNo).setParameter("CustomerID", sCustomerID).setParameter("DocumentID", preTempStr).setParameter("BeginTime",sModifyTime).setParameter("EndTime","").setParameter("ModifyTime", sModifyTime).setParameter("OperateUser", sOperateUser).setParameter("OperateOrg", sOperateOrg).setParameter("UploadPhase", objectType).setParameter("PhaseNo", "AfterLoan").setParameter("BranchMenu", sBranchMenu);
							Sqlca.executeSQL(so);
						}
						sSql1 = "insert into ECM_PAGE_FILE (SerialNo,TypeNo,CustomerID,DocumentID,FileName,BeginTime,EndTime,ModifyTime,OperateUser,OperateOrg,UploadPhase,BranchMenu) values(:SerialNo,:TypeNo,:CustomerID,:DocumentID,:FileName,:BeginTime,:EndTime,:ModifyTime,:OperateUser,:OperateOrg,:UploadPhase,:BranchMenu)";
						so1 = new SqlObject(sSql1);
						so1.setParameter("SerialNo", sSerialNo).setParameter("TypeNo", sTypeNo).setParameter("CustomerID", sCustomerID).setParameter("DocumentID", preTempStr).setParameter("FileName", lastTempStr).setParameter("BeginTime",sModifyTime).setParameter("EndTime","").setParameter("ModifyTime", sModifyTime).setParameter("OperateUser", sOperateUser).setParameter("OperateOrg", sOperateOrg).setParameter("UploadPhase", objectType).setParameter("BranchMenu", sBranchMenu);
						Sqlca.executeSQL(so1);
					
				}
				
			} catch (Exception e) {
				System.out.println("�ļ��ϴ�ʧ��");
	            e.printStackTrace();
				try {
					Sqlca.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
			}finally {
	            try {
					Sqlca.commit();
					Sqlca.disConnect();
				} catch (SQLException e) {
					e.printStackTrace();
				}
	        }
		}else{
			//������ȡ
			doGet(request, resp) ;
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(null, resp) ;
	}

	public File getFileUpload() {
		return fileUpload;
	}

	public void setFileUpload(File fileUpload) {
		this.fileUpload = fileUpload;
	}

	public String getImageContentType() {
		return imageContentType;
	}

	public void setImageContentType(String imageContentType) {
		this.imageContentType = imageContentType;
	}

	public String getImageFileName() {
		return imageFileName;
	}

	public void setImageFileName(String imageFileName) {
		this.imageFileName = imageFileName;
	}

	private void close(FileOutputStream fos, FileInputStream fis) {
        if (fis != null) {
            try {
                fis.close();
                fis=null;
            } catch (IOException e) {
                System.out.println("FileInputStream�ر�ʧ��");
                e.printStackTrace();
            }
        }
        if (fos != null) {
            try {
                fos.close();
                fis=null;
            } catch (IOException e) {
                System.out.println("FileOutputStream�ر�ʧ��");
                e.printStackTrace();
            }
        }
    }
	/**
	 * 	��ȡ�ļ�ȫ·��
	 * @param sDocNo
	 * @param sAttachmentNo
	 * @param sFileName
	 * @param sFileSavePath
	 * @param sFileNameType
	 * @return
	 * @throws Exception
	 */
	public static String getFullPath(String sDocNo, String sAttachmentNo, String sFileName, String sFileSavePath, String sFileNameType)throws Exception{
	    
		File dFile = null;
	    String sBasePath = sFileSavePath;		//als7c.xml�����ļ������õ��ϴ��ļ���·��

	    String sFullPath = sBasePath + "/" + FileNameHelper.getMidPath(sDocNo, sAttachmentNo)+"/"+sDocNo+"_"+sAttachmentNo+"_";
	    dFile = new File(sFullPath);
	    try {
	      if ((dFile.exists()) || (dFile.mkdirs())) {
	    	  
	        ARE.getLog().info("�������渽���ļ�·��[" + sFullPath + "]�����ɹ�2222����");
	      } else {
	    	  
	        ARE.getLog().trace("�������渽���ļ�·��[" + sFullPath + "]����ʧ�ܣ���");
	        throw new IOException("�������渽���ļ�·��[" + sFullPath + "]����ʧ�ܣ���");
	      }
	    } catch (SecurityException e) {
	      ARE.getLog().error(e.getMessage(), e);
	      throw new SecurityException("�������渽���ļ�����·��[" + sFullPath + "]�޷�����������Ŀ¼��дȨ�ޣ�");
	    }
	
	    String sFullName = sFullPath+"/"+ sFileName;
	    return sFullName;
  }
	
}
