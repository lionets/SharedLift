/**
 * 
 */
package com.amarsoft.webservice.proj.nh.approve;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;

/**
 * @author Administrator
 * �����б�����ˮ�� SerialNo
 */
public class OpinionSignCreditInfoHandler extends JSONHandlerWithSession{

	private String SerialNo = "";
	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub
		Connection conn = null;
		JSONObject response = new JSONObject();
		if (!request.containsKey("SerialNo"))
			throw new HandlerException("��Ҫ��ˮ�Ų���");
		else {
			SerialNo = request.get("SerialNo").toString();
		}
		String getBusinessInfo = " select SerialNo,"
				+ "RelativeType,RelativeNo,ObjectNo,"
				+ "CustomerID,CustomerName,"
				+ "BusinessType,getBusinessName(BusinessType) as BusinessTypeName,"
				+ "BusinessCurrency,"
				+ "BaseRateType,BaseRate,"
				+ "RateFloatType,RateFloat,"
				+ "BusinessRate,ExecuteYearRate,"
				+ "BusinessSum,"
				+ " TermMonth,"
				+ "CycleFlag,getItemName('YesNo',CycleFlag) as CycleFlagName,"
				+ "VouchType,getItemName('VouchType',VouchType) as VouchTypeName,"
				+ "CorpusPayMethod,getItemName('CorpusPayMethod2',CorpusPayMethod) as CorpusPayMethodName,"
				+ "getUserName(InputUserID) as InputUserName,"
				+ "getOrgName(InputOrgID) as InputOrgName,"
				+ "InputTime from flow_creditopinion where serialno=?";

		try{
			conn = ARE.getDBConnection("als");
			
			PreparedStatement psPreparedStatement = conn.prepareStatement(getBusinessInfo);
			psPreparedStatement.setString(1, SerialNo);
			ResultSet rSet = psPreparedStatement.executeQuery();
			if(rSet.next()){
				response.put("SerialNo", rSet.getString("SerialNo"));//��ˮ��
				response.put("ObjectNo", rSet.getString("ObjectNo"));//������
				response.put("CustomerName", rSet.getString("CustomerName"));//�ͻ�����
				response.put("BusinessTypeName", rSet.getString("BusinessTypeName"));//ҵ��Ʒ��
				response.put("BusinessSum", (new DecimalFormat("#0.00").format(rSet.getDouble("BusinessSum"))));//���
				response.put("TermMonth", rSet.getInt("TermMonth")+"");//����
				response.put("BaseRate", (new DecimalFormat("#0.00").format(rSet.getDouble("BaseRate"))));//��׼����
				response.put("RateFloat", (new DecimalFormat("#0.00").format(rSet.getDouble("RateFloat"))));//���ʸ���ֵ
				response.put("ExecuteYearRate", (new DecimalFormat("#0.00").format(rSet.getDouble("ExecuteYearRate"))));//ִ��������
				response.put("BusinessRate", (new DecimalFormat("#0.00").format(rSet.getDouble("BusinessRate"))));//ִ������
				response.put("CorpusPayMethodName", rSet.getString("CorpusPayMethodName"));//���ʽ
				response.put("VouchTypeName", rSet.getString("VouchType"));//��Ҫ������ʽcode
				response.put("VouchTypeName2", rSet.getString("VouchTypeName"));//��Ҫ������ʽcodename
				response.put("CycleFlagName", rSet.getString("CycleFlagName"));//�Ƿ��ѭ��
				response.put("InputUserName", rSet.getString("InputUserName"));//�Ǽ���
				response.put("InputOrgName", rSet.getString("InputOrgName"));//�Ǽǻ���
				response.put("InputTime", rSet.getString("InputTime"));//�Ǽ�ʱ��
			}
			rSet.getStatement().close();
			
			JSONArray resultPay = getSql("CorpusPayMethod2", conn);//���ʽ
			//add 20140527
//			JSONArray resultVouchType = getSql("VouchType", conn);//��Ҫ������ʽ
			JSONArray resultCycleFlag = getSql("YesNo", conn);//�Ƿ�ѭ��
			
			response.put("ArrayCycleFlagName", resultCycleFlag);//�Ƿ�ѭ��
//			response.put("ArrayVouchTypeName", resultVouchType);//��Ҫ������ʽ
			response.put("ArrayCorpusPayMethodName", resultPay);//���ʽ
			
		} catch (Exception e) {
			// TODO: handle exception
			ARE.getLog().error(e.getMessage());
			e.printStackTrace();
			throw new HandlerException(e.getMessage());
		} finally {
			try {
				conn.commit();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				ARE.getLog().error("���ݿ�ر�ʧ��:" + e.getMessage());
				e.printStackTrace();
			}
		}
		return response;
	}
	
	//��ȡ�����ֵ�����
		private static JSONArray getSql(String codeno,Connection conn) throws Exception{
			String sSql = "select itemno,itemname from code_library where codeno='"+codeno+"' and IsInuse = '1'";
			PreparedStatement psCode = conn.prepareStatement(sSql);
			ARE.getLog().info(sSql);
			ResultSet rsCode = psCode.executeQuery();
			JSONArray result = new JSONArray();		
			while(rsCode.next()){
				JSONObject obj = new JSONObject();
				obj.put("CodeNo", rsCode.getString("itemno"));
				obj.put("CodeName", rsCode.getString("itemname"));
				result.add(obj);
			}
			rsCode.getStatement().close();
			return result;
		}

}
