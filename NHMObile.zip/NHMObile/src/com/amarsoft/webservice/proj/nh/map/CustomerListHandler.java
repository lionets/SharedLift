package com.amarsoft.webservice.proj.nh.map;

import java.sql.Connection;
import java.util.Properties;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.business.DBHandler;
/**
 * �ͻ��б�
 * ���������

 * ���������

 * @author 
 *
 */

public class CustomerListHandler extends DBHandler {
	protected Object createReponseWithDB(JSONObject request, Properties arg1,
			Connection conn) {
		return null;
	}

}
