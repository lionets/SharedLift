package com.amarsoft.webservice.proj.nh.afterloan;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.amarsoft.are.ARE;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.json.JSONArray;
import com.amarsoft.awe.util.json.JSONObject;
import com.amarsoft.mobile.webservice.ServiceFactory;
import com.amarsoft.mobile.webservice.business.HandlerException;
import com.amarsoft.mobile.webservice.business.JSONHandlerWithSession;
import com.amarsoft.mobile.webservice.security.Base64;
import com.amarsoft.mobile.webservice.session.SessionManager;
import com.amarsoft.mobile.webservice.sql.Pageable;

public class CheckDetailHandler extends JSONHandlerWithSession {
	private String sCustomerType = "01";
	private String sCustomerNo = "";
	private String sOrgID = "";
	private StringBuffer certifyInfo=new StringBuffer("");
	private StringBuffer riskInfo=new StringBuffer("");

	@Override
	public JSONObject createResponse(JSONObject request, Properties arg1)
			throws HandlerException {
		// TODO Auto-generated method stub

		Connection conn = null;
		JSONObject response = new JSONObject();

		String customerName = request.get("CustomerName").toString();
		String serialNo = request.get("SerialNo").toString();
	//	String BStatus = request.get("BStatus").toString();

		String sql = "select ObjectType,ObjectNo,INSPECTDATE,InputUserID,InputDate,SerialNo,UpdateDate,remark, "
				+ "UpToDate,StepType,InputOrgID,Opinion1 from INSPECT_INFO where SerialNo=?";

		String sSqlPhoto = "select PI.photodesc as PhotoDes,PI.PhotoPath as PhotoPath"
				+ " from photo_info PI "
				+ " WHERE PI.ObjectNo =? and PI.ObjectType = 'Afterloan' and PI.BizType = 'Afterloan' ";
		//add ldfang
		String day = StringFunction.getToday();
		String day10 = StringFunction.getRelativeDate(day, 10);
		String sUserId = SessionManager.getUserId(this.getSessionKey());//�û���
		String sgetorg = " select belongorg from user_info where userid =?";//������
		String sLicense = " select count(*) as cnt from CUSTOMER_BELONG CB,ENT_INFO EI, CUSTOMER_INFO CI where  CB.CustomerID=EI.CustomerID  and  CB.CustomerID=CI.CustomerID and cb.BELONGATTRIBUTE2 = '1' "
				+ " and CI.customerid=? and cb.UserID =? and CB.INPUTORGID=? and    LICENSEMATURITY<= ? and LICENSEMATURITY >= to_char(current_date,'yyyy/MM/dd')";
		String sOrgNo = "select count(*) as cnt from CUSTOMER_BELONG CB,ENT_INFO EI, CUSTOMER_INFO CI where  CB.CustomerID=EI.CustomerID  and  CB.CustomerID=CI.CustomerID and CI.certType='Ent01'  and cb.BELONGATTRIBUTE2 = '1' and CI.CUSTOMERID = ? and cb.UserID =? and CB.INPUTORGID=? and  corpmaturitydate<=? and corpmaturitydate >= to_char(current_date,'yyyy/MM/dd')";
		String sTrust = "select count(*) as cnt from CUSTOMER_BELONG CB,ENT_INFO EI, CUSTOMER_INFO CI where  CB.CustomerID=EI.CustomerID  and  CB.CustomerID=CI.CustomerID and CI.CUSTOMERID =? AND cb.BELONGATTRIBUTE2 = '1' and cb.UserID =? and CB.INPUTORGID=? and  CreditCodeMaturityDate<=? and CreditCodeMaturityDate >= to_char(current_date,'yyyy/MM/dd')";
		String sHouse = " select count(*) as cnt from  CUSTOMER_BELONG CB, CUSTOMER_INFO CI,ENT_REALTYAUTH ER where  CB.CustomerID=CI.CustomerID  and ER.CUSTOMERID=CI.CUSTOMERID and "+
                        " cb.BELONGATTRIBUTE2 = '1'  and ER.CorpMaturityDate >= to_char(current_date,'yyyy/MM/dd')  and  ER.CorpMaturityDate<=?"+
                        " and cb.UserID =? and CB.INPUTORGID=? and CI.CUSTOMERID=?";
		String sTrade = " select count(*) as cnt from  CUSTOMER_BELONG CB, CUSTOMER_INFO CI,ENT_ENTRANCEAUTH EE where  CB.CustomerID=CI.CustomerID  and EE.CUSTOMERID=CI.CUSTOMERID and "+
						" cb.BELONGATTRIBUTE2 = '1'  and EE.CorpMaturityDate >= to_char(current_date,'yyyy/MM/dd')  and  EE.CorpMaturityDate<=? "+
						" and cb.UserID =? and CB.INPUTORGID=? And CI.CUSTOMERID =?";
		String sTexuWork = "select count(*) as cnt from  CUSTOMER_BELONG CB, CUSTOMER_INFO CI,ENT_AUTH EA where  CB.CustomerID=CI.CustomerID  and EA.CUSTOMERID=CI.CUSTOMERID and"+ 
						" cb.BELONGATTRIBUTE2 = '1'  and EA.CorpMaturityDate >= to_char(current_date,'yyyy/MM/dd')  and  EA.CorpMaturityDate<=?"+
						" and cb.UserID =? and CB.INPUTORGID=? and CI.CUSTOMERID=?";
		String sAbout = " select count(*) as cnt from  CUSTOMER_BELONG CB, CUSTOMER_INFO CI,ENT_AUTH EA where  CB.CustomerID=CI.CustomerID  and EA.CUSTOMERID=CI.CUSTOMERID and"+ 
						" cb.BELONGATTRIBUTE2 = '1'  and EA.Validdate >= to_char(current_date,'yyyy/MM/dd')  and  EA.Validdate<=?"+
						" and cb.UserID =? and CB.INPUTORGID=? and CI.CUSTOMERID=?";
		
		String sYujing = " select RISK_ANALYSE.RISKINFO as RISKINFO From RISK_ANALYSE,FLOW_OBJECT Where FLOW_OBJECT.OBJECTNO=RISK_ANALYSE.SERIALNO  and FLOW_OBJECT.ObjectType =  'RiskAnalyseApply' and FLOW_OBJECT.PhaseType='1030'  and FLOW_OBJECT.ApplyType='RiskAnalyseApply'  and FLOW_OBJECT.UserID=? and RISK_ANALYSE.CUSTOMERID=?";
		//end
		try {
			JSONArray result = new JSONArray();
			conn = ARE.getDBConnection("als");

			System.out.println("before-----");
			Pageable.setDBType("db2");

			//if(BStatus.equals("01")){
				ARE.getLog().info(sql);

				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, serialNo);

				ResultSet rs = ps.executeQuery();

				if (rs.next()) {
					response.put("CustomerNums", rs.getString("ObjectNo"));
					response.put("CheckDate", rs.getString("INSPECTDATE"));
					response.put("CheckNums", rs.getString("SerialNo"));
					response.put("CheckTime", rs.getString("Opinion1"));
					response.put("CustomerName", customerName);
					response.put("CustomerId", rs.getString("ObjectNo"));
					response.put("CheckDes", rs.getString("remark"));
					response.put("StepType", rs.getString("StepType"));//add
					sCustomerNo = rs.getString("ObjectNo");//add by ldfang

				}

				rs.getStatement().close();

				// ��Ƭ��Ϣ
				PreparedStatement psPhoto = conn.prepareStatement(sSqlPhoto);
				psPhoto.setString(1, serialNo);
				ResultSet rsPhoto = psPhoto.executeQuery();
				ARE.getLog().info(sSqlPhoto+"ccccccccc "+serialNo);
				String sPhotoRootPath = ServiceFactory.getFactory()
						.getUploadRootPath();// ��·��
				String sReturnPhotoData = "";
				String sPhotoDes = "";
				while (rsPhoto.next()) {
					String sPhotoPath = rsPhoto.getString("PhotoPath");// ���·��
					sPhotoDes = rsPhoto.getString("PhotoDes");
					sPhotoPath = sPhotoRootPath + sPhotoPath;// ����·��
					ARE.getLog().info(sPhotoPath);
					FileInputStream fis = new FileInputStream(sPhotoPath);// sPhotpPath��ͼƬ����·��
					byte[] bPhotoData = getBytes(fis);// ��ȡȡ�ļ�ת���ɶ�����
					fis.close();
					// �����ƾ���base64���뽫������ת�����ַ���
					String sReturnPhotoData1 = Base64.encode(bPhotoData);

					sReturnPhotoData = sReturnPhotoData + sReturnPhotoData1 + ",";
				}
				rsPhoto.getStatement().close();

				ARE.getLog().info(sPhotoDes);
				response.put("PhotoData", sReturnPhotoData);// ��Ƭ����
				response.put("PhotoDes", sPhotoDes);// ��Ƭ����



				PreparedStatement psorg = conn.prepareStatement(sgetorg);
				psorg.setString(1, sUserId);

				ResultSet rsorg = psorg.executeQuery();

				if (rsorg.next()) {
					sOrgID=rsorg.getString("belongorg");
				}

				rsorg.getStatement().close();
				//֤������
				//Ӫҵִ��
				PreparedStatement psLicense = conn.prepareStatement(sLicense);
				psLicense.setString(1, sCustomerNo);
				psLicense.setString(2, sUserId);
				psLicense.setString(3, sOrgID);
				psLicense.setString(4, day10);
				ARE.getLog().info(sLicense);
				ResultSet rsLicense = psLicense.executeQuery();
				while(rsLicense.next()) {
					JSONObject obj = new JSONObject();
					if(rsLicense.getInt("cnt")!=0){

					   certifyInfo.append("Ӫҵִ��10���ڵ���").append(";");

					}
				}
				rsLicense.getStatement().close();
				
				//��֯��������
				PreparedStatement psOrgNo = conn.prepareStatement(sOrgNo);
				psOrgNo.setString(1, sCustomerNo);
				psOrgNo.setString(2, sUserId);
				psOrgNo.setString(3, sOrgID);
				psOrgNo.setString(4, day10);
				ARE.getLog().info(sOrgNo);
				ResultSet rsOrgNo = psOrgNo.executeQuery();
				while(rsOrgNo.next()) {
					JSONObject obj = new JSONObject();
					if(rsOrgNo.getInt("cnt")!=0){
					   certifyInfo.append("��֯�ṹ����֤10���ڵ���").append(";");
							}
				}
				rsOrgNo.getStatement().close();
				
				//�������ô���֤
				PreparedStatement psTrust = conn.prepareStatement(sTrust);
				psTrust.setString(1, sCustomerNo);
				psTrust.setString(2, sUserId);
				psTrust.setString(3, sOrgID);
				psTrust.setString(4, day10);
				ARE.getLog().info(sTrust);
				ResultSet rsTrust = psTrust.executeQuery();
				while(rsTrust.next()) {
				
					if(rsTrust.getInt("cnt")!=0){
					 
					   certifyInfo.append("�������ô���֤10���ڵ���;").append(";");
				
					}
				}
				rsTrust.getStatement().close();
				
				//���ز�����֤��
				PreparedStatement psHouse = conn.prepareStatement(sHouse);
				psHouse.setString(1, day10);
				psHouse.setString(2, sUserId);
				psHouse.setString(3, sOrgID);
				psHouse.setString(4, sCustomerNo);
				ARE.getLog().info(sHouse);
				ResultSet rsHouse = psHouse.executeQuery();
				while(rsHouse.next()) {
					
					if(rsHouse.getInt("cnt")!=0){
					  
					   
					   certifyInfo.append("���ز�����֤��10���ڵ���").append(";");
					
					}
				}
				rsHouse.getStatement().close();
				
				//������ó��֤��
				PreparedStatement psTrade = conn.prepareStatement(sTrade);
				psTrade.setString(1, day10);
				psTrade.setString(2, sUserId);
				psTrade.setString(3, sOrgID);
				psTrade.setString(4, sCustomerNo);
				ARE.getLog().info(sTrade);
				ResultSet rsTrade = psTrade.executeQuery();
				while(rsTrade.next()) {
				
					if(rsTrade.getInt("cnt")!=0){
					  
					   certifyInfo.append("������ó��֤��10���ڵ���").append(";");
					  // result.add(obj);
					}
				}
				rsTrade.getStatement().close();
				
				//������ҵ��Ӫ֤��
				PreparedStatement pstexu = conn.prepareStatement(sTexuWork);
				pstexu.setString(1, day10);
				pstexu.setString(2, sUserId);
				pstexu.setString(3, sOrgID);
				pstexu.setString(4, sCustomerNo);
				ARE.getLog().info(sTexuWork);
				ResultSet rsTexu = pstexu.executeQuery();
				while(rsTexu.next()) {
					
					if(rsTexu.getInt("cnt")!=0){
					  // obj.put("detail", "������ҵ��Ӫ֤��10���ڵ���");
					   certifyInfo.append("������ҵ��Ӫ֤��10���ڵ���").append(";");
					  // result.add(obj);
					}
				}
				rsTexu.getStatement().close();
				
				//�����֤��Ϣ
				PreparedStatement psabout = conn.prepareStatement(sAbout);
				psabout.setString(1, day10);
				psabout.setString(2, sUserId);
				psabout.setString(3, sOrgID);
				psabout.setString(4, sCustomerNo);
				ARE.getLog().info(sAbout);
				ResultSet rsabout = psabout.executeQuery();
				while(rsabout.next()) {
				
					if(rsabout.getInt("cnt")!=0){
					  // obj.put("detail", "�����֤��Ϣ10���ڵ���");
					   certifyInfo.append("�����֤��Ϣ10���ڵ���");
					   //result.add(obj);
					}
				}
				rsabout.getStatement().close();
			
				response.put("Cert", certifyInfo.toString());
	
			 

				//Ԥ����Ϣ
				PreparedStatement psrisk = conn.prepareStatement(sYujing);
				psrisk.setString(1, sUserId);
				psrisk.setString(2, sCustomerNo);
				ARE.getLog().info(sYujing);
				ResultSet rsrisk = psrisk.executeQuery();
				JSONArray resultrisk = new JSONArray();
				while(rsrisk.next()) {
			
					riskInfo.append(rsrisk.getString("RISKINFO")).append(";");

				}
				rsrisk.getStatement().close();
			
	
				response.put("risk", riskInfo.toString());
	
		} catch (Exception e) {
			ARE.getLog().error(e.getMessage());

			throw new HandlerException(e.getMessage());
		} finally {

			if (conn != null)
				try {
					conn.commit();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return response;

	}

	// add 20140312
	public static byte[] getBytes(InputStream is) throws IOException {
		ByteArrayOutputStream ois = new ByteArrayOutputStream();
		byte[] buffer = new byte[10240];
		int b = is.read(buffer);
		while (b > -1) {
			ois.write(buffer, 0, b);
			b = is.read(buffer);
		}
		return ois.toByteArray();
	}

}
