package com.amarsoft.biz.workflow;

import com.amarsoft.amarscript.Any;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.ASResultSet;
import com.amarsoft.awe.util.DBKeyHelp;
import com.amarsoft.awe.util.SqlObject;
import com.amarsoft.awe.util.Transaction;
import com.amarsoft.context.ASUser;
import java.io.PrintStream;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class FlowTask
{
  public String SerialNo;
  public String RelativeSerialNo;
  public String ObjectType;
  public String ObjectNo;
  public String FlowNo;
  public String PhaseNo;
  public String PhaseType;
  public String ApplyType;
  public String UserID;
  public String OrgID;
  public String BeginTime;
  public String EndTime;
  public String PhaseAction;
  public String FlowName;
  public String UserName;
  public String OrgName;
  public String PhaseName;
  public String PhaseChoice;
  public String PhaseOpinion;
  public String PhaseOpinion1;
  public String PhaseOpinion2;
  public String PhaseOpinion3;
  public String PhaseOpinion4;
  public String ForkState;
  public String Version;
  public FlowPhase RelativeFlowPhase;
  public FlowObject RelativeFlowObject;
  Transaction Sqlca;

  public FlowTask(String sSerialNo, Transaction transSql)
    throws Exception
  {
    this.SerialNo = sSerialNo;
    this.Sqlca = transSql;

    ASResultSet rsFlowTask = this.Sqlca.getASResultSet("select FLOW_TASK.* from FLOW_TASK where SerialNo='" + sSerialNo + "'");
    if (rsFlowTask.next()) {
      this.RelativeSerialNo = (rsFlowTask.getString("RelativeSerialNo") == null ? "" : rsFlowTask.getString("RelativeSerialNo"));
      this.ObjectType = (rsFlowTask.getString("ObjectType") == null ? "" : rsFlowTask.getString("ObjectType"));
      this.ObjectNo = (rsFlowTask.getString("ObjectNo") == null ? "" : rsFlowTask.getString("ObjectNo"));
      this.FlowNo = (rsFlowTask.getString("FlowNo") == null ? "" : rsFlowTask.getString("FlowNo"));
      this.FlowName = (rsFlowTask.getString("FlowName") == null ? "" : rsFlowTask.getString("FlowName"));
      this.PhaseNo = (rsFlowTask.getString("PhaseNo") == null ? "" : rsFlowTask.getString("PhaseNo"));
      this.PhaseName = (rsFlowTask.getString("PhaseName") == null ? "" : rsFlowTask.getString("PhaseName"));
      this.PhaseType = (rsFlowTask.getString("PhaseType") == null ? "" : rsFlowTask.getString("PhaseType"));
      this.ApplyType = (rsFlowTask.getString("ApplyType") == null ? "" : rsFlowTask.getString("ApplyType"));
      this.UserID = (rsFlowTask.getString("UserID") == null ? "" : rsFlowTask.getString("UserID"));
      this.UserName = (rsFlowTask.getString("UserName") == null ? "" : rsFlowTask.getString("UserName"));
      this.OrgID = (rsFlowTask.getString("OrgID") == null ? "" : rsFlowTask.getString("OrgID"));
      this.OrgName = (rsFlowTask.getString("OrgName") == null ? "" : rsFlowTask.getString("OrgName"));
      this.BeginTime = (rsFlowTask.getString("BeginTime") == null ? "" : rsFlowTask.getString("BeginTime"));
      this.EndTime = (rsFlowTask.getString("EndTime") == null ? "" : rsFlowTask.getString("EndTime"));
      this.PhaseChoice = (rsFlowTask.getString("PhaseChoice") == null ? "" : rsFlowTask.getString("PhaseChoice"));
      this.PhaseAction = (rsFlowTask.getString("PhaseAction") == null ? "" : rsFlowTask.getString("PhaseAction"));
      this.PhaseOpinion = (rsFlowTask.getString("PhaseOpinion") == null ? "" : rsFlowTask.getString("PhaseOpinion"));
      this.PhaseOpinion1 = (rsFlowTask.getString("PhaseOpinion1") == null ? "" : rsFlowTask.getString("PhaseOpinion1"));
      this.PhaseOpinion2 = (rsFlowTask.getString("PhaseOpinion2") == null ? "" : rsFlowTask.getString("PhaseOpinion2"));
      this.PhaseOpinion3 = (rsFlowTask.getString("PhaseOpinion3") == null ? "" : rsFlowTask.getString("PhaseOpinion3"));
      this.PhaseOpinion4 = (rsFlowTask.getString("PhaseOpinion4") == null ? "" : rsFlowTask.getString("PhaseOpinion4"));
      this.ForkState = (rsFlowTask.getString("ForkState") == null ? "" : rsFlowTask.getString("ForkState"));
      this.Version = (rsFlowTask.getString("Version") == null ? "" : rsFlowTask.getString("Version"));
    } else {
      rsFlowTask.getStatement().close();
      throw new FlowException("�������������׶���ˮ��:'" + sSerialNo + "' �����ڣ�");
    }
    rsFlowTask.getStatement().close();

    this.RelativeFlowPhase = new FlowPhase(this.FlowNo, this.PhaseNo, this.Sqlca);

    this.RelativeFlowObject = new FlowObject(this.ObjectType, this.ObjectNo, this.Sqlca);
  }

  public static void initFlow(String sObjectType, String sObjectNo, String sFlowNo, String sApplyType, String sPhaseNo, String sUserID, String sOrgID, Transaction transSql)
    throws Exception
  {
    String sSql = " select UserName from USER_INFO where UserID = '" + sUserID + "' ";
    String sUserName = transSql.getString(sSql);

    sSql = " select OrgName from ORG_INFO where OrgID = '" + sOrgID + "' ";
    String sOrgName = transSql.getString(sSql);

    sSql = " select FlowName from FLOW_CATALOG where FlowNo = '" + sFlowNo + "' and IsInUse = '1'";
    String sFlowName = transSql.getString(sSql);

    sSql = " select Version from FLOW_CATALOG where FlowNo = '" + sFlowNo + "' and IsInUse = '1'";
    String sVersion = transSql.getString(sSql);

    if (("".equals(sPhaseNo)) || (sPhaseNo == null))
    {
      sSql = "select InitPhase from FLOW_CATALOG where FlowNo = '" + sFlowNo + "'";
      sPhaseNo = transSql.getString(sSql);

      if ((sPhaseNo == null) || (sPhaseNo.trim().equals(""))) {
        throw new Exception("��������" + sFlowNo + "û�г�ʼ���׶α�ţ�");
      }
    }

    sSql = " select PhaseName,PhaseType from FLOW_MODEL where FlowNo = '" + sFlowNo + "' and PhaseNo = '" + sPhaseNo + "' and Version = '" + sVersion + "'";
    ASResultSet rs = transSql.getASResultSet(sSql);
    String sPhaseName = ""; String sPhaseType = "";
    if (rs.next())
    {
      sPhaseName = rs.getString("PhaseName");
      sPhaseType = rs.getString("PhaseType");

      if (sPhaseName == null) sPhaseName = "";
      if (sPhaseType == null) sPhaseType = "";

    }

    String sBeginTime = StringFunction.getTodayNow();

    String foSql = " Insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,PhaseNo,  PhaseName,OrgID,OrgName,UserID,UserName,InputDate,Version)  values ('" + sObjectType + "','" + sObjectNo + "','" + sPhaseType + "','" + sApplyType + "','" + sFlowNo + "', " + " '" + sFlowName + "','" + sPhaseNo + "','" + sPhaseName + "','" + sOrgID + "','" + sOrgName + "','" + sUserID + "', " + " '" + sUserName + "','" + StringFunction.getToday() + "','" + sVersion + "')";

    String sSerialNo = DBKeyHelp.getSerialNo("FLOW_TASK", "SerialNo", transSql);
    String ftSql = " insert into FLOW_TASK(SerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,UserID,UserName,OrgName,BegInTime,Version)  values ('" + sSerialNo + "','" + sObjectType + "','" + sObjectNo + "','" + sPhaseType + "','" + sApplyType + "', " + " '" + sFlowNo + "','" + sFlowName + "','" + sPhaseNo + "','" + sPhaseName + "','" + sOrgID + "','" + sUserID + "', " + " '" + sUserName + "','" + sOrgName + "','" + sBeginTime + "','" + sVersion + "')";

    transSql.executeSQL(foSql);
    transSql.executeSQL(ftSql);
  }

  public FlowPhase commitAction(String sPhaseAction)
    throws Exception
  {
    String sEndTime = StringFunction.getTodayNow();
    FlowPhase fpNext;
    if (!this.RelativeFlowPhase.equals(this.RelativeFlowObject.RelativeFlowPhase)) {
      finish(sEndTime, sPhaseAction);
      fpNext = this.RelativeFlowObject.RelativeFlowPhase;
    }
    else {
      fpNext = getNextFlowPhase(sPhaseAction);

      if ((fpNext != null) && (!fpNext.PhaseNo.equals(""))) {
        if (this.RelativeFlowPhase.equals(fpNext)) {
          finish(sEndTime, sPhaseAction);
        } else {
          finish(sEndTime, sPhaseAction);
          this.RelativeFlowObject.changePhase(fpNext, this, "");
        }
      }
    }
    return fpNext;
  }

  public String getJoinCondition(FlowTask flowTask, FlowPhase curFlowPhase, FlowPhase nextFlowPhase)
    throws Exception
  {
    Integer mNum = Integer.valueOf(0);

    String sSql = "select count(*) from FLOW_MODEL where FlowNo=:FlowNo and PostScript=:PostScript";
    SqlObject so = new SqlObject(sSql);
    so.setParameter("FlowNo", this.FlowNo);
    so.setParameter("PostScript", curFlowPhase.PostScript);
    ASResultSet rsFlowModel = this.Sqlca.getASResultSet(so);
    if (rsFlowModel.next()) {
      mNum = Integer.valueOf(rsFlowModel.getInt(1));
    }
    rsFlowModel.getStatement().close();

    Integer tNum = Integer.valueOf(0);
    sSql = "select count(*) from FLOW_TASK where ObjectNo='" + this.ObjectNo + "' and ObjectType='" + this.ObjectType + "'and PhaseNo='" + nextFlowPhase.PhaseNo + "' and (Endtime is null or EndTime='')";
    ASResultSet rsFlowTask = this.Sqlca.getASResultSet(sSql);
    if (rsFlowTask.next()) {
      tNum = Integer.valueOf(rsFlowTask.getInt(1));
    }
    rsFlowTask.getStatement().close();

    if (mNum.intValue() - 1 == tNum.intValue()) {
      return "JOIN";
    }
    return "WAIT";
  }

  public boolean haveBackTask()
    throws SQLException
  {
    Integer count = Integer.valueOf(0);
    String sSql = "select count(*) from FLOW_TASK where (EndTime='' or EndTime is null) and ForkState=:ForkState and SerialNo <> :SerialNo and ObjectNo=:ObjectNo and ObjectType=:ObjectType";

    SqlObject so = new SqlObject(sSql);
    so.setParameter("ForkState", "BACK");
    so.setParameter("SerialNo", this.SerialNo);
    so.setParameter("ObjectNo", this.ObjectNo);
    so.setParameter("ObjectType", this.ObjectType);
    ASResultSet rs = this.Sqlca.getASResultSet(so);
    if (rs.next()) {
      count = Integer.valueOf(rs.getInt(1));
    }
    rs.getStatement().close();
    if (count.intValue() > 0) {
      return true;
    }
    return false;
  }

  public String[][] getHistoryTask()
    throws Exception
  {
    List historyObject = new ArrayList();
    List modelRoute = new ArrayList();

    String sSql = "select * from FLOW_TASK where ObjectNo=:ObjectNo and ObjectType=:ObjectType order by SerialNo";
    SqlObject so = new SqlObject(sSql);
    so.setParameter("ObjectNo", this.ObjectNo);
    so.setParameter("ObjectType", this.ObjectType);
    so.setParameter("SerialNo", this.SerialNo);
    String[][] Array = this.Sqlca.getStringMatrix(so);
    int count = Array.length;
    ASResultSet rs = this.Sqlca.getASResultSet(so);

    int size = 0;
    while ((rs.next()) && (size == 0))
    {
      if (rs.getString("phaseNo").equals(this.PhaseNo)) {
        size = historyObject.size();
        break;
      }
      HistoryObject ho = new HistoryObject();
      ho.setSerialNo(rs.getString("SerialNo"));
      ho.setRelativeSerialNo(rs.getString("relativeSerialNo"));
      ho.setPhaseNo(rs.getString("phaseNo"));
      ho.setPhaseName(rs.getString("phaseName"));
      ho.setUserName(rs.getString("userName"));
      historyObject.add(ho);
    }
    System.out.println(historyObject);
    rs.getStatement().close();

    for (int j = 0; j < historyObject.size(); j++) {
      String pn = ((HistoryObject)historyObject.get(j)).getPhaseNo();
      for (int k = j + 1; k < historyObject.size(); k++) {
        if (pn.equals(((HistoryObject)historyObject.get(k)).getPhaseNo())) {
          historyObject.remove(k);
        }
      }
    }

    String[][] HistroyTask = new String[historyObject.size()][2];
    for (int i = 0; i < historyObject.size(); i++) {
      HistoryObject ho = (HistoryObject)historyObject.get(i);
      HistroyTask[i][0] = (ho.getPhaseName() + "-" + ho.getUserName());
      HistroyTask[i][1] = ho.getSerialNo();
    }
    return HistroyTask;
  }

  public void returnTask(String sSerialNo, Transaction transSql) throws Exception {
    FlowTask rtFlowTask = new FlowTask(sSerialNo, transSql);
    String sEndTime = StringFunction.getTodayNow();
    finish(sEndTime, "", "");
    this.RelativeFlowObject.changePhase(rtFlowTask, this);
    deleteSamePhaseTask(this.ObjectType, this.ObjectNo, this.FlowNo, this.PhaseNo, this.UserID, this.Sqlca);
  }

  public FlowPhase[] commitAction(String sPhaseAction, String sPhaseOpinion1)
    throws Exception
  {
    String sEndTime = StringFunction.getTodayNow();

    FlowPhase[] workFlowPhase = null;

    workFlowPhase = getNextFlowPhase(sPhaseAction, sPhaseOpinion1);

    if (workFlowPhase.length == 1) {
      FlowPhase flowphase = workFlowPhase[0];

      if ("JOIN".equalsIgnoreCase(flowphase.PhaseDescribe)) {
        if ((flowphase != null) && (!flowphase.PhaseNo.equals(""))) {
          if (this.RelativeFlowPhase.equals(flowphase)) {
            finish(sEndTime, sPhaseAction, sPhaseOpinion1);
          } else {
            finish(sEndTime, sPhaseAction, sPhaseOpinion1);
            String JoinFlag = getJoinCondition(this, this.RelativeFlowPhase, flowphase);
            this.RelativeFlowObject.changePhase(flowphase, this, JoinFlag);
          }
        }
      }
      else if ((flowphase != null) && (!flowphase.PhaseNo.equals(""))) {
        if (this.RelativeFlowPhase.equals(flowphase)) {
          finish(sEndTime, sPhaseAction, sPhaseOpinion1);
        } else {
          finish(sEndTime, sPhaseAction, sPhaseOpinion1);

          if (("1".equals(this.ForkState)) && (!"".equals(sPhaseAction)) && (sPhaseAction != null)) {
            boolean haveBackTask = haveBackTask();
            if (haveBackTask == true) {
              throw new Exception("�����˻����񣬲������˻�");
            }
            this.RelativeFlowObject.changePhase(flowphase, this, "INFORK");
          }
          else if (("1".equals(this.ForkState)) && (("".equals(sPhaseAction)) || (sPhaseAction == null))) {
            boolean haveBackTask = haveBackTask();
            if (haveBackTask == true) {
              throw new Exception("�����˻����񣬲������˻�");
            }
            this.RelativeFlowObject.changePhase(flowphase, this, "BACK");
          }
          else if ("BACK".equals(this.ForkState)) {
            this.RelativeFlowObject.changePhase(flowphase, this, "INFORK");
          } else {
            this.RelativeFlowObject.changePhase(flowphase, this, "");
            deleteSamePhaseTask(this.ObjectType, this.ObjectNo, this.FlowNo, this.PhaseNo, this.UserID, this.Sqlca);
          }

        }

      }

    }
    else if ("FORK".equalsIgnoreCase(this.RelativeFlowPhase.PhaseDescribe)) {
      for (int i = 0; i < workFlowPhase.length; i++)
      {
        FlowPhase flowphase = workFlowPhase[i];
        if ((flowphase != null) && (!flowphase.PhaseNo.equals("")))
          if (this.RelativeFlowPhase.equals(flowphase)) {
            finish(sEndTime, sPhaseAction, sPhaseOpinion1);
          } else {
            finish(sEndTime, sPhaseAction, sPhaseOpinion1);
            this.RelativeFlowObject.changePhase(flowphase, this, "FORK");
          }
      }
    }
    else {
      for (int i = 0; i < workFlowPhase.length; i++)
      {
        FlowPhase flowphase = workFlowPhase[i];
        if ((flowphase != null) && (!flowphase.PhaseNo.equals(""))) {
          if (this.RelativeFlowPhase.equals(flowphase)) {
            finish(sEndTime, sPhaseAction, sPhaseOpinion1);
          } else {
            finish(sEndTime, sPhaseAction, sPhaseOpinion1);
            this.RelativeFlowObject.changePhase(flowphase, this, "");
          }
        }
      }

    }

    return workFlowPhase;
  }

  public FlowPhase getNextFlowPhase(String sPhaseAction)
    throws Exception
  {
    FlowPhase fpNext = null;
    String[][] sConstantList = getConstantList();

    StringFunction.setAttribute(sConstantList, "#PhaseAction", "'" + sPhaseAction + "'");

    String sNextFlowPhase = this.RelativeFlowPhase.executeScript("PostScript", sConstantList).toStringValue();

    if ((sNextFlowPhase != null) && (sNextFlowPhase.trim().length() > 0)) {
      sNextFlowPhase = sNextFlowPhase.trim();

      String sTips = StringFunction.getSeparate(sNextFlowPhase, " ", 2);
      sNextFlowPhase = StringFunction.getSeparate(sNextFlowPhase, " ", 1);
      String sNextFlowNo = StringFunction.getSeparate(sNextFlowPhase, ".", 1);
      String sNextPhaseNo = StringFunction.getSeparate(sNextFlowPhase, ".", 2);

      if (sNextFlowNo.equalsIgnoreCase("Null")) {
        sNextPhaseNo = "Null";
        fpNext = new FlowPhase(sNextFlowNo, sNextPhaseNo, sTips);
      } else {
        if (sNextPhaseNo.equals("")) {
          sNextPhaseNo = sNextFlowNo;
          sNextFlowNo = this.FlowNo;
        }
        fpNext = new FlowPhase(sNextFlowNo, sNextPhaseNo, sTips, this.Sqlca);
      }
    }
    return fpNext;
  }

  public FlowPhase[] getNextFlowPhase(String sPhaseAction, String sPhaseOpinion1)
    throws Exception
  {
    FlowPhase flowphase = null;
    FlowPhase[] workFlowPhase = null;
    String[][] sConstantList = getConstantList();

    StringFunction.setAttribute(sConstantList, "#PhaseAction", "'" + sPhaseAction + "'");

    StringFunction.setAttribute(sConstantList, "#PhaseOpinion1", "'" + sPhaseOpinion1 + "'");

    String sNextFlowPhase = this.RelativeFlowPhase.executeScript("PostScript", sConstantList).toStringValue();

    String[] NextFlowPhase = StringFunction.toStringArray(sNextFlowPhase, ";");
    workFlowPhase = new FlowPhase[NextFlowPhase.length];

    for (int i = 0; i < NextFlowPhase.length; i++)
    {
      sNextFlowPhase = NextFlowPhase[i];
      if ((sNextFlowPhase != null) && (sNextFlowPhase.trim().length() > 0)) {
        sNextFlowPhase = sNextFlowPhase.trim();
        String sTips = StringFunction.getSeparate(sNextFlowPhase, " ", 2);
        sNextFlowPhase = StringFunction.getSeparate(sNextFlowPhase, " ", 1);
        String sNextFlowNo = StringFunction.getSeparate(sNextFlowPhase, ".", 1);
        String sNextPhaseNo = StringFunction.getSeparate(sNextFlowPhase, ".", 2);
        if (sNextFlowNo.equalsIgnoreCase("Null")) {
          sNextPhaseNo = "Null";
          flowphase = new FlowPhase(sNextFlowNo, sNextPhaseNo, sTips);
        } else {
          if (sNextPhaseNo.equals("")) {
            sNextPhaseNo = sNextFlowNo;
            sNextFlowNo = this.FlowNo;
          }
          flowphase = new FlowPhase(sNextFlowNo, sNextPhaseNo, sTips, this.Sqlca);
          workFlowPhase[i] = flowphase;
        }
      }
    }
    return workFlowPhase;
  }

  public void finish(String sEndTime, String sPhaseAction) throws Exception
  {
    this.EndTime = sEndTime;
    this.PhaseAction = sPhaseAction;
    this.Sqlca.executeSQL("update FLOW_TASK set EndTime='" + sEndTime + "',PhaseAction='" + sPhaseAction + "' where SerialNo='" + this.SerialNo + "'");
  }

  private void finish(String sEndTime, String sPhaseAction, String sPhaseOpinion1)
    throws Exception
  {
    this.EndTime = sEndTime;
    this.PhaseAction = sPhaseAction;
    this.PhaseOpinion1 = sPhaseOpinion1;
    this.Sqlca.executeSQL("update FLOW_TASK set EndTime='" + sEndTime + "',PhaseAction='" + sPhaseAction + "',PhaseOpinion1='" + sPhaseOpinion1 + "'  where SerialNo='" + this.SerialNo + "'");
  }

  public ReturnMessage cancel(ASUser asuOperator)
    throws Exception
  {
    if ((this.EndTime != null) && (!this.EndTime.trim().equals(""))) return new ReturnMessage(-1, "���ύ���������˻�");

    if ((this.RelativeSerialNo == null) || (this.RelativeSerialNo.trim().equals(""))) {
      return new ReturnMessage(-2, "�޸��������˻�");
    }
    FlowTask ftParent = new FlowTask(this.RelativeSerialNo, this.Sqlca);
    if (ftParent.getChildTaskCount() > 1) {
      return new ReturnMessage(-3, "���׶λ��������а���,�����˻�");
    }

    FlowTask ft = new FlowTask(this.SerialNo, this.Sqlca);
    String phaseDescribe = ft.RelativeFlowPhase.PhaseDescribe;
    if ("join".equalsIgnoreCase(phaseDescribe))
    {
      return new ReturnMessage(-4, "���׶�Ϊ��֧�ۺϽ׶�,�����˻�");
    }
    boolean haveBackTask = haveBackTask();
    if (haveBackTask == true) {
      return new ReturnMessage(-5, "�������������֧�����˻ز��������У���ȴ�������ȫ���˻أ�");
    }
    ftParent.finish("", "", "");
    this.RelativeFlowObject.updatePhase(ftParent.RelativeFlowPhase);
    deleteTask(this.SerialNo, this.Sqlca);

    return new ReturnMessage(0, "�˻����");
  }

  private void forkRollBack()
    throws Exception
  {
    String sSql = "select SerialNo,RelativeSerialNo from FLOW_TASK where (EndTime=:EndTime or BeginTime=:BeginTime)and PhaseNo=:PhaseNo and ObjectNo=:ObjectNo and ObjectType=:ObjectType";

    SqlObject so = new SqlObject(sSql);
    so.setParameter("EndTime", this.BeginTime);
    so.setParameter("BeginTime", this.BeginTime);
    so.setParameter("PhaseNo", this.PhaseNo);
    so.setParameter("ObjectNo", this.ObjectNo);
    so.setParameter("ObjectType", this.ObjectType);
    String[][] Array = this.Sqlca.getStringMatrix(so);
    int count = Array.length;

    for (int i = 0; i < count; i++) {
      System.out.println(Array[i][0]);
      deleteTask(Array[i][0], this.Sqlca);
    }

    for (int i = 0; i < count; i++) {
      System.out.println(Array[i][1]);
      FlowTask ft = new FlowTask(Array[i][1], this.Sqlca);
      ft.finish("", "", "");
      this.RelativeFlowObject.updatePhase(ft.RelativeFlowPhase);
    }
  }

  public ReturnMessage takeBack(ASUser asuOperator)
    throws Exception
  {
    int iCount = 0;

    ASResultSet rsTemp = this.Sqlca.getASResultSet("select count(*) from FLOW_TASK where RelativeSerialNo = '" + this.SerialNo + "' " + " and ((EndTime is not null) or (PhaseChoice is not null) or (PhaseOpinion1 is not null) " + " or (PhaseOpinion2 is not null) or (PhaseOpinion3 is not null) or (UserID ='system'))");

    if (rsTemp.next()) iCount = rsTemp.getInt(1);
    rsTemp.getStatement().close();

    if (iCount > 0) {
      return new ReturnMessage(-1, "�½׶��������ύ����ǩ������������ջ�");
    }
    iCount = getChildTaskCount();

    this.Sqlca.executeSQL("delete from FLOW_TASK where RelativeSerialNo = '" + this.SerialNo + "'");
    finish("", "");
    this.RelativeFlowObject.updatePhase(this.RelativeFlowPhase);

    return new ReturnMessage(0, "�ջ����");
  }

  public int getChildTaskCount() throws Exception
  {
    int iCount = 0;
    ASResultSet rsTemp = this.Sqlca.getASResultSet("select count(*) from FLOW_TASK where RelativeSerialNo = '" + this.SerialNo + "'");
    if (rsTemp.next()) iCount = rsTemp.getInt(1);
    rsTemp.getStatement().close();

    return iCount;
  }

  public String getChoiceDescribe() throws Exception
  {
    return this.RelativeFlowPhase.executeScript("ChoiceDescribe", getConstantList()).toStringValue();
  }

  public String getActionDescribe() throws Exception
  {
    return this.RelativeFlowPhase.executeScript("ActionDescribe", getConstantList()).toStringValue();
  }

  public String[] getChoiceList() throws Exception
  {
    Any aChoiceList;
    try
    {
      aChoiceList = this.RelativeFlowPhase.executeScript("ChoiceScript", getConstantList());
    } catch (Exception ex) {
      throw new FlowException(ex.toString() + " ȡ����б�������");
    }
    if (aChoiceList == null) return null;
    String[] sReturn = aChoiceList.toStringArray();
    return sReturn;
  }

  public String[] getActionList() throws Exception
  {
    Any aActionList = null;
    String[] sActionList = null;
    aActionList = this.RelativeFlowPhase.executeScript("ActionScript", getConstantList());
    if (aActionList != null) sActionList = aActionList.toStringArray();
    return sActionList;
  }

  public String[] getActionList(String sPhaseOpinion1) throws Exception
  {
    String[][] sActionList = getConstantList();
    StringFunction.setAttribute(sActionList, "#PhaseOpinion1", "'" + sPhaseOpinion1 + "'");
    return this.RelativeFlowPhase.executeScript("ActionScript", sActionList).toStringArray();
  }

  public String[][] getConstantList() throws Exception
  {
    FlowTask ftLast = null;
    String[][] sConstantList = { { "#SerialNo", this.SerialNo }, { "#ObjectType", this.ObjectType }, { "#ObjectNo", this.ObjectNo }, { "#FlowNo", this.FlowNo }, { "#FlowName", this.FlowName }, { "#PhaseNo", this.PhaseNo }, { "#PhaseName", this.PhaseName }, { "#PhaseType", this.PhaseType }, { "#ApplyType", this.ApplyType }, { "#PhaseChoice", this.PhaseChoice }, { "#PhaseAction", this.PhaseAction }, { "#PhaseOpinion1", this.PhaseOpinion1 }, { "#BeginTime", this.BeginTime }, { "#EndTime", this.EndTime }, { "#UserID", this.UserID }, { "#UserName", this.UserName }, { "#OrgID", this.OrgID }, { "#OrgName", this.OrgName }, { "#LastFlowNo", "" }, { "#LastFlowName", "" }, { "#LastPhaseNo", "" }, { "#LastPhaseName", "" }, { "#LastPhaseType", "" }, { "#LastApplyType", "" }, { "#LastPhaseChoice", "" }, { "#LastPhaseAction", "" }, { "#LastBeginTime", "" }, { "#LastEndTime", "" }, { "#LastUserID", "" }, { "#LastUserName", "" }, { "#LastOrgID", "" }, { "#LastOrgName", "" } };

    if ((this.RelativeSerialNo != null) && (!this.RelativeSerialNo.equals(""))) {
      ftLast = new FlowTask(this.RelativeSerialNo, this.Sqlca);
      StringFunction.setAttribute(sConstantList, "#LastFlowNo", ftLast.FlowNo);
      StringFunction.setAttribute(sConstantList, "#LastFlowName", ftLast.FlowName);
      StringFunction.setAttribute(sConstantList, "#LastPhaseNo", ftLast.PhaseNo);
      StringFunction.setAttribute(sConstantList, "#LastPhaseName", ftLast.PhaseName);
      StringFunction.setAttribute(sConstantList, "#LastPhaseType", ftLast.PhaseType);
      StringFunction.setAttribute(sConstantList, "#LastApplyType", ftLast.ApplyType);
      StringFunction.setAttribute(sConstantList, "#LastPhaseChoice", ftLast.PhaseChoice);
      StringFunction.setAttribute(sConstantList, "#LastPhaseAction", ftLast.PhaseAction);
      StringFunction.setAttribute(sConstantList, "#LastBeginTime", ftLast.BeginTime);
      StringFunction.setAttribute(sConstantList, "#LastEndTime", ftLast.EndTime);
      StringFunction.setAttribute(sConstantList, "#LastUserID", ftLast.UserID);
      StringFunction.setAttribute(sConstantList, "#LastUserName", ftLast.UserName);
      StringFunction.setAttribute(sConstantList, "#LastOrgID", ftLast.OrgID);
      StringFunction.setAttribute(sConstantList, "#LastOrgName", ftLast.OrgName);
    }

    return sConstantList;
  }

  public static String newTask(String sRelativeSerialNo, String sObjectType, String sObjectNo, String sFlowNo, String sPhaseNo, String sApplyType, String sUserID, String sBeginTime, Transaction transSql, String fork, String sVersion)
    throws Exception
  {
    String sUserName = transSql.getString("select UserName from USER_INFO where UserID = '" + sUserID + "'");
    String sOrgID = transSql.getString("select BelongOrg from USER_INFO where UserID = '" + sUserID + "'");
    String sOrgName = transSql.getString("select OrgName from ORG_INFO where OrgID = '" + sOrgID + "'");

    FlowPhase fpTemp = new FlowPhase(sFlowNo, sPhaseNo, transSql);
    String sPhaseName = fpTemp.PhaseName;
    String sPhaseType = fpTemp.PhaseType;

    FlowCatalog fcTemp = new FlowCatalog(sFlowNo, transSql);
    String sFlowName = fcTemp.FlowName;

    if (sBeginTime == null) sBeginTime = StringFunction.getTodayNow();

    String sSerialNo = DBKeyHelp.getSerialNo("FLOW_TASK", "SerialNo", transSql);
    String sSql = "";
    if ("".equals(fork)) {
      sSql = "INSERT INTO FLOW_TASK(SerialNo,RelativeSerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,BeginTime,EndTime,UserID,UserName,OrgID,OrgName,Version)  VALUES ( '" + sSerialNo + "','" + sRelativeSerialNo + "','" + sObjectType + "','" + sObjectNo + "','" + sPhaseType + "','" + sApplyType + "','" + sFlowNo + "','" + sFlowName + "'," + " '" + sPhaseNo + "','" + sPhaseName + "','" + sBeginTime + "',null,'" + sUserID + "','" + sUserName + "','" + sOrgID + "','" + sOrgName + "','" + sVersion + "')";
    }
    else if ("WAIT".equals(fork)) {
      sSql = "INSERT INTO FLOW_TASK(SerialNo,RelativeSerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,BeginTime,EndTime,UserID,UserName,OrgID,OrgName,Version)  VALUES ( '" + sSerialNo + "','" + sRelativeSerialNo + "','" + sObjectType + "','" + sObjectNo + "','" + sPhaseType + "','" + sApplyType + "','" + sFlowNo + "','" + sFlowName + "'," + " '" + sPhaseNo + "','" + sPhaseName + "','" + sBeginTime + "',null,'*" + sUserID + "','" + sUserName + "','" + sOrgID + "','" + sOrgName + "','" + sVersion + "')";
    }
    else if (("FORK".equals(fork)) || ("INFORK".equals(fork))) {
      sSql = "INSERT INTO FLOW_TASK(SerialNo,RelativeSerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,BeginTime,EndTime,UserID,UserName,OrgID,OrgName,forkState,Version)  VALUES ( '" + sSerialNo + "','" + sRelativeSerialNo + "','" + sObjectType + "','" + sObjectNo + "','" + sPhaseType + "','" + sApplyType + "','" + sFlowNo + "','" + sFlowName + "'," + " '" + sPhaseNo + "','" + sPhaseName + "','" + sBeginTime + "',null,'" + sUserID + "','" + sUserName + "','" + sOrgID + "','" + sOrgName + "','1','" + sVersion + "')";
    }
    else if ("JOIN".equals(fork)) {
      sSql = "INSERT INTO FLOW_TASK(SerialNo,RelativeSerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,BeginTime,EndTime,UserID,UserName,OrgID,OrgName,Version)  VALUES ( '" + sSerialNo + "','" + sRelativeSerialNo + "','" + sObjectType + "','" + sObjectNo + "','" + sPhaseType + "','" + sApplyType + "','" + sFlowNo + "','" + sFlowName + "'," + " '" + sPhaseNo + "','" + sPhaseName + "','" + sBeginTime + "',null,'" + sUserID + "','" + sUserName + "','" + sOrgID + "','" + sOrgName + "','" + sVersion + "')";

      endForkTask(sBeginTime, sObjectNo, sObjectType, transSql);
    }
    else if ("BACK".equals(fork)) {
      sSql = "INSERT INTO FLOW_TASK(SerialNo,RelativeSerialNo,ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,BeginTime,EndTime,UserID,UserName,OrgID,OrgName,forkState,Version)  VALUES ( '" + sSerialNo + "','" + sRelativeSerialNo + "','" + sObjectType + "','" + sObjectNo + "','" + sPhaseType + "','" + sApplyType + "','" + sFlowNo + "','" + sFlowName + "'," + " '" + sPhaseNo + "','" + sPhaseName + "','" + sBeginTime + "',null,'" + sUserID + "','" + sUserName + "','" + sOrgID + "','" + sOrgName + "','BACK','" + sVersion + "')";
    }
    else
    {
      throw new FlowException("�ύ���̳��������߱��κ����ó���");
    }

    transSql.executeSQL(sSql);
    return sSerialNo;
  }

  public static void deleteTask(String sSerialNo, Transaction transSql) throws Exception
  {
    transSql.executeSQL("delete from  FLOW_TASK where SerialNo= '" + sSerialNo + "'");
  }

  public static void endForkTask(String sEndTime, String sObjectNo, String sObjectType, Transaction transSql) throws Exception
  {
    transSql.executeSQL("update  FLOW_TASK set EndTime = '" + sEndTime + "' where ObjectNo ='" + sObjectNo + "' and ObjectType = '" + sObjectType + "' and (EndTime is null or EndTime = '')");
  }

  public static void deleteSamePhaseTask(String sObjectType, String sObjectNo, String sFlowNo, String sPhaseNo, String sUserID, Transaction transSql)
    throws Exception
  {
    String sSql = "delete from  FLOW_TASK where ObjectType = '" + sObjectType + "' and ObjectNo= '" + sObjectNo + "' and FlowNo = '" + sFlowNo + "' and PhaseNo = '" + sPhaseNo + "' and UserID <> '" + sUserID + "' and (EndTime is null or EndTime = '') ";
    transSql.executeSQL(sSql);
  }
}