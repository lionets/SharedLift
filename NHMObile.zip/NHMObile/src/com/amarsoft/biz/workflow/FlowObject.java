package com.amarsoft.biz.workflow;

import com.amarsoft.amarscript.Any;
import com.amarsoft.are.util.StringFunction;
import com.amarsoft.awe.util.ASResultSet;
import com.amarsoft.awe.util.Transaction;
import com.amarsoft.context.ASOrg;
import com.amarsoft.context.ASUser;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class FlowObject
{
  public String ObjectType;
  public String ObjectNo;
  public String PhaseType;
  public String ApplyType;
  public String FlowNo;
  public String FlowName;
  public String PhaseNo;
  public String PhaseName;
  public String ObjDescribe;
  public String ObjAttribute1;
  public String ObjAttribute2;
  public String ObjAttribute3;
  public String ObjAttribute4;
  public String ObjAttribute5;
  public String UserID;
  public String UserName;
  public String OrgID;
  public String OrgName;
  public String InputDate;
  public String ArchiveTime;
  public String Version;
  public FlowPhase RelativeFlowPhase;
  Transaction Sqlca;

  public FlowObject(String sObjectType, String sObjectNo, Transaction transSql)
    throws Exception
  {
    this.ObjectType = sObjectType;
    this.ObjectNo = sObjectNo;
    this.Sqlca = transSql;

    String sSql = "select * from FLOW_OBJECT where ObjectType='" + this.ObjectType + "' and ObjectNo='" + this.ObjectNo + "'";
    ASResultSet rsFlowObject = this.Sqlca.getASResultSet(sSql);
    if (rsFlowObject.next()) {
      this.PhaseType = (rsFlowObject.getString("PhaseType") == null ? "" : rsFlowObject.getString("PhaseType"));
      this.ApplyType = (rsFlowObject.getString("ApplyType") == null ? "" : rsFlowObject.getString("ApplyType"));
      this.FlowNo = (rsFlowObject.getString("FlowNo") == null ? "" : rsFlowObject.getString("FlowNo"));
      this.FlowName = (rsFlowObject.getString("FlowName") == null ? "" : rsFlowObject.getString("FlowName"));
      this.PhaseNo = (rsFlowObject.getString("PhaseNo") == null ? "" : rsFlowObject.getString("PhaseNo"));
      this.PhaseName = (rsFlowObject.getString("PhaseName") == null ? "" : rsFlowObject.getString("PhaseName"));
      this.ObjDescribe = (rsFlowObject.getString("ObjDescribe") == null ? "" : rsFlowObject.getString("ObjDescribe"));
      this.ObjAttribute1 = (rsFlowObject.getString("ObjAttribute1") == null ? "" : rsFlowObject.getString("ObjAttribute1"));
      this.ObjAttribute2 = (rsFlowObject.getString("ObjAttribute2") == null ? "" : rsFlowObject.getString("ObjAttribute2"));
      this.ObjAttribute3 = (rsFlowObject.getString("ObjAttribute3") == null ? "" : rsFlowObject.getString("ObjAttribute3"));
      this.ObjAttribute4 = (rsFlowObject.getString("ObjAttribute4") == null ? "" : rsFlowObject.getString("ObjAttribute4"));
      this.ObjAttribute5 = (rsFlowObject.getString("ObjAttribute5") == null ? "" : rsFlowObject.getString("ObjAttribute5"));
      this.OrgID = (rsFlowObject.getString("OrgID") == null ? "" : rsFlowObject.getString("OrgID"));
      this.OrgName = (rsFlowObject.getString("OrgName") == null ? "" : rsFlowObject.getString("OrgName"));
      this.UserID = (rsFlowObject.getString("UserID") == null ? "" : rsFlowObject.getString("UserID"));
      this.UserName = (rsFlowObject.getString("UserName") == null ? "" : rsFlowObject.getString("UserName"));
      this.InputDate = (rsFlowObject.getString("InputDate") == null ? "" : rsFlowObject.getString("InputDate"));
      this.ArchiveTime = (rsFlowObject.getString("ArchiveTime") == null ? "" : rsFlowObject.getString("ArchiveTime"));
      this.Version = (rsFlowObject.getString("Version") == null ? "" : rsFlowObject.getString("Version"));
    } else {
      rsFlowObject.getStatement().close();
      throw new FlowException("FlowObject:ObjectType:" + sObjectType + " ObjectNo:" + sObjectNo + " not Exist");
    }
    rsFlowObject.getStatement().close();
    if ((this.FlowNo != null) && (!this.FlowNo.equals(""))) this.RelativeFlowPhase = new FlowPhase(this.FlowNo, this.PhaseNo, this.Sqlca);
  }

  public void changePhase(FlowPhase fpNext, ASUser asuNext)
    throws Exception
  {
    FlowCatalog fcNext = new FlowCatalog(fpNext.FlowNo, this.Sqlca);
    String[][] sConstantList = { { "#ObjectType", this.ObjectType }, { "#ObjectNo", this.ObjectNo }, { "#ApplyType", this.ApplyType }, { "#PhaseType", fpNext.PhaseType }, { "#FlowNo", fpNext.FlowNo }, { "#FlowName", fcNext.FlowName }, { "#PhaseNo", fpNext.PhaseNo }, { "#PhaseName", fpNext.PhaseName }, { "#UserID", asuNext.getUserID() }, { "#UserName", asuNext.getUserName() }, { "#OrgID", asuNext.getOrgID() }, { "#OrgName", asuNext.getBelongOrg().getOrgName() }, { "#LastPhaseType", this.PhaseType }, { "#LastFlowNo", this.FlowNo }, { "#LastFlowName", this.FlowName }, { "#LastPhaseNo", this.PhaseNo }, { "#LastPhaseName", this.PhaseName }, { "#LastPhaseChoice", "" }, { "#LastPhaseAction", "" }, { "#LastBeginTime", "" }, { "#LastEndTime", "" }, { "#LastUserID", "" }, { "#LastUserName", "" }, { "#LastOrgID", "" }, { "#LastOrgName", "" } };

    changePhase(fpNext, "", sConstantList, "");
  }

  public void changePhase(FlowPhase fpNext, ASUser asuNext, String sRelativeSerialNo)
    throws Exception
  {
    FlowCatalog fcNext = new FlowCatalog(fpNext.FlowNo, this.Sqlca);
    String[][] sConstantList = { { "#ObjectType", this.ObjectType }, { "#ObjectNo", this.ObjectNo }, { "#ApplyType", this.ApplyType }, { "#PhaseType", fpNext.PhaseType }, { "#FlowNo", fpNext.FlowNo }, { "#FlowName", fcNext.FlowName }, { "#PhaseNo", fpNext.PhaseNo }, { "#PhaseName", fpNext.PhaseName }, { "#UserID", asuNext.getUserID() }, { "#UserName", asuNext.getUserName() }, { "#OrgID", asuNext.getOrgID() }, { "#OrgName", asuNext.getBelongOrg().getOrgName() }, { "#LastPhaseType", this.PhaseType }, { "#LastFlowNo", this.FlowNo }, { "#LastFlowName", this.FlowName }, { "#LastPhaseNo", this.PhaseNo }, { "#LastPhaseName", this.PhaseName }, { "#LastPhaseChoice", "" }, { "#LastPhaseAction", "" }, { "#LastBeginTime", "" }, { "#LastEndTime", "" }, { "#LastUserID", "" }, { "#LastUserName", "" }, { "#LastOrgID", "" }, { "#LastOrgName", "" } };

    changePhase(fpNext, sRelativeSerialNo, sConstantList, "");
  }

  public void changePhase(FlowPhase fpNext, FlowTask ftCurrent, String fork)
    throws Exception
  {
    FlowCatalog fcNext = new FlowCatalog(fpNext.FlowNo, this.Sqlca);
    String[][] sConstantList = { { "#ObjectType", this.ObjectType }, { "#ObjectNo", this.ObjectNo }, { "#ApplyType", this.ApplyType }, { "#PhaseType", fpNext.PhaseType }, { "#FlowNo", fpNext.FlowNo }, { "#FlowName", fcNext.FlowName }, { "#PhaseNo", fpNext.PhaseNo }, { "#PhaseName", fpNext.PhaseName }, { "#PhaseAction", ftCurrent.PhaseAction }, { "#PhaseOpinion1", ftCurrent.PhaseOpinion1 }, { "#UserID", ftCurrent.UserID }, { "#UserName", ftCurrent.UserName }, { "#OrgID", ftCurrent.OrgID }, { "#OrgName", ftCurrent.OrgName }, { "#LastPhaseType", ftCurrent.PhaseType }, { "#LastFlowNo", ftCurrent.FlowNo }, { "#LastFlowName", ftCurrent.FlowName }, { "#LastPhaseNo", ftCurrent.PhaseNo }, { "#LastPhaseName", ftCurrent.PhaseName }, { "#LastPhaseChoice", ftCurrent.PhaseChoice }, { "#LastPhaseAction", ftCurrent.PhaseAction }, { "#LastPhaseOpinion1", ftCurrent.PhaseOpinion1 }, { "#LastBeginTime", ftCurrent.BeginTime }, { "#LastEndTime", ftCurrent.EndTime }, { "#LastUserID", ftCurrent.UserID }, { "#LastUserName", ftCurrent.UserName }, { "#LastOrgID", ftCurrent.OrgID }, { "#LastOrgName", ftCurrent.OrgName } };

    changePhase(fpNext, ftCurrent.SerialNo, sConstantList, fork);
  }

  private void changePhase(FlowPhase fpNext, String sRelativeSerialNo, String[][] sConstantList, String fork)
    throws Exception
  {
    String[] sOperatorList = null;

    String[] sUserInfo = null;
    String[] sFlowInfo = null;
    String sNextFlowNo = "";
    String sNextPhaseNo = "";
    int iCount = 0; int iNum = 0;
    List OperatorList = new ArrayList();
    try
    {
      updatePhase(fpNext);
    } catch (Exception ex) {
      throw new FlowException(ex.toString() + "����FlowObject���̽׶η�������");
    }

    try
    {
      fpNext.executeScript("PreScript", sConstantList);
    } catch (Exception ex) {
      throw new FlowException(ex.toString() + "ִ��prescript��������");
    }

    Any aOperatorList;
    try
    {
      aOperatorList = fpNext.executeScript("InitScript", sConstantList);
    } catch (Exception ex) {
      throw new FlowException(ex.toString() + "�а��˳�ʼ����������");
    }
    if (aOperatorList != null) sOperatorList = aOperatorList.toStringArray();

    iNum = sOperatorList.length;
    for (int i = 0; i < iNum; i++)
    {
      if (sOperatorList[i].indexOf("|") >= 0)
      {
        sUserInfo = StringFunction.toStringArray(sOperatorList[i], "|");
        if (sUserInfo[0].indexOf(".") >= 0)
        {
          sFlowInfo = StringFunction.toStringArray(sUserInfo[0], ".");
          sNextFlowNo = sFlowInfo[0];
          sNextPhaseNo = sFlowInfo[1];
        }
        else
        {
          sNextPhaseNo = sUserInfo[0];
          sNextFlowNo = fpNext.FlowNo;
        }

        if ((sNextFlowNo.equals(fpNext.FlowNo)) && (sNextPhaseNo.equals(fpNext.PhaseNo))) {
          OperatorList.add(sUserInfo[1]);
        }
      }
      else
      {
        OperatorList.add(sOperatorList[i]);
      }

    }

    if (OperatorList.size() > 0) {
      String sBeginTime = StringFunction.getTodayNow();
      iCount = OperatorList.size();
      for (int i = 0; i < iCount; i++)
        try
        {
          String sSerialNo = FlowTask.newTask(sRelativeSerialNo, this.ObjectType, this.ObjectNo, fpNext.FlowNo, fpNext.PhaseNo, this.ApplyType, (String)OperatorList.get(i), sBeginTime, this.Sqlca, fork, this.Version);

          FlowTask ft = new FlowTask(sSerialNo, this.Sqlca);
          if ((fpNext.PostScript == null) || (fpNext.PostScript.equals(""))) {
            ft.finish(sBeginTime, "AutoFinish");

            FlowTask.endForkTask(sBeginTime, this.ObjectNo, this.ObjectType, this.Sqlca);
          }
        } catch (Exception ex) {
          throw new FlowException(ex.toString() + "��ʼ��������������");
        }
    }
  }

  protected void changePhase(FlowTask ftNext, FlowTask ft)
    throws Exception
  {
    FlowPhase fpNext = ftNext.RelativeFlowPhase;
    try {
      updatePhase(fpNext);
    } catch (Exception ex) {
      throw new FlowException(ex.toString() + "����FlowObject���̽׶η�������");
    }
    String sBeginTime = StringFunction.getTodayNow();
    FlowTask.newTask(ft.RelativeSerialNo, this.ObjectType, this.ObjectNo, fpNext.FlowNo, fpNext.PhaseNo, this.ApplyType, ftNext.UserID, sBeginTime, this.Sqlca, "", this.Version);
  }

  public void updatePhase(FlowPhase fpNext)
    throws Exception
  {
    FlowCatalog fcNext = new FlowCatalog(fpNext.FlowNo, this.Sqlca);

    String sSql = "update FLOW_OBJECT set PhaseType='" + fpNext.PhaseType + "',FlowNo='" + fpNext.FlowNo + "',FlowName='" + fcNext.FlowName + "',PhaseNo='" + fpNext.PhaseNo + "',PhaseName = '" + fpNext.PhaseName + "' where ObjectType='" + this.ObjectType + "' and ObjectNo='" + this.ObjectNo + "'";
    this.Sqlca.executeSQL(sSql);

    this.RelativeFlowPhase = fpNext;
    this.PhaseType = fpNext.PhaseType;
    this.FlowNo = fpNext.FlowNo;
    this.FlowName = fcNext.FlowName;
    this.PhaseNo = fpNext.PhaseNo;
    this.PhaseName = fpNext.PhaseName;
  }

  public void updateDescribe(String sObjDescribe)
    throws Exception
  {
    String sSql = "update FLOW_OBJECT set ObjDescribe='" + sObjDescribe + "' where ObjectType='" + this.ObjectType + "' and ObjectNo='" + this.ObjectNo + "'";
    this.Sqlca.executeSQL(sSql);

    this.ObjDescribe = sObjDescribe;
  }

  public static void newObject(String sObjectType, String sObjectNo, String sFlowNo, String sPhaseNo, String sApplyType, String sUserID, Transaction transSql)
    throws Exception
  {
    String sUserName = transSql.getString("select UserName from USER_INFO where UserID = '" + sUserID + "'");
    String sOrgID = transSql.getString("select BelongOrg from USER_INFO where UserID = '" + sUserID + "'");
    String sOrgName = transSql.getString("select OrgName from ORG_INFO where OrgID = '" + sOrgID + "'");

    FlowPhase fpTemp = new FlowPhase(sFlowNo, sPhaseNo, transSql);
    String sPhaseName = fpTemp.PhaseName;
    String sPhaseType = fpTemp.PhaseType;

    FlowCatalog fcTemp = new FlowCatalog(sFlowNo, transSql);
    String sFlowName = fcTemp.FlowName;
    String sSql = " Insert into FLOW_OBJECT(ObjectType,ObjectNo,PhaseType,ApplyType,FlowNo,FlowName,  PhaseNo,PhaseName,OrgID,OrgName,UserID,UserName,InputDate)  values ('" + sObjectType + "','" + sObjectNo + "','" + sPhaseType + "','" + sApplyType + "','" + sFlowNo + "','" + sFlowName + "', " + " '" + sPhaseNo + "','" + sPhaseName + "','" + sOrgID + "','" + sOrgName + "','" + sUserID + "','" + sUserName + "','" + StringFunction.getToday() + "') ";

    transSql.executeSQL(sSql);
  }
}